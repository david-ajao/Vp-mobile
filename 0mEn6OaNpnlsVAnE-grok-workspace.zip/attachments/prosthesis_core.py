"""
Adaptive 1,600-Element Visual Prosthesis Simulator - Step 7+ Protected Context
==============================================================================

SCIENTIFIC & SYSTEM ACCURACY DISCLAIMER:
    The 1,600 elements processed here represent VIRTUAL visual encoding elements 
    (spatial sampling territories). They are NOT physical electrodes, NOT TMS coils, 
    and DO NOT constitute a claim about a real human implant or physiological cortical
    simulation. This system is an experimental computational design testing whether 
    adaptive spatial sampling combined with bounded local contrast assistance improves 
    multi-object scene representation without losing background context.

Core Allocator Features:
------------------------
1. Protected Background/Context Allocation Range (15% - 25% / 240 - 400 elements):
   - Preferred Target: 20% (320 elements)
   - Minimum Protection Floor: 15% (240 elements)
   - Maximum Cap Ceiling: 25% (400 elements)

2. Continuous Importance Topology Preserved:
   - Remaining ~80% (1,200–1,360 elements) adaptively partitioned across high and 
     medium importance regions following continuous importance scores.

3. Complete Diagnostics Verification:
   - Explicitly validates total count == 1,600 and context allocation within range.
"""

import argparse
import abc
import heapq
import itertools
import typing

import cv2
import numpy as np
from ultralytics import YOLO

# ============================================================
# CONSTANTS & CONFIGURATION
# ============================================================

WINDOW_MAIN = "YOLO Detections (Box + Mask)"
WINDOW_PHOSPHENE = "Simulated Phosphene Perception (Step 7+)"
WINDOW_ADAPTIVE = "Adaptive Territory Map"
WINDOW_TEST = "Encoding Test Results"

WINDOW_SEMANTIC = "Signal 1: Semantic Map"
WINDOW_DETAIL = "Signal 2: Detail Map"
WINDOW_SALIENCY = "Signal 3: Saliency Map"
WINDOW_CONTEXT = "Signal 4: Context Map"
WINDOW_COMBINED = "Combined Importance Map"

GRID_COLS: int = 40
GRID_ROWS: int = 40
TOTAL_ELEMENTS: int = GRID_COLS * GRID_ROWS  # Exactly 1,600 virtual encoding elements

OUTPUT_SIZE: int = 800

SEMANTIC_WEIGHT: float = 0.35
DETAIL_WEIGHT: float = 0.25
SALIENCY_WEIGHT: float = 0.20
CONTEXT_WEIGHT: float = 0.20

MIN_IMPORTANCE: float = 0.05
MAX_IMPORTANCE: float = 1.0
MAX_RESOLUTION_RATIO: float = 8.0
ALLOCATION_EXPONENT: float = 1.5
MIN_TERRITORY_SIZE: int = 4
MAX_TERRITORY_FRACTION: float = 0.125

# ---- Protected Context Allocation Range Parameters ----
BACKGROUND_TARGET: float = 0.20  # 20% target (320 elements)
BACKGROUND_MIN: float = 0.15     # 15% floor (240 elements)
BACKGROUND_MAX: float = 0.25     # 25% ceiling (400 elements)

TARGET_CONTEXT_COUNT: int = int(TOTAL_ELEMENTS * BACKGROUND_TARGET)  # 320
MIN_CONTEXT_COUNT: int = int(TOTAL_ELEMENTS * BACKGROUND_MIN)        # 240
MAX_CONTEXT_COUNT: int = int(TOTAL_ELEMENTS * BACKGROUND_MAX)        # 400

HIGH_IMPORTANCE_THRESHOLD: float = 0.45
LOW_IMPORTANCE_THRESHOLD: float = 0.20

CONTRAST_ASSIST_ALPHA: float = 0.08
MAX_CONTRAST_GAIN: float = 1.25
MAX_BRIGHTNESS_DELTA: float = 0.12
LOCAL_LUMINANCE_SIGMA: float = 15.0

ANALYSIS_SCALE: float = 0.5
IMPORTANCE_SMOOTH_SIGMA: float = 3.0
IMPORTANCE_TEMPORAL_ALPHA: float = 0.75

PERSON_SEMANTIC_LEVEL: float = 0.85
OBJECT_SEMANTIC_LEVEL: float = 0.65
BBOX_REGION_WEIGHT: float = 0.4
MASK_REFINEMENT_WEIGHT: float = 0.6
SEMANTIC_EVERY_N_FRAMES: int = 5

# ---- Step 7+ Density-Aware PSF Separability Experiment ----
# Baseline (fixed) PSF:
PHOSPHENE_BASE_RADIUS: float = 5.5
PHOSPHENE_BLUR_SIGMA: float = 2.5

# Conservative density-aware range (never extreme)
PHOSPHENE_RADIUS_MIN: float = 3.8   # densest regions
PHOSPHENE_RADIUS_MAX: float = 6.2   # sparsest regions
DENSITY_KNN: int = 6                # local neighborhood size
DENSITY_SMOOTH_ALPHA: float = 0.65  # temporal smoothing of density scores

# Toggle: True = density-aware experiment, False = fixed baseline
density_aware_enabled: bool = True

adaptive_enabled: bool = True
grid_enabled: bool = True
semantic_enabled: bool = True
contrast_assist_enabled: bool = True




def importance_floor() -> float:
    return max(MIN_IMPORTANCE, MAX_IMPORTANCE / MAX_RESOLUTION_RATIO)


# ============================================================
# CAMERA & SEMANTIC PROVIDER
# ============================================================

def open_camera(index: int = 0) -> cv2.VideoCapture:
    cap = cv2.VideoCapture(index)
    if cap.isOpened():
        return cap
    cap.release()
    cap = cv2.VideoCapture(index, cv2.CAP_DSHOW)
    if cap.isOpened():
        return cap
    cap.release()
    raise RuntimeError(f"Could not open camera device at index {index}.")


class SemanticProvider(abc.ABC):
    @property
    @abc.abstractmethod
    def name(self) -> str:
        pass

    @abc.abstractmethod
    def detect(self, frame_bgr: np.ndarray) -> typing.List[typing.Tuple[float, float, float, float, float, str, typing.Optional[np.ndarray]]]:
        pass


class YOLOSemanticProvider(SemanticProvider):
    def __init__(self, model_path: str = "yolo11n-seg.pt"):
        print(f"[INFO] Initializing YOLO segmentation engine ({model_path})...")
        self.model = YOLO(model_path)
        self._name = f"Ultralytics YOLO ({model_path})"

    @property
    def name(self) -> str:
        return self._name

    def detect(self, frame_bgr: np.ndarray) -> typing.List[typing.Tuple[float, float, float, float, float, str, typing.Optional[np.ndarray]]]:
        results = self.model(frame_bgr, verbose=False)[0]
        detections = []

        if results.boxes is not None:
            boxes = results.boxes.xyxy.cpu().numpy()
            classes = results.boxes.cls.cpu().numpy()
            masks = results.masks.xy if results.masks is not None else [None] * len(boxes)

            for box, cls_id, mask_poly in zip(boxes, classes, masks):
                x1, y1, x2, y2 = box
                w, h = x2 - x1, y2 - y1
                label = self.model.names[int(cls_id)]
                level = PERSON_SEMANTIC_LEVEL if label == "person" else OBJECT_SEMANTIC_LEVEL
                detections.append((float(x1), float(y1), float(w), float(h), level, label, mask_poly))

        return detections


class FallbackSemanticProvider(SemanticProvider):
    @property
    def name(self) -> str:
        return "Fallback (Disabled / Manual Mode)"

    def detect(self, frame_bgr: np.ndarray) -> typing.List:
        return []


# ============================================================
# IMPORTANCE FUSION ENGINE
# ============================================================

def to_analysis_image(gray: np.ndarray) -> np.ndarray:
    h, w = gray.shape
    aw = max(32, int(w * ANALYSIS_SCALE))
    ah = max(32, int(h * ANALYSIS_SCALE))
    return cv2.resize(gray, (aw, ah), interpolation=cv2.INTER_AREA).astype(np.float32)


def calculate_semantic_map(detections: typing.List, full_shape: typing.Tuple[int, int], analysis_shape: typing.Tuple[int, int]) -> np.ndarray:
    full_h, full_w = full_shape
    ah, aw = analysis_shape
    sem_bbox = np.zeros((ah, aw), dtype=np.float32)
    sem_mask = np.zeros((ah, aw), dtype=np.float32)

    if not detections:
        return np.zeros((ah, aw), dtype=np.float32)

    sx, sy = aw / full_w, ah / full_h

    for (x, y, w, h, level, _label, mask_poly) in detections:
        x0, y0 = max(0, int(x * sx)), max(0, int(y * sy))
        x1, y1 = min(aw, int((x + w) * sx)), min(ah, int((y + h) * sy))
        if x1 > x0 and y1 > y0:
            sem_bbox[y0:y1, x0:x1] = np.maximum(sem_bbox[y0:y1, x0:x1], level * BBOX_REGION_WEIGHT)

        if mask_poly is not None and len(mask_poly) > 0:
            scaled_poly = (mask_poly * np.array([sx, sy])).astype(np.int32)
            temp_mask = np.zeros((ah, aw), dtype=np.uint8)
            cv2.fillPoly(temp_mask, [scaled_poly], 255)
            mask_float = (temp_mask.astype(np.float32) / 255.0) * level * MASK_REFINEMENT_WEIGHT
            sem_mask = np.maximum(sem_mask, mask_float)

    return np.clip(sem_bbox + sem_mask, 0.0, 1.0).astype(np.float32)


def calculate_detail_map(img: np.ndarray) -> np.ndarray:
    sigmas = (1.2, 3.0, 6.0)
    refs = (300.0, 180.0, 90.0)
    weights = (0.5, 0.3, 0.2)
    detail_acc = np.zeros_like(img, dtype=np.float32)

    for s, r, w in zip(sigmas, refs, weights):
        blurred = cv2.GaussianBlur(img, (0, 0), s)
        gx = cv2.Sobel(blurred, cv2.CV_32F, 1, 0, ksize=3)
        gy = cv2.Sobel(blurred, cv2.CV_32F, 0, 1, ksize=3)
        detail_acc += w * np.clip(cv2.magnitude(gx, gy) / r, 0.0, 1.0)

    return np.clip(detail_acc, 0.0, 1.0).astype(np.float32)


def calculate_saliency_map(img: np.ndarray) -> np.ndarray:
    fine = cv2.GaussianBlur(img, (0, 0), 2.0)
    coarse = cv2.GaussianBlur(img, (0, 0), 14.0)
    dog = np.clip(np.abs(fine - coarse) / 40.0, 0.0, 1.0)

    median_val = float(np.median(img))
    regional = cv2.GaussianBlur(img, (0, 0), 8.0)
    global_contrast = np.clip(np.abs(regional - median_val) / 60.0, 0.0, 1.0)

    return np.clip(0.6 * dog + 0.4 * global_contrast, 0.0, 1.0).astype(np.float32)


def calculate_context_map(img: np.ndarray) -> np.ndarray:
    large_blur = cv2.GaussianBlur(img, (0, 0), 16.0)
    structural_grad = cv2.Sobel(large_blur, cv2.CV_32F, 1, 1, ksize=5)
    ctx_struct = np.clip(np.abs(structural_grad) / 50.0, 0.0, 1.0)

    regional_std = cv2.GaussianBlur(img ** 2, (0, 0), 12.0) - cv2.GaussianBlur(img, (0, 0), 12.0) ** 2
    ctx_continuity = np.clip(np.sqrt(np.maximum(0.0, regional_std)) / 40.0, 0.0, 1.0)

    return np.clip(0.5 * ctx_struct + 0.5 * ctx_continuity, 0.0, 1.0).astype(np.float32)


class ImportanceEngine:
    def __init__(self):
        self.previous = None

    def reset(self):
        self.previous = None

    def compute(self, gray: np.ndarray, detections: typing.List, semantic_active: bool, use_temporal: bool = True):
        full_h, full_w = gray.shape
        img = to_analysis_image(gray)
        ah, aw = img.shape

        semantic_map = calculate_semantic_map(detections, (full_h, full_w), (ah, aw)) if semantic_active else np.zeros((ah, aw), dtype=np.float32)
        w_sem = SEMANTIC_WEIGHT if semantic_active else 0.0

        detail_map = calculate_detail_map(img)
        saliency_map = calculate_saliency_map(img)
        context_map = calculate_context_map(img)

        total_weight = w_sem + DETAIL_WEIGHT + SALIENCY_WEIGHT + CONTEXT_WEIGHT
        combined = (w_sem * semantic_map + DETAIL_WEIGHT * detail_map +
                    SALIENCY_WEIGHT * saliency_map + CONTEXT_WEIGHT * context_map) / total_weight

        combined = cv2.GaussianBlur(combined, (0, 0), IMPORTANCE_SMOOTH_SIGMA)
        importance = np.clip(combined, importance_floor(), MAX_IMPORTANCE).astype(np.float32)

        if use_temporal and self.previous is not None and self.previous.shape == importance.shape:
            importance = IMPORTANCE_TEMPORAL_ALPHA * self.previous + (1.0 - IMPORTANCE_TEMPORAL_ALPHA) * importance
        self.previous = importance

        full_imp = cv2.resize(importance, (full_w, full_h), interpolation=cv2.INTER_LINEAR)
        full_imp = np.clip(full_imp, importance_floor(), MAX_IMPORTANCE).astype(np.float32)

        debug_maps = {
            "semantic": cv2.resize(semantic_map, (full_w, full_h)),
            "detail": cv2.resize(detail_map, (full_w, full_h)),
            "saliency": cv2.resize(saliency_map, (full_w, full_h)),
            "context": cv2.resize(context_map, (full_w, full_h)),
            "combined": full_imp,
        }

        return full_imp, debug_maps


# ============================================================
# PROTECTED RANGE ALLOCATION & CONTRAST ASSISTANCE
# ============================================================

def apply_perceptual_contrast_assistance(
    gray: np.ndarray, 
    rects: np.ndarray, 
    scores: np.ndarray, 
    raw_brightness: np.ndarray
) -> np.ndarray:
    if not contrast_assist_enabled:
        return raw_brightness.copy()

    height, width = gray.shape
    norm_gray = gray.astype(np.float32) / 255.0
    b_local_map = cv2.GaussianBlur(norm_gray, (0, 0), LOCAL_LUMINANCE_SIGMA)

    x, y, w, h = rects[:, 0], rects[:, 1], rects[:, 2], rects[:, 3]
    cx_idx = np.clip((x + w // 2).astype(int), 0, width - 1)
    cy_idx = np.clip((y + h // 2).astype(int), 0, height - 1)

    b_orig = raw_brightness / 255.0
    b_local = b_local_map[cy_idx, cx_idx]

    contrast_factor = np.minimum(1.0 + CONTRAST_ASSIST_ALPHA * scores, MAX_CONTRAST_GAIN)
    b_out = b_local + (b_orig - b_local) * contrast_factor

    brightness_shift = np.clip(b_out - b_orig, -MAX_BRIGHTNESS_DELTA, MAX_BRIGHTNESS_DELTA)
    return np.clip(b_orig + brightness_shift, 0.0, 1.0) * 255.0


def _rect_sum(integral: np.ndarray, x: int, y: int, w: int, h: int) -> float:
    return float(integral[y + h, x + w] - integral[y, x + w] - integral[y + h, x] + integral[y, x])


def _split_rect(x: int, y: int, w: int, h: int) -> typing.List[typing.Tuple[int, int, int, int]]:
    hw, hh = w // 2, h // 2
    return [
        (x, y, hw, hh),
        (x + hw, y, w - hw, hh),
        (x, y + hh, hw, h - hh),
        (x + hw, y + hh, w - hw, h - hh),
    ]


def _can_split(w: int, h: int) -> bool:
    return w >= 2 * MIN_TERRITORY_SIZE and h >= 2 * MIN_TERRITORY_SIZE


def _finalize_territories(
    leaves: typing.List, 
    gray_integral: np.ndarray, 
    gray: np.ndarray, 
    importance_map: np.ndarray
) -> typing.Dict[str, np.ndarray]:
    rects = np.array([leaf[0] for leaf in leaves], dtype=np.int64)
    scores = np.array([leaf[1] for leaf in leaves], dtype=np.float32)
    x, y, w, h = rects[:, 0], rects[:, 1], rects[:, 2], rects[:, 3]

    sums = (gray_integral[y + h, x + w] - gray_integral[y, x + w]
            - gray_integral[y + h, x] + gray_integral[y, x])
    raw_brightness = sums / (w * h).astype(np.float64)

    assisted_brightness = apply_perceptual_contrast_assistance(gray, rects, scores, raw_brightness)

    return {
        "rects": rects,
        "score": scores,
        "brightness": assisted_brightness,
        "raw_brightness": raw_brightness,
        "cx": x + w / 2.0,
        "cy": y + h / 2.0,
    }


def build_territories(gray: np.ndarray, importance_map: np.ndarray) -> typing.Dict[str, np.ndarray]:
    """
    Quadtree partition guaranteeing 1,600 territories with a PROTECTED 
    Context/Background Allocation Range (15% - 25% / 240 - 400 elements).
    """
    height, width = gray.shape
    gray_integral = cv2.integral(gray, sdepth=cv2.CV_64F)
    imp_integral = cv2.integral(importance_map, sdepth=cv2.CV_64F)
    max_side = max(width, height) * MAX_TERRITORY_FRACTION

    def mean_importance(x: int, y: int, w: int, h: int) -> float:
        return _rect_sum(imp_integral, x, y, w, h) / float(w * h)

    def compute_prio(w: int, h: int, score: float) -> float:
        if w > max_side or h > max_side:
            return 1e12 + w * h
        return (score ** ALLOCATION_EXPONENT) * float(w * h)

    counter = itertools.count()
    high_med_heap = []
    context_heap = []
    high_med_frozen = []
    context_frozen = []

    root_rect = (0, 0, width, height)
    root_score = mean_importance(*root_rect)
    root_prio = compute_prio(width, height, root_score)

    if root_score < LOW_IMPORTANCE_THRESHOLD:
        heapq.heappush(context_heap, (-root_prio, next(counter), root_rect, root_score))
        current_context_count = 1
        current_high_med_count = 0
    else:
        heapq.heappush(high_med_heap, (-root_prio, next(counter), root_rect, root_score))
        current_context_count = 0
        current_high_med_count = 1

    leaf_count = 1

    while leaf_count < TOTAL_ELEMENTS:
        can_pop_high_med = len(high_med_heap) > 0
        can_pop_context = len(context_heap) > 0

        if not can_pop_high_med and not can_pop_context:
            break

        # Protected range logic governing pops
        if can_pop_high_med and can_pop_context:
            if current_context_count < MIN_CONTEXT_COUNT:
                # Force context split to build up protection floor
                pop_from_high_med = False
            elif current_context_count + 3 > MAX_CONTEXT_COUNT:
                # Context limit reached, strictly split high/med
                pop_from_high_med = True
            elif current_context_count < TARGET_CONTEXT_COUNT:
                # Context is between MIN and TARGET: favor context if its priority is competitive
                prio_high_med = -high_med_heap[0][0]
                prio_context = -context_heap[0][0]
                pop_from_high_med = (prio_high_med > prio_context * 1.5)
            else:
                # Context is between TARGET and MAX: prefer high/med splits
                prio_high_med = -high_med_heap[0][0]
                prio_context = -context_heap[0][0]
                pop_from_high_med = (prio_high_med * 1.5 >= prio_context)
        elif can_pop_high_med:
            pop_from_high_med = True
        else:
            pop_from_high_med = False

        if pop_from_high_med:
            neg_prio, _, (x, y, w, h), score = heapq.heappop(high_med_heap)
            current_high_med_count -= 1
        else:
            neg_prio, _, (x, y, w, h), score = heapq.heappop(context_heap)
            current_context_count -= 1

        children = _split_rect(x, y, w, h)
        for cx, cy, cw, ch in children:
            c_score = mean_importance(cx, cy, cw, ch)
            c_prio = compute_prio(cw, ch, c_score)
            c_is_context = (c_score < LOW_IMPORTANCE_THRESHOLD)

            if _can_split(cw, ch):
                if c_is_context:
                    current_context_count += 1
                    heapq.heappush(context_heap, (-c_prio, next(counter), (cx, cy, cw, ch), c_score))
                else:
                    current_high_med_count += 1
                    heapq.heappush(high_med_heap, (-c_prio, next(counter), (cx, cy, cw, ch), c_score))
            else:
                if c_is_context:
                    current_context_count += 1
                    context_frozen.append(((cx, cy, cw, ch), c_score))
                else:
                    current_high_med_count += 1
                    high_med_frozen.append(((cx, cy, cw, ch), c_score))

        leaf_count += 3

    leaves = (high_med_frozen + context_frozen + 
              [(item[2], item[3]) for item in high_med_heap] + 
              [(item[2], item[3]) for item in context_heap])

    return _finalize_territories(leaves, gray_integral, gray, importance_map)


def build_uniform_territories(gray: np.ndarray, importance_map: np.ndarray) -> typing.Dict[str, np.ndarray]:
    height, width = gray.shape
    gray_integral = cv2.integral(gray, sdepth=cv2.CV_64F)
    imp_integral = cv2.integral(importance_map, sdepth=cv2.CV_64F)
    xs = np.linspace(0, width, GRID_COLS + 1).astype(int)
    ys = np.linspace(0, height, GRID_ROWS + 1).astype(int)
    leaves = []
    for r in range(GRID_ROWS):
        for c in range(GRID_COLS):
            rect = (int(xs[c]), int(ys[r]), int(xs[c + 1] - xs[c]), int(ys[r + 1] - ys[r]))
            score = _rect_sum(imp_integral, *rect) / float(rect[2] * rect[3])
            leaves.append((rect, score))
    return _finalize_territories(leaves, gray_integral, gray, importance_map)


# ============================================================
# DIAGNOSTICS & RENDERING
# ============================================================

def draw_detections_and_masks(frame: np.ndarray, detections: typing.List) -> np.ndarray:
    out = frame.copy()
    for (x, y, w, h, _level, label, mask_poly) in detections:
        color_box = (0, 255, 255)
        color_mask = (0, 255, 0) if label == "person" else (255, 0, 255)
        cv2.rectangle(out, (int(x), int(y)), (int(x + w), int(y + h)), color_box, 2)
        cv2.putText(out, f"{label}", (int(x), max(15, int(y) - 5)),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, color_box, 1)
        if mask_poly is not None and len(mask_poly) > 0:
            poly_pts = mask_poly.astype(np.int32).reshape((-1, 1, 2))
            cv2.polylines(out, [poly_pts], True, color_mask, 2)
    return out


def color_map_visual(map_2d: np.ndarray) -> np.ndarray:
    u8 = np.clip(map_2d * 255.0, 0, 255).astype(np.uint8)
    return cv2.applyColorMap(u8, cv2.COLORMAP_JET)


def calculate_diagnostics(gray: np.ndarray, territories: typing.Dict, importance_map: np.ndarray) -> typing.Dict:
    height, width = gray.shape
    rects = territories["rects"]
    scores = territories["score"]
    n = len(rects)

    counter = np.zeros((height, width), dtype=np.int32)
    oob_count = 0
    for x, y, w, h in rects:
        if x < 0 or y < 0 or x + w > width or y + h > height:
            oob_count += 1
        else:
            counter[y:y + h, x:x + w] += 1

    uncovered = int(np.count_nonzero(counter == 0))
    overlapping = int(np.count_nonzero(counter > 1))
    coverage_percent = 100.0 * np.count_nonzero(counter >= 1) / (height * width)

    high_mask = scores >= HIGH_IMPORTANCE_THRESHOLD
    med_mask = (scores >= LOW_IMPORTANCE_THRESHOLD) & (scores < HIGH_IMPORTANCE_THRESHOLD)
    context_mask = scores < LOW_IMPORTANCE_THRESHOLD

    high_count = int(np.count_nonzero(high_mask))
    med_count = int(np.count_nonzero(med_mask))
    context_count = int(np.count_nonzero(context_mask))

    pct_high = 100.0 * high_count / n
    pct_med = 100.0 * med_count / n
    pct_context = 100.0 * context_count / n

    context_protection_pass = (MIN_CONTEXT_COUNT <= context_count <= MAX_CONTEXT_COUNT)

    brightness_delta = float(np.abs(territories["brightness"] - territories["raw_brightness"]).mean())

    # Brightness statistics for PSF experiment (luminance left unchanged)
    b = territories["brightness"]
    mean_b = float(np.mean(b))
    min_b = float(np.min(b))
    max_b = float(np.max(b))
    near_black = int(np.count_nonzero(b < 8.0))
    saturated = int(np.count_nonzero(b > 247.0))
    pct_near_black = 100.0 * near_black / n
    pct_saturated = 100.0 * saturated / n

    return {
        "elements": n,
        "coverage_percent": coverage_percent,
        "uncovered_pixels": uncovered,
        "overlapping_pixels": overlapping,
        "oob_territories": oob_count,
        "high_count": high_count,
        "pct_high": pct_high,
        "med_count": med_count,
        "pct_med": pct_med,
        "context_count": context_count,
        "pct_context": pct_context,
        "context_protection_pass": context_protection_pass,
        "avg_contrast_assist_delta": brightness_delta,
        "mean_brightness": mean_b,
        "min_brightness": min_b,
        "max_brightness": max_b,
        "near_black_count": near_black,
        "pct_near_black": pct_near_black,
        "saturated_count": saturated,
        "pct_saturated": pct_saturated,
    }



def create_diagnostics_panel(d: typing.Dict, semantic_status: str) -> np.ndarray:
    panel = np.zeros((760, 780), dtype=np.uint8)
    pass_str = "PASS" if d["context_protection_pass"] else "FAIL (Insufficient scene context)"
    mode_str = "DENSITY-AWARE (experiment)" if density_aware_enabled else "FIXED BASELINE"
    lines = [
        "STEP 7+ - VISUAL PROSTHESIS SIMULATOR (diagnostics)",
        f"PSF mode: {mode_str}  [press D to toggle A/B]",
        f"Radius range: {PHOSPHENE_RADIUS_MIN:.1f} .. {PHOSPHENE_RADIUS_MAX:.1f}  (base {PHOSPHENE_BASE_RADIUS:.1f})",
        "",
        f"Total territories:           {d['elements']} / {TOTAL_ELEMENTS}",
        f"Coverage:                    {d['coverage_percent']:.2f}%",
        f"Overlap violations:          {d['overlapping_pixels']}",
        f"Out-of-bounds territories:   {d['oob_territories']}",
        "",
        "--- CONTINUOUS IMPORTANCE ALLOCATION ---",
        f"High importance:             {d['high_count']} ({d['pct_high']:.1f}%)",
        f"Medium importance:           {d['med_count']} ({d['pct_med']:.1f}%)",
        f"Context/background:          {d['context_count']} ({d['pct_context']:.1f}%)",
        "",
        "--- PROTECTED BACKGROUND ALLOCATION RANGE ---",
        f"Context target:              {BACKGROUND_TARGET*100:.1f}% ({TARGET_CONTEXT_COUNT} elements)",
        f"Context minimum:             {BACKGROUND_MIN*100:.1f}% ({MIN_CONTEXT_COUNT} elements)",
        f"Context maximum:             {BACKGROUND_MAX*100:.1f}% ({MAX_CONTEXT_COUNT} elements)",
        f"Actual context allocation:   {d['pct_context']:.1f}% ({d['context_count']} elements)",
        f"Context protection:          {pass_str}",
        "",
        "--- BRIGHTNESS (luminance preserved) ---",
        f"Mean brightness:             {d['mean_brightness']:.2f}",
        f"Min / Max brightness:        {d['min_brightness']:.1f} / {d['max_brightness']:.1f}",
        f"Near-black elements (<8):    {d['near_black_count']} ({d['pct_near_black']:.1f}%)",
        f"Saturated elements (>247):   {d['saturated_count']} ({d['pct_saturated']:.1f}%)",
        f"Contrast Assist Enabled:     {contrast_assist_enabled}",
        f"Mean brightness shift:       {d['avg_contrast_assist_delta']:.4f} / 255.0",
        "",
        f"Semantic provider:           {semantic_status}",
    ]
    y = 20
    for line in lines:
        cv2.putText(panel, line, (12, y), cv2.FONT_HERSHEY_SIMPLEX, 0.45, 255, 1)
        y += 20
    return panel




# Temporal state for density smoothing (preserves stability)
_prev_density_scores: typing.Optional[np.ndarray] = None


def _compute_local_density_scores(cx: np.ndarray, cy: np.ndarray, knn: int = DENSITY_KNN) -> np.ndarray:
    """Lightweight continuous density estimate from k-nearest neighbor distances.
    Higher score = denser local packing. Returns values roughly in [0, 1].
    """
    n = len(cx)
    if n < 2:
        return np.zeros(n, dtype=np.float32)

    pts = np.stack([cx, cy], axis=1).astype(np.float32)
    # Pairwise squared distances (n is 1600, fine for real-time)
    diff = pts[:, None, :] - pts[None, :, :]
    d2 = np.sum(diff * diff, axis=2)
    np.fill_diagonal(d2, np.inf)

    k = min(knn, n - 1)
    # Mean distance to k nearest neighbors
    knn_d2 = np.partition(d2, k, axis=1)[:, :k]
    mean_d = np.sqrt(np.maximum(knn_d2.mean(axis=1), 1e-6))

    # Convert distance → density score (smaller distance = higher density)
    # Normalize robustly with percentiles to avoid outliers dominating
    p10, p90 = np.percentile(mean_d, [10, 90])
    span = max(p90 - p10, 1e-3)
    density = 1.0 - np.clip((mean_d - p10) / span, 0.0, 1.0)
    return density.astype(np.float32)


def render_phosphenes(territories: typing.Dict, input_shape: typing.Tuple[int, int]) -> np.ndarray:
    """Density-aware PSF renderer.
    - Sparse regions keep near-baseline radius (coherence + background).
    - Dense regions receive modestly smaller radius (improved separability).
    - Variation is continuous and tightly bounded so objects stay coherent.
    - Brightness values are taken unchanged from the encoding stage.
    """
    global _prev_density_scores

    img_h, img_w = input_shape
    canvas = np.zeros((OUTPUT_SIZE, OUTPUT_SIZE), dtype=np.float32)
    sx, sy = OUTPUT_SIZE / img_w, OUTPUT_SIZE / img_h

    cx = territories["cx"] * sx
    cy = territories["cy"] * sy
    brightness = territories["brightness"]
    n = len(cx)

    if density_aware_enabled and n > 8:
        density = _compute_local_density_scores(cx, cy, DENSITY_KNN)

        # Temporal smoothing to protect frame-to-frame stability
        if (_prev_density_scores is not None
                and _prev_density_scores.shape == density.shape):
            density = (DENSITY_SMOOTH_ALPHA * _prev_density_scores
                       + (1.0 - DENSITY_SMOOTH_ALPHA) * density)
        _prev_density_scores = density.copy()

        # Continuous mapping: high density → smaller radius, low density → larger
        # Kept deliberately conservative so dense objects remain coherent structures
        radii = PHOSPHENE_RADIUS_MAX - density * (PHOSPHENE_RADIUS_MAX - PHOSPHENE_RADIUS_MIN)
        radii = np.clip(radii, PHOSPHENE_RADIUS_MIN, PHOSPHENE_RADIUS_MAX)
    else:
        radii = np.full(n, PHOSPHENE_BASE_RADIUS, dtype=np.float32)
        _prev_density_scores = None

    for i in range(n):
        center = (int(cx[i]), int(cy[i]))
        val = float(brightness[i]) / 255.0
        r = int(round(radii[i]))
        cv2.circle(canvas, center, r, val, -1)

    phosphene_sim = cv2.GaussianBlur(canvas, (0, 0), PHOSPHENE_BLUR_SIGMA)
    return np.clip(phosphene_sim * 255.0, 0, 255).astype(np.uint8)



def render_territory_map(territories: typing.Dict, importance_map: np.ndarray, input_shape: typing.Tuple[int, int]) -> np.ndarray:
    img_h, img_w = input_shape
    heat = cv2.resize(importance_map, (OUTPUT_SIZE, OUTPUT_SIZE))
    heat_u8 = np.clip(heat * 255.0, 0, 255).astype(np.uint8)
    canvas = (cv2.applyColorMap(heat_u8, cv2.COLORMAP_JET) * 0.35).astype(np.uint8)

    sx, sy = OUTPUT_SIZE / img_w, OUTPUT_SIZE / img_h
    for x, y, w, h in territories["rects"]:
        cv2.rectangle(canvas, (int(x * sx), int(y * sy)),
                      (int((x + w) * sx), int((y + h) * sy)), (230, 230, 230), 1)
    return canvas


def draw_grid(image: np.ndarray) -> np.ndarray:
    output = image.copy()
    cell_w = OUTPUT_SIZE // GRID_COLS
    cell_h = OUTPUT_SIZE // GRID_ROWS
    for x in range(0, OUTPUT_SIZE, cell_w):
        cv2.line(output, (x, 0), (x, OUTPUT_SIZE), 50, 1)
    for y in range(0, OUTPUT_SIZE, cell_h):
        cv2.line(output, (0, y), (OUTPUT_SIZE, y), 50, 1)
    return output


def encode_frame(gray: np.ndarray, engine: ImportanceEngine, detections: typing.List, semantic_active: bool, adaptive: bool, use_temporal: bool = True):
    importance_map, debug_maps = engine.compute(gray, detections, semantic_active, use_temporal)
    territories = build_territories(gray, importance_map) if adaptive else build_uniform_territories(gray, importance_map)
    return importance_map, territories, debug_maps


# ============================================================
# MAIN APPLICATION LOOP
# ============================================================

def main(provider: typing.Optional[SemanticProvider] = None, camera_index: int = 0):
    global adaptive_enabled, grid_enabled, semantic_enabled, contrast_assist_enabled
    global density_aware_enabled, _prev_density_scores



    if provider is None:
        try:
            provider = YOLOSemanticProvider("yolo11n-seg.pt")
        except Exception as error:
            print(f"[WARNING] YOLO provider failed ({error}). Running in FALLBACK mode.")
            provider = FallbackSemanticProvider()

    cap = open_camera(camera_index)
    engine = ImportanceEngine()
    detections = []
    frame_index = 0

    try:
        while True:
            ret, frame = cap.read()
            if not ret or frame is None or frame.size == 0:
                break

            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

            semantic_active = not isinstance(provider, FallbackSemanticProvider) and semantic_enabled
            if semantic_active:
                if frame_index % SEMANTIC_EVERY_N_FRAMES == 0:
                    detections = provider.detect(frame)
            else:
                detections = []
            frame_index += 1

            importance_map, territories, debug_maps = encode_frame(
                gray, engine, detections, semantic_active, adaptive_enabled)

            phosphene_canvas = render_phosphenes(territories, gray.shape)
            phosphene_display = draw_grid(phosphene_canvas) if grid_enabled else phosphene_canvas
            territory_display = render_territory_map(territories, importance_map, gray.shape)

            diag = calculate_diagnostics(gray, territories, importance_map)
            status = provider.name if semantic_active else "OFF (FALLBACK mode)"
            test_display = create_diagnostics_panel(diag, status)

            cv2.imshow(WINDOW_MAIN, draw_detections_and_masks(frame, detections))
            cv2.imshow(WINDOW_PHOSPHENE, phosphene_display)
            cv2.imshow(WINDOW_ADAPTIVE, territory_display)
            cv2.imshow(WINDOW_TEST, test_display)

            cv2.imshow(WINDOW_SEMANTIC, color_map_visual(debug_maps["semantic"]))
            cv2.imshow(WINDOW_DETAIL, color_map_visual(debug_maps["detail"]))
            cv2.imshow(WINDOW_SALIENCY, color_map_visual(debug_maps["saliency"]))
            cv2.imshow(WINDOW_CONTEXT, color_map_visual(debug_maps["context"]))
            cv2.imshow(WINDOW_COMBINED, color_map_visual(debug_maps["combined"]))

            key = cv2.waitKey(1) & 0xFF
            if key == ord("q"):
                break
            elif key == ord("g"):
                grid_enabled = not grid_enabled
            elif key == ord("a"):
                adaptive_enabled = not adaptive_enabled
            elif key == ord("s"):
                semantic_enabled = not semantic_enabled
                engine.reset()
            elif key == ord("c"):
                contrast_assist_enabled = not contrast_assist_enabled
            elif key == ord("d"):
                # A/B toggle: density-aware experiment vs fixed baseline
                density_aware_enabled = not density_aware_enabled
                _prev_density_scores = None  # reset temporal state
            elif key == ord("r"):
                adaptive_enabled = True
                grid_enabled = True
                semantic_enabled = True
                contrast_assist_enabled = True
                density_aware_enabled = True
                engine.reset()
                _prev_density_scores = None



    finally:
        cap.release()
        cv2.destroyAllWindows()


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Step 7+ Adaptive Visual Prosthesis Simulator")
    parser.add_argument("--no-semantic", action="store_true", help="disable semantic layer")
    parser.add_argument("--camera", type=int, default=0, help="camera index")
    args = parser.parse_args()

    selected_provider = FallbackSemanticProvider() if args.no_semantic else None
    main(provider=selected_provider, camera_index=args.camera)