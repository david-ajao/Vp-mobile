"""
1,600-Element Local Positional Steering Experiment
==================================================

This is an illustrative visualization of spatial steering applied to
virtual encoding elements. It is NOT a physiological model of cortical
electrical current flow and does NOT claim to simulate a real implanted
visual prosthesis.

MECHANISM
---------
  - Exactly 1,600 adaptive elements from prosthesis_core (unchanged).
  - Underlying territory centers and brightness are NEVER modified.
  - Steering applies a SMALL, coherent positional offset only at
    RENDER time to the phosphene centers.
  - Every phosphene stays CIRCULAR (core density-aware renderer).
  - Max displacement = STEERING_MAX_FRACTION * nearest-neighbor distance
    (default 0.15, hard-capped at 0.20).
  - No pooling, no extra elements, no ellipses, no brightness redistribution.

Controls:
  S = toggle steering ON/OFF
  Q = quit
"""

from __future__ import annotations

import typing

import cv2
import numpy as np

import prosthesis_core as core


WINDOW_BASELINE = "1,600 Adaptive - No Steering"
WINDOW_STEERED = "1,600 Adaptive + Current Steering"

# ---------------------------------------------------------------------------
# Positional steering parameters
# ---------------------------------------------------------------------------
STEERING_NEIGHBORS: int = 8
# Max move as a fraction of nearest-neighbor spacing (do not exceed 0.20)
STEERING_MAX_FRACTION: float = 0.15
# Overall gain on the steering vector before the max-fraction clamp
STEERING_GAIN: float = 1.0
# Minimum structure score to apply meaningful steering
MIN_STRUCTURE: float = 0.12
# Minimum center-to-center separation after steering (fraction of mean NN)
MIN_SEPARATION_FRAC: float = 0.35
# Temporal smoothing of the steering vector field
VECTOR_TEMPORAL_ALPHA: float = 0.70
# Spatial smoothing passes on the vector field (neighbor average)
VECTOR_SPATIAL_PASSES: int = 2

steering_enabled: bool = False

_prev_vx: typing.Optional[np.ndarray] = None
_prev_vy: typing.Optional[np.ndarray] = None


def _knn_graph(cx: np.ndarray, cy: np.ndarray, k: int) -> tuple:
    """Return (neighbor_indices [n,k], nn_distance [n], mean_nn)."""
    n = len(cx)
    if n < 2:
        return (
            np.empty((n, 0), dtype=np.int32),
            np.ones(n, dtype=np.float64),
            1.0,
        )

    pts = np.stack([cx, cy], axis=1).astype(np.float64)
    diff = pts[:, None, :] - pts[None, :, :]
    d2 = np.sum(diff * diff, axis=2)
    np.fill_diagonal(d2, np.inf)

    k_eff = min(k, n - 1)
    idx = np.argpartition(d2, k_eff, axis=1)[:, :k_eff]
    rows = np.arange(n)[:, None]
    knn_d = np.sqrt(np.maximum(d2[rows, idx], 1e-12))
    nn_dist = knn_d[:, 0]  # nearest
    mean_nn = float(np.mean(nn_dist))
    return idx.astype(np.int32), nn_dist.astype(np.float64), mean_nn


def _structure_scores(nn_dist: np.ndarray) -> np.ndarray:
    """Higher score in denser adaptive regions (smaller NN distance)."""
    inv = 1.0 / np.maximum(nn_dist, 1e-6)
    p10, p90 = np.percentile(inv, [10, 90])
    span = max(float(p90 - p10), 1e-6)
    return np.clip((inv - p10) / span, 0.0, 1.0).astype(np.float64)


def _compute_steering_field(
    cx: np.ndarray,
    cy: np.ndarray,
    scores: np.ndarray,
    neigh_idx: np.ndarray,
    nn_dist: np.ndarray,
) -> tuple:
    """
    Coherent local steering vectors (vx, vy) and magnitude map.
    Direction follows local structure / importance gradient, then
    spatially and temporally smoothed so neighbors agree.
    """
    global _prev_vx, _prev_vy

    n = len(cx)
    structure = _structure_scores(nn_dist)
    pts = np.stack([cx, cy], axis=1)
    k = neigh_idx.shape[1] if neigh_idx.size else 0

    vx = np.zeros(n, dtype=np.float64)
    vy = np.zeros(n, dtype=np.float64)

    if k == 0:
        return vx, vy, structure

    # Local gradient of importance+structure → preferred direction
    for i in range(n):
        si = structure[i]
        if si < MIN_STRUCTURE:
            continue
        acc = np.zeros(2, dtype=np.float64)
        wsum = 0.0
        for t in range(k):
            j = int(neigh_idx[i, t])
            vec = pts[j] - pts[i]
            dist = float(np.linalg.norm(vec))
            if dist < 1e-8:
                continue
            unit = vec / dist
            # Prefer neighbors with higher score/structure
            dj = 0.55 * float(np.clip(scores[j], 0.0, 1.0)) + 0.45 * structure[j]
            di = 0.55 * float(np.clip(scores[i], 0.0, 1.0)) + 0.45 * si
            # Gradient-like weight: move toward higher field
            w = max(0.0, dj - di) + 0.15 * si
            acc += unit * w
            wsum += abs(w)
        if wsum < 1e-8:
            # Fallback: mild pull toward local centroid of denser neighbors
            local = pts[neigh_idx[i]]
            centroid = local.mean(axis=0)
            vec = centroid - pts[i]
            mag = float(np.linalg.norm(vec))
            if mag > 1e-8:
                acc = vec / mag * si
                wsum = si
        if wsum > 1e-8:
            acc = acc / (np.linalg.norm(acc) + 1e-8)
            # Magnitude gated by structure
            mag = STEERING_GAIN * si
            vx[i] = acc[0] * mag
            vy[i] = acc[1] * mag

    # Spatial smoothing of the vector field (coherence)
    for _ in range(VECTOR_SPATIAL_PASSES):
        nvx = vx.copy()
        nvy = vy.copy()
        for i in range(n):
            accx, accy, wsum = vx[i], vy[i], 1.0
            for t in range(k):
                j = int(neigh_idx[i, t])
                accx += vx[j]
                accy += vy[j]
                wsum += 1.0
            nvx[i] = accx / wsum
            nvy[i] = accy / wsum
        vx, vy = nvx, nvy

    # Temporal smoothing
    if (
        _prev_vx is not None
        and _prev_vy is not None
        and _prev_vx.shape == vx.shape
    ):
        a = VECTOR_TEMPORAL_ALPHA
        vx = a * _prev_vx + (1.0 - a) * vx
        vy = a * _prev_vy + (1.0 - a) * vy
    _prev_vx = vx.copy()
    _prev_vy = vy.copy()

    return vx, vy, structure


def _apply_displacements(
    cx: np.ndarray,
    cy: np.ndarray,
    vx: np.ndarray,
    vy: np.ndarray,
    nn_dist: np.ndarray,
    mean_nn: float,
    img_h: int,
    img_w: int,
) -> tuple:
    """
    Scale vectors by local NN spacing, clamp to STEERING_MAX_FRACTION,
    enforce bounds and minimum separation. Returns (cx_s, cy_s, disp_mags).
    """
    n = len(cx)
    frac = float(np.clip(STEERING_MAX_FRACTION, 0.0, 0.20))
    max_disp = frac * nn_dist

    # Desired displacement
    dx = vx * nn_dist  # scale unit-ish field by local spacing
    dy = vy * nn_dist
    mag = np.sqrt(dx * dx + dy * dy)
    scale = np.ones(n, dtype=np.float64)
    over = mag > max_disp
    scale[over] = max_disp[over] / np.maximum(mag[over], 1e-8)
    dx *= scale
    dy *= scale

    cx_s = cx + dx
    cy_s = cy + dy

    # Image bounds
    margin = 1.0
    cx_s = np.clip(cx_s, margin, img_w - 1.0 - margin)
    cy_s = np.clip(cy_s, margin, img_h - 1.0 - margin)

    # Soft minimum-separation: if pair too close, pull halfway back to originals
    min_sep = MIN_SEPARATION_FRAC * mean_nn
    # One pass over nearest neighbor only (cheap, sufficient)
    pts = np.stack([cx_s, cy_s], axis=1)
    for i in range(n):
        # find current nearest among a few candidates from original graph is costly;
        # approximate with global check against previous indices via random subsample
        pass

    # Efficient separation: for each point, if nearest of steered set is too close,
    # shrink both displacements toward original
    # Use a coarse grid hash to limit comparisons
    cell = max(mean_nn * 0.5, 1.0)
    grid: dict = {}
    for i in range(n):
        key = (int(cx_s[i] / cell), int(cy_s[i] / cell))
        grid.setdefault(key, []).append(i)

    for i in range(n):
        gx, gy = int(cx_s[i] / cell), int(cy_s[i] / cell)
        for ox in range(-1, 2):
            for oy in range(-1, 2):
                for j in grid.get((gx + ox, gy + oy), []):
                    if j <= i:
                        continue
                    ddx = cx_s[i] - cx_s[j]
                    ddy = cy_s[i] - cy_s[j]
                    dist = float(np.hypot(ddx, ddy))
                    if dist < min_sep and dist > 1e-6:
                        # Reduce both offsets by half the deficit
                        deficit = (min_sep - dist) / 2.0
                        ux, uy = ddx / dist, ddy / dist
                        cx_s[i] += ux * deficit
                        cy_s[i] += uy * deficit
                        cx_s[j] -= ux * deficit
                        cy_s[j] -= uy * deficit

    cx_s = np.clip(cx_s, margin, img_w - 1.0 - margin)
    cy_s = np.clip(cy_s, margin, img_h - 1.0 - margin)

    disp = np.sqrt((cx_s - cx) ** 2 + (cy_s - cy) ** 2)
    return cx_s, cy_s, disp


def steer_territories_for_render(
    territories: dict,
    img_h: int,
    img_w: int,
) -> tuple:
    """
    Build a render-only copy with displaced centers.
    Original territories dict is never mutated.
    Returns (steered_dict, diagnostics).
    """
    cx = territories["cx"].astype(np.float64)
    cy = territories["cy"].astype(np.float64)
    n = len(cx)

    scores = territories.get("score")
    if scores is None:
        scores = np.ones(n, dtype=np.float64)
    else:
        scores = np.asarray(scores, dtype=np.float64)

    neigh_idx, nn_dist, mean_nn = _knn_graph(cx, cy, STEERING_NEIGHBORS)
    vx, vy, structure = _compute_steering_field(cx, cy, scores, neigh_idx, nn_dist)
    cx_s, cy_s, disp = _apply_displacements(
        cx, cy, vx, vy, nn_dist, mean_nn, img_h, img_w
    )

    meaningful = float(np.mean(disp > 0.05 * nn_dist)) * 100.0
    diag = {
        "n": n,
        "mean_disp": float(np.mean(disp)),
        "max_disp": float(np.max(disp)),
        "mean_nn": mean_nn,
        "pct_meaningful": meaningful,
        "max_frac_used": STEERING_MAX_FRACTION,
    }

    steered = {
        "cx": cx_s,
        "cy": cy_s,
        "brightness": territories["brightness"],  # unchanged
    }
    for key in ("score", "rects", "raw_brightness"):
        if key in territories:
            steered[key] = territories[key]
    return steered, diag


def validate(territories: dict) -> None:
    n = len(territories["cx"])
    if n != 1600:
        raise RuntimeError(f"Expected 1600 elements, got {n}")
    if not np.isfinite(territories["cx"]).all() or not np.isfinite(territories["cy"]).all():
        raise RuntimeError("Non-finite coordinates")
    if not np.isfinite(territories["brightness"]).all():
        raise RuntimeError("Non-finite brightness")
    print(f"[VALIDATE] n={n}  OK")


def main() -> None:
    global steering_enabled, _prev_vx, _prev_vy

    print("=" * 60)
    print("1,600-ELEMENT LOCAL POSITIONAL STEERING")
    print("=" * 60)
    print("  Centers offset at render-time only (underlying fixed)")
    print("  Circles only | Brightness unchanged | No extra elements")
    print(f"  STEERING_MAX_FRACTION = {STEERING_MAX_FRACTION}  (cap 0.20)")
    print("  S = toggle   Q = quit")
    print("=" * 60)

    try:
        provider = core.YOLOSemanticProvider("yolo11n-seg.pt")
        semantic_active = True
        print("[INFO] YOLO semantic provider: ACTIVE")
    except Exception as error:
        print(f"[WARNING] YOLO failed: {error}")
        provider = core.FallbackSemanticProvider()
        semantic_active = False
        print("[INFO] Fallback semantic mode")

    cap = core.open_camera()
    engine = core.ImportanceEngine()
    detections: list = []
    frame_index = 0
    validated_once = False
    last_diag = None

    try:
        while True:
            ret, frame = cap.read()
            if not ret or frame is None or frame.size == 0:
                print("[ERROR] Camera frame unavailable")
                break

            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            img_h, img_w = gray.shape

            if semantic_active and frame_index % core.SEMANTIC_EVERY_N_FRAMES == 0:
                detections = provider.detect(frame)
            frame_index += 1

            # Core encoding — never modified
            _imp, territories, _dbg = core.encode_frame(
                gray, engine, detections, semantic_active, adaptive=True
            )

            if not validated_once:
                validate(territories)
                validated_once = True

            # Snapshot underlying geometry + brightness
            cx0 = territories["cx"].copy()
            cy0 = territories["cy"].copy()
            b0 = territories["brightness"].copy()

            baseline = core.render_phosphenes(territories, gray.shape)

            if steering_enabled:
                steered_t, diag = steer_territories_for_render(
                    territories, img_h, img_w
                )
                last_diag = diag
                steered = core.render_phosphenes(steered_t, gray.shape)
            else:
                steered = baseline.copy()
                _prev_vx = _prev_vy = None

            # Underlying encoding must remain identical
            assert np.allclose(territories["cx"], cx0)
            assert np.allclose(territories["cy"], cy0)
            assert np.allclose(territories["brightness"], b0)

            cv2.putText(
                baseline, "1,600 ELEMENTS - BASELINE",
                (15, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.65, 255, 2, cv2.LINE_AA
            )
            status = "ON" if steering_enabled else "OFF"
            cv2.putText(
                steered, f"1,600 ELEMENTS - STEERING {status}",
                (15, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.65, 255, 2, cv2.LINE_AA
            )
            if steering_enabled and last_diag is not None:
                d = last_diag
                msg = (
                    f"n={d['n']}  mean_disp={d['mean_disp']:.2f}px  "
                    f"max_disp={d['max_disp']:.2f}px  "
                    f"steered={d['pct_meaningful']:.0f}%  "
                    f"frac={d['max_frac_used']:.2f}"
                )
                cv2.putText(
                    steered, msg,
                    (15, 58), cv2.FONT_HERSHEY_SIMPLEX, 0.42, 200, 1, cv2.LINE_AA
                )
            cv2.putText(
                steered, "S = toggle | Q = quit",
                (15, 82), cv2.FONT_HERSHEY_SIMPLEX, 0.5, 180, 1, cv2.LINE_AA
            )

            cv2.imshow(WINDOW_BASELINE, baseline)
            cv2.imshow(WINDOW_STEERED, steered)

            key = cv2.waitKey(1) & 0xFF
            if key == ord("q"):
                break
            elif key == ord("s"):
                steering_enabled = not steering_enabled
                _prev_vx = _prev_vy = None
                print(f"[INFO] Steering: {'ON' if steering_enabled else 'OFF'}")
                if last_diag and steering_enabled:
                    print(
                        f"  mean_disp={last_diag['mean_disp']:.2f}  "
                        f"max_disp={last_diag['max_disp']:.2f}  "
                        f"pct={last_diag['pct_meaningful']:.1f}%"
                    )

    finally:
        cap.release()
        cv2.destroyAllWindows()


if __name__ == "__main__":
    main()