/**
 * Density-aware circular PSF renderer.
 *
 * Port of prosthesis_core.render_phosphenes:
 *   - Sparse regions keep a near-baseline radius (background coherence).
 *   - Dense regions receive a modestly smaller radius (separability).
 *   - Variation is continuous and tightly bounded.
 *   - Brightness values come unchanged from the encoding stage.
 *   - Phosphenes are CIRCLES. No ellipses, no cells, no photographic reconstruct.
 */

import {
  DENSITY_KNN,
  DENSITY_SMOOTH_ALPHA,
  GRID_COLS,
  PHOSPHENE_BASE_RADIUS,
  PHOSPHENE_BLUR_SIGMA,
  PHOSPHENE_RADIUS_MAX,
  PHOSPHENE_RADIUS_MIN,
  TOTAL_ELEMENTS,
} from "./constants";
import { SpatialKnn } from "./knn";

const N = TOTAL_ELEMENTS;

export class PhospheneRenderer {
  private size = 512;
  private buf: Float32Array = new Float32Array(512 * 512);
  private tmp: Float32Array = new Float32Array(512 * 512);
  private scratch: Float32Array = new Float32Array(512 * 512);
  private image: ImageData | null = null;
  private readonly density = new Float32Array(N);
  private readonly prevDensity = new Float32Array(N);
  private hasPrevDensity = false;
  private readonly knn = new SpatialKnn(N + 8);
  private readonly knnIdx = new Int32Array(N * DENSITY_KNN);
  private readonly knnDist = new Float32Array(N * DENSITY_KNN);
  private readonly outCx = new Float64Array(N);
  private readonly outCy = new Float64Array(N);

  resetDensity(): void {
    this.hasPrevDensity = false;
  }

  ensureSize(size: number): void {
    const s = Math.max(320, Math.min(512, size | 0));
    if (s === this.size && this.image) return;
    this.size = s;
    const n = s * s;
    this.buf = new Float32Array(n);
    this.tmp = new Float32Array(n);
    this.scratch = new Float32Array(n);
    this.image = new ImageData(s, s);
  }

  get outputSize(): number {
    return this.size;
  }

  render(
    cx: Float64Array,
    cy: Float64Array,
    brightness: Float32Array,
    n: number,
    imgW: number,
    imgH: number,
    densityAware: boolean,
    ctx: CanvasRenderingContext2D,
  ): void {
    const size = ctx.canvas.width || this.size;
    this.ensureSize(size);
    const spacing = size / GRID_COLS;
    const sx = size / imgW;
    const sy = size / imgH;
    const buf = this.buf;
    buf.fill(0);

    for (let i = 0; i < n; i++) {
      this.outCx[i] = cx[i] * sx;
      this.outCy[i] = cy[i] * sy;
    }

    // Density-aware radii, scaled to the output lattice. Floored so
    // phosphenes stay readable on a phone-sized canvas.
    const rMin = Math.max(4.2, spacing * (PHOSPHENE_RADIUS_MIN / 20));
    const rMax = Math.max(6.6, spacing * (PHOSPHENE_RADIUS_MAX / 20) * 1.35);
    const rBase = Math.max(5.4, spacing * (PHOSPHENE_BASE_RADIUS / 20) * 1.25);

    if (densityAware && n > 8) {
      this.knn.build(this.outCx, this.outCy, n);
      this.knn.query(this.outCx, this.outCy, n, DENSITY_KNN, this.knnIdx, this.knnDist);
      // Convert mean kNN distance → density score
      const meanD = this.tmp; // reuse prefix
      for (let i = 0; i < n; i++) {
        let s = 0;
        const base = i * DENSITY_KNN;
        for (let t = 0; t < DENSITY_KNN; t++) s += this.knnDist[base + t];
        meanD[i] = s / DENSITY_KNN;
      }
      const sorted = Array.from(meanD.subarray(0, n)).sort((a, b) => a - b);
      const p10 = sorted[(n * 0.1) | 0] ?? 0;
      const p90 = sorted[(n * 0.9) | 0] ?? 1;
      const span = Math.max(p90 - p10, 1e-3);
      const dens = this.density;
      for (let i = 0; i < n; i++) {
        let d = 1 - (meanD[i] - p10) / span;
        if (d < 0) d = 0;
        else if (d > 1) d = 1;
        dens[i] = d;
      }
      if (this.hasPrevDensity) {
        const a = DENSITY_SMOOTH_ALPHA;
        for (let i = 0; i < n; i++) {
          dens[i] = a * this.prevDensity[i] + (1 - a) * dens[i];
        }
      }
      this.prevDensity.set(dens.subarray(0, n));
      this.hasPrevDensity = true;

      for (let i = 0; i < n; i++) {
        let r = rMax - dens[i] * (rMax - rMin);
        if (r < rMin) r = rMin;
        else if (r > rMax) r = rMax;
        this.stamp(buf, size, this.outCx[i], this.outCy[i], r, brightness[i] / 255);
      }
    } else {
      this.hasPrevDensity = false;
      for (let i = 0; i < n; i++) {
        this.stamp(buf, size, this.outCx[i], this.outCy[i], rBase, brightness[i] / 255);
      }
    }

    const blurR = Math.max(2, Math.round(PHOSPHENE_BLUR_SIGMA * (size / 512)));
    this.boxBlurGray(buf, this.scratch, this.tmp, size, size, blurR);
    this.boxBlurGray(this.scratch, buf, this.tmp, size, size, blurR);

    const image = this.image!;
    const px = image.data;
    // Uniform display gain — does not change relative encoding brightness.
    const gain = 1.45;
    for (let i = 0, p = 0; i < buf.length; i++, p += 4) {
      let v = buf[i] * 255 * gain;
      if (v < 0) v = 0;
      else if (v > 255) v = 255;
      const u = v | 0;
      px[p] = u;
      px[p + 1] = u;
      px[p + 2] = u;
      px[p + 3] = 255;
    }
    ctx.putImageData(image, 0, 0);
  }

  private stamp(
    buf: Float32Array,
    size: number,
    cx: number,
    cy: number,
    radius: number,
    val: number,
  ): void {
    const r = Math.max(1, radius);
    const r2 = r * r;
    const x0 = Math.max(0, Math.floor(cx - r));
    const x1 = Math.min(size - 1, Math.ceil(cx + r));
    const y0 = Math.max(0, Math.floor(cy - r));
    const y1 = Math.min(size - 1, Math.ceil(cy + r));
    for (let y = y0; y <= y1; y++) {
      const dy = y - cy;
      const row = y * size;
      for (let x = x0; x <= x1; x++) {
        const dx = x - cx;
        if (dx * dx + dy * dy <= r2) {
          buf[row + x] = val;
        }
      }
    }
  }

  private boxBlurGray(
    src: Float32Array,
    dst: Float32Array,
    tmp: Float32Array,
    w: number,
    h: number,
    radius: number,
  ): void {
    const r = Math.max(1, radius | 0);
    const win = 2 * r + 1;
    const inv = 1 / win;
    for (let y = 0; y < h; y++) {
      const row = y * w;
      let sum = 0;
      for (let x = -r; x <= r; x++) {
        const xx = x < 0 ? 0 : x >= w ? w - 1 : x;
        sum += src[row + xx];
      }
      for (let x = 0; x < w; x++) {
        tmp[row + x] = sum * inv;
        const add = x + r + 1 >= w ? w - 1 : x + r + 1;
        const sub = x - r < 0 ? 0 : x - r;
        sum += src[row + add] - src[row + sub];
      }
    }
    for (let x = 0; x < w; x++) {
      let sum = 0;
      for (let y = -r; y <= r; y++) {
        const yy = y < 0 ? 0 : y >= h ? h - 1 : y;
        sum += tmp[yy * w + x];
      }
      for (let y = 0; y < h; y++) {
        dst[y * w + x] = sum * inv;
        const add = y + r + 1 >= h ? h - 1 : y + r + 1;
        const sub = y - r < 0 ? 0 : y - r;
        sum += tmp[add * w + x] - tmp[sub * w + x];
      }
    }
  }
}
