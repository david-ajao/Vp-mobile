/**
 * Spatial-hash k-nearest neighbors for 1,600 points.
 * Replaces the O(n²) pairwise matrices in the Python prototype so the
 * mobile build can hold 20–30 FPS. Results are equivalent for local k.
 */

const HASH_BINS = 64;

export class SpatialKnn {
  private readonly heads = new Int32Array(HASH_BINS * HASH_BINS);
  private readonly next: Int32Array;
  private readonly cap: number;
  private cell = 8;
  private originX = 0;
  private originY = 0;
  private cols = HASH_BINS;
  private rows = HASH_BINS;

  constructor(cap: number) {
    this.cap = cap;
    this.next = new Int32Array(cap);
  }

  build(cx: Float64Array, cy: Float64Array, n: number): void {
    let minX = Infinity;
    let minY = Infinity;
    let maxX = -Infinity;
    let maxY = -Infinity;
    for (let i = 0; i < n; i++) {
      const x = cx[i];
      const y = cy[i];
      if (x < minX) minX = x;
      if (y < minY) minY = y;
      if (x > maxX) maxX = x;
      if (y > maxY) maxY = y;
    }
    const spanX = Math.max(1, maxX - minX);
    const spanY = Math.max(1, maxY - minY);
    this.cell = Math.max(4, Math.sqrt((spanX * spanY) / Math.max(1, n)));
    this.originX = minX;
    this.originY = minY;
    this.cols = Math.min(HASH_BINS, Math.max(4, Math.ceil(spanX / this.cell) + 1));
    this.rows = Math.min(HASH_BINS, Math.max(4, Math.ceil(spanY / this.cell) + 1));
    this.heads.fill(-1);
    for (let i = 0; i < n; i++) {
      const gx = this.binX(cx[i]);
      const gy = this.binY(cy[i]);
      const b = gy * this.cols + gx;
      this.next[i] = this.heads[b];
      this.heads[b] = i;
    }
  }

  /**
   * Fill idxOut[i*k + t] and distOut[i*k + t] with the t-th nearest neighbor
   * of i (sorted by distance, excluding self). Returns mean nearest-neighbor
   * distance.
   */
  query(
    cx: Float64Array,
    cy: Float64Array,
    n: number,
    k: number,
    idxOut: Int32Array,
    distOut: Float32Array,
  ): number {
    const kEff = Math.min(k, Math.max(0, n - 1));
    let nnSum = 0;
    const candIdx = this._candIdx;
    const candD = this._candD;

    for (let i = 0; i < n; i++) {
      const x = cx[i];
      const y = cy[i];
      let count = 0;
      const gx = this.binX(x);
      const gy = this.binY(y);
      // Expand ring until we have plenty of candidates
      for (let ring = 1; ring <= 6 && count < kEff * 4; ring++) {
        const x0 = Math.max(0, gx - ring);
        const x1 = Math.min(this.cols - 1, gx + ring);
        const y0 = Math.max(0, gy - ring);
        const y1 = Math.min(this.rows - 1, gy + ring);
        for (let by = y0; by <= y1; by++) {
          for (let bx = x0; bx <= x1; bx++) {
            if (ring > 1) {
              const interior =
                bx > x0 && bx < x1 && by > y0 && by < y1 &&
                bx >= gx - (ring - 1) && bx <= gx + (ring - 1) &&
                by >= gy - (ring - 1) && by <= gy + (ring - 1);
              if (interior) continue;
            }
            let t = this.heads[by * this.cols + bx];
            while (t !== -1) {
              if (t !== i && count < candIdx.length) {
                const dx = cx[t] - x;
                const dy = cy[t] - y;
                candIdx[count] = t;
                candD[count] = dx * dx + dy * dy;
                count++;
              }
              t = this.next[t];
            }
          }
        }
      }

      const take = Math.min(kEff, count);
      // Partial sort of the `take` smallest distances
      for (let a = 0; a < take; a++) {
        let minI = a;
        for (let b = a + 1; b < count; b++) {
          if (candD[b] < candD[minI]) minI = b;
        }
        if (minI !== a) {
          const td = candD[a];
          candD[a] = candD[minI];
          candD[minI] = td;
          const ti = candIdx[a];
          candIdx[a] = candIdx[minI];
          candIdx[minI] = ti;
        }
      }

      const base = i * k;
      for (let t = 0; t < k; t++) {
        if (t < take) {
          idxOut[base + t] = candIdx[t];
          distOut[base + t] = Math.sqrt(Math.max(candD[t], 1e-12));
        } else {
          idxOut[base + t] = i;
          distOut[base + t] = 1;
        }
      }
      nnSum += distOut[base];
    }
    return n > 0 ? nnSum / n : 1;
  }

  private readonly _candIdx = new Int32Array(256);
  private readonly _candD = new Float32Array(256);

  private binX(x: number): number {
    const v = ((x - this.originX) / this.cell) | 0;
    return v < 0 ? 0 : v >= this.cols ? this.cols - 1 : v;
  }
  private binY(y: number): number {
    const v = ((y - this.originY) / this.cell) | 0;
    return v < 0 ? 0 : v >= this.rows ? this.rows - 1 : v;
  }
}
