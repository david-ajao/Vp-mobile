/**
 * Lightweight image operators replacing OpenCV for the mobile build.
 * All buffers are preallocated by the caller — no per-frame allocs here.
 */

export function rgbaToGray(
  rgba: Uint8ClampedArray,
  gray: Float32Array,
  n: number,
): void {
  for (let i = 0, p = 0; i < n; i++, p += 4) {
    gray[i] = 0.299 * rgba[p] + 0.587 * rgba[p + 1] + 0.114 * rgba[p + 2];
  }
}

export function downsampleArea(
  src: Float32Array,
  sw: number,
  sh: number,
  dst: Float32Array,
  dw: number,
  dh: number,
): void {
  const xRatio = sw / dw;
  const yRatio = sh / dh;
  for (let y = 0; y < dh; y++) {
    const y0 = (y * yRatio) | 0;
    const y1 = Math.min(sh, Math.ceil((y + 1) * yRatio));
    for (let x = 0; x < dw; x++) {
      const x0 = (x * xRatio) | 0;
      const x1 = Math.min(sw, Math.ceil((x + 1) * xRatio));
      let sum = 0;
      let count = 0;
      for (let yy = y0; yy < y1; yy++) {
        const row = yy * sw;
        for (let xx = x0; xx < x1; xx++) {
          sum += src[row + xx];
          count++;
        }
      }
      dst[y * dw + x] = count ? sum / count : 0;
    }
  }
}

export function upsampleBilinear(
  src: Float32Array,
  sw: number,
  sh: number,
  dst: Float32Array,
  dw: number,
  dh: number,
): void {
  const xRatio = (sw - 1) / Math.max(1, dw - 1);
  const yRatio = (sh - 1) / Math.max(1, dh - 1);
  for (let y = 0; y < dh; y++) {
    const fy = y * yRatio;
    const y0 = fy | 0;
    const y1 = Math.min(sh - 1, y0 + 1);
    const ty = fy - y0;
    for (let x = 0; x < dw; x++) {
      const fx = x * xRatio;
      const x0 = fx | 0;
      const x1 = Math.min(sw - 1, x0 + 1);
      const tx = fx - x0;
      const a = src[y0 * sw + x0];
      const b = src[y0 * sw + x1];
      const c = src[y1 * sw + x0];
      const d = src[y1 * sw + x1];
      dst[y * dw + x] =
        a * (1 - tx) * (1 - ty) +
        b * tx * (1 - ty) +
        c * (1 - tx) * ty +
        d * tx * ty;
    }
  }
}

export function buildIntegral(
  src: Float32Array,
  w: number,
  h: number,
  out: Float64Array,
): void {
  const iw = w + 1;
  out.fill(0);
  for (let y = 0; y < h; y++) {
    let rowSum = 0;
    const srcRow = y * w;
    const dstRow = (y + 1) * iw;
    const prevRow = y * iw;
    for (let x = 0; x < w; x++) {
      rowSum += src[srcRow + x];
      out[dstRow + x + 1] = out[prevRow + x + 1] + rowSum;
    }
  }
}

export function rectSum(
  integral: Float64Array,
  iw: number,
  x: number,
  y: number,
  w: number,
  h: number,
): number {
  return (
    integral[(y + h) * iw + (x + w)] -
    integral[y * iw + (x + w)] -
    integral[(y + h) * iw + x] +
    integral[y * iw + x]
  );
}

export function rectMean(
  integral: Float64Array,
  iw: number,
  x: number,
  y: number,
  w: number,
  h: number,
): number {
  const area = w * h;
  if (area <= 0) return 0;
  return rectSum(integral, iw, x, y, w, h) / area;
}

/** Separable box blur. `radius` is half-width of the window. */
export function boxBlur(
  src: Float32Array,
  dst: Float32Array,
  tmp: Float32Array,
  w: number,
  h: number,
  radius: number,
): void {
  const r = Math.max(1, radius | 0);
  const win = 2 * r + 1;
  const inv = 1 / win;

  for (let y = 0; y < h; y++) {
    const row = y * w;
    let sum = 0;
    for (let x = -r; x <= r; x++) {
      const xx = x < 0 ? 0 : x >= w ? w - 1 : x;
      sum += src[row + xx];
    }
    for (let x = 0; x < w; x++) {
      tmp[row + x] = sum * inv;
      const add = x + r + 1;
      const sub = x - r;
      const a = add >= w ? w - 1 : add;
      const s = sub < 0 ? 0 : sub;
      sum += src[row + a] - src[row + s];
    }
  }

  for (let x = 0; x < w; x++) {
    let sum = 0;
    for (let y = -r; y <= r; y++) {
      const yy = y < 0 ? 0 : y >= h ? h - 1 : y;
      sum += tmp[yy * w + x];
    }
    for (let y = 0; y < h; y++) {
      dst[y * w + x] = sum * inv;
      const add = y + r + 1;
      const sub = y - r;
      const a = add >= h ? h - 1 : add;
      const s = sub < 0 ? 0 : sub;
      sum += tmp[a * w + x] - tmp[s * w + x];
    }
  }
}

/**
 * Two-pass box blur ≈ Gaussian with sigma ≈ radius / 0.886.
 * Matches the desktop pipeline's GaussianBlur well enough at analysis res.
 */
export function gaussianBlurApprox(
  src: Float32Array,
  dst: Float32Array,
  tmp: Float32Array,
  scratch: Float32Array,
  w: number,
  h: number,
  sigma: number,
): void {
  const radius = Math.max(1, Math.round(sigma * 0.9));
  boxBlur(src, scratch, tmp, w, h, radius);
  boxBlur(scratch, dst, tmp, w, h, radius);
}

export function sobelMagnitude(
  src: Float32Array,
  dst: Float32Array,
  w: number,
  h: number,
): void {
  for (let y = 0; y < h; y++) {
    const ym = y === 0 ? 0 : y - 1;
    const yp = y === h - 1 ? h - 1 : y + 1;
    for (let x = 0; x < w; x++) {
      const xm = x === 0 ? 0 : x - 1;
      const xp = x === w - 1 ? w - 1 : x + 1;
      const p00 = src[ym * w + xm];
      const p01 = src[ym * w + x];
      const p02 = src[ym * w + xp];
      const p10 = src[y * w + xm];
      const p12 = src[y * w + xp];
      const p20 = src[yp * w + xm];
      const p21 = src[yp * w + x];
      const p22 = src[yp * w + xp];
      const gx = -p00 + p02 - 2 * p10 + 2 * p12 - p20 + p22;
      const gy = -p00 - 2 * p01 - p02 + p20 + 2 * p21 + p22;
      dst[y * w + x] = Math.sqrt(gx * gx + gy * gy);
    }
  }
}

/** Mixed partial d²/dxdy — stand-in for OpenCV Sobel(dx=1, dy=1). */
export function mixedDerivative(
  src: Float32Array,
  dst: Float32Array,
  w: number,
  h: number,
): void {
  for (let y = 0; y < h; y++) {
    const ym = y === 0 ? 0 : y - 1;
    const yp = y === h - 1 ? h - 1 : y + 1;
    for (let x = 0; x < w; x++) {
      const xm = x === 0 ? 0 : x - 1;
      const xp = x === w - 1 ? w - 1 : x + 1;
      dst[y * w + x] = Math.abs(
        src[yp * w + xp] - src[yp * w + xm] - src[ym * w + xp] + src[ym * w + xm],
      );
    }
  }
}

export function histogramMedian255(src: Float32Array, n: number): number {
  const bins = new Int32Array(256);
  for (let i = 0; i < n; i++) {
    let v = src[i] | 0;
    if (v < 0) v = 0;
    else if (v > 255) v = 255;
    bins[v]++;
  }
  const mid = n >> 1;
  let acc = 0;
  for (let i = 0; i < 256; i++) {
    acc += bins[i];
    if (acc >= mid) return i;
  }
  return 128;
}

export function clip01(v: number): number {
  return v < 0 ? 0 : v > 1 ? 1 : v;
}

export function fillMul(
  src: Float32Array,
  dst: Float32Array,
  n: number,
  scale: number,
): void {
  for (let i = 0; i < n; i++) dst[i] = src[i] * scale;
}

export function squareInto(
  src: Float32Array,
  dst: Float32Array,
  n: number,
): void {
  for (let i = 0; i < n; i++) dst[i] = src[i] * src[i];
}
