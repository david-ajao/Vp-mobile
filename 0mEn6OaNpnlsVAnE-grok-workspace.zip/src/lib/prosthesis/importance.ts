/**
 * MOBILE IMPORTANCE DETECTOR
 * --------------------------
 * Browser approximation of desktop ImportanceEngine (prosthesis_core.py).
 *
 * Desktop fuses four maps:
 *   semantic (YOLO seg) 0.35 + detail 0.25 + saliency 0.20 + context 0.20
 *
 * This mobile build does NOT run YOLO / Ultralytics / any neural net.
 * Semantic weight is dropped and the remaining three maps are renormalized,
 * matching the desktop `--no-semantic` / fallback path:
 *   detail, saliency (DoG + global contrast), context (structure + variance).
 *
 * To plug in a more sophisticated model later, replace `compute()` so it
 * still returns a Float32Array of length CAPTURE_SIZE² in
 * [importanceFloor(), 1]. Territory allocation and steering will pick it up
 * without further changes.
 */

import {
  ANALYSIS_SIZE,
  CAPTURE_SIZE,
  CONTEXT_WEIGHT,
  DETAIL_WEIGHT,
  IMPORTANCE_SMOOTH_SIGMA,
  IMPORTANCE_TEMPORAL_ALPHA,
  MAX_IMPORTANCE,
  SALIENCY_WEIGHT,
  importanceFloor,
} from "./constants";
import {
  clip01,
  downsampleArea,
  gaussianBlurApprox,
  histogramMedian255,
  mixedDerivative,
  sobelMagnitude,
  squareInto,
  upsampleBilinear,
} from "./image-ops";

const AW = ANALYSIS_SIZE;
const AH = ANALYSIS_SIZE;
const AN = AW * AH;
const CW = CAPTURE_SIZE;
const CH = CAPTURE_SIZE;
const CN = CW * CH;

export class ImportanceEngine {
  private readonly analysis = new Float32Array(AN);
  private readonly detail = new Float32Array(AN);
  private readonly saliency = new Float32Array(AN);
  private readonly context = new Float32Array(AN);
  private readonly combined = new Float32Array(AN);
  private readonly full = new Float32Array(CN);

  private readonly tmpA = new Float32Array(AN);
  private readonly tmpB = new Float32Array(AN);
  private readonly tmpC = new Float32Array(AN);
  private readonly tmpD = new Float32Array(AN);

  private previous: Float32Array | null = null;
  private readonly prevBuf = new Float32Array(AN);

  reset(): void {
    this.previous = null;
  }

  /**
   * @param gray Capture-resolution luminance, 0–255, length CAPTURE_SIZE²
   * @returns Full-resolution importance map, length CAPTURE_SIZE²
   */
  compute(gray: Float32Array, useTemporal = true): Float32Array {
    downsampleArea(gray, CW, CH, this.analysis, AW, AH);

    this.computeDetail(this.analysis, this.detail);
    this.computeSaliency(this.analysis, this.saliency);
    this.computeContext(this.analysis, this.context);

    const floor = importanceFloor();
    const wDet = DETAIL_WEIGHT;
    const wSal = SALIENCY_WEIGHT;
    const wCtx = CONTEXT_WEIGHT;
    const total = wDet + wSal + wCtx;

    const det = this.detail;
    const sal = this.saliency;
    const ctx = this.context;
    const comb = this.combined;
    for (let i = 0; i < AN; i++) {
      comb[i] = (wDet * det[i] + wSal * sal[i] + wCtx * ctx[i]) / total;
    }

    gaussianBlurApprox(
      comb,
      comb,
      this.tmpA,
      this.tmpB,
      AW,
      AH,
      IMPORTANCE_SMOOTH_SIGMA,
    );

    for (let i = 0; i < AN; i++) {
      const v = comb[i];
      comb[i] = v < floor ? floor : v > MAX_IMPORTANCE ? MAX_IMPORTANCE : v;
    }

    if (useTemporal && this.previous) {
      const a = IMPORTANCE_TEMPORAL_ALPHA;
      const prev = this.previous;
      for (let i = 0; i < AN; i++) {
        comb[i] = a * prev[i] + (1 - a) * comb[i];
      }
    }
    this.prevBuf.set(comb);
    this.previous = this.prevBuf;

    upsampleBilinear(comb, AW, AH, this.full, CW, CH);
    for (let i = 0; i < CN; i++) {
      const v = this.full[i];
      this.full[i] = v < floor ? floor : v > MAX_IMPORTANCE ? MAX_IMPORTANCE : v;
    }
    return this.full;
  }

  private computeDetail(img: Float32Array, out: Float32Array): void {
    const sigmas = [1.2, 3.0, 6.0];
    const refs = [300.0, 180.0, 90.0];
    const weights = [0.5, 0.3, 0.2];
    out.fill(0);
    for (let k = 0; k < 3; k++) {
      gaussianBlurApprox(img, this.tmpC, this.tmpA, this.tmpB, AW, AH, sigmas[k]);
      sobelMagnitude(this.tmpC, this.tmpD, AW, AH);
      const inv = 1 / refs[k];
      const w = weights[k];
      for (let i = 0; i < AN; i++) {
        const v = this.tmpD[i] * inv;
        out[i] += w * (v < 0 ? 0 : v > 1 ? 1 : v);
      }
    }
    for (let i = 0; i < AN; i++) out[i] = clip01(out[i]);
  }

  private computeSaliency(img: Float32Array, out: Float32Array): void {
    gaussianBlurApprox(img, this.tmpC, this.tmpA, this.tmpB, AW, AH, 2.0);
    gaussianBlurApprox(img, this.tmpD, this.tmpA, this.tmpB, AW, AH, 14.0);
    const median = histogramMedian255(img, AN);
    gaussianBlurApprox(img, this.tmpA, this.tmpB, out, AW, AH, 8.0);
    // tmpA is regional (gauss 8). out was used as scratch — recompute into out.
    for (let i = 0; i < AN; i++) {
      const dog = clip01(Math.abs(this.tmpC[i] - this.tmpD[i]) / 40);
      const globalC = clip01(Math.abs(this.tmpA[i] - median) / 60);
      out[i] = clip01(0.6 * dog + 0.4 * globalC);
    }
  }

  private computeContext(img: Float32Array, out: Float32Array): void {
    gaussianBlurApprox(img, this.tmpC, this.tmpA, this.tmpB, AW, AH, 16.0);
    mixedDerivative(this.tmpC, this.tmpD, AW, AH);

    squareInto(img, this.tmpA, AN);
    gaussianBlurApprox(this.tmpA, this.tmpB, this.tmpC, out, AW, AH, 12.0);
    gaussianBlurApprox(img, this.tmpA, this.tmpC, out, AW, AH, 12.0);

    for (let i = 0; i < AN; i++) {
      const ctxStruct = clip01(this.tmpD[i] / 50);
      const varApprox = this.tmpB[i] - this.tmpA[i] * this.tmpA[i];
      const std = Math.sqrt(varApprox > 0 ? varApprox : 0);
      const ctxCont = clip01(std / 40);
      out[i] = clip01(0.5 * ctxStruct + 0.5 * ctxCont);
    }
  }
}
