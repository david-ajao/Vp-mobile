/**
 * Adaptive 1,600-element visual prosthesis — constants.
 *
 * Source of truth: the desktop prototype (prosthesis_core.py +
 * current_steering_standalone.py). Names and values are preserved so a later
 * model swap can map 1:1 onto the Python architecture.
 *
 * SCIENTIFIC DISCLAIMER:
 * The 1,600 elements represent VIRTUAL spatial sampling / encoding
 * territories. They are NOT physical electrodes, NOT TMS coils, and this
 * is NOT a simulation of cortical stimulation or physiological neural
 * activity.
 */

export const GRID_COLS = 40;
export const GRID_ROWS = 40;
export const TOTAL_ELEMENTS = GRID_COLS * GRID_ROWS; // exactly 1,600

/** Internal capture / encoding resolution (square). */
export const CAPTURE_SIZE = 320;

/** Importance maps run at half capture res, matching ANALYSIS_SCALE = 0.5. */
export const ANALYSIS_SIZE = 160;

export const SEMANTIC_WEIGHT = 0.35;
export const DETAIL_WEIGHT = 0.25;
export const SALIENCY_WEIGHT = 0.2;
export const CONTEXT_WEIGHT = 0.2;

/**
 * Mobile build does not run YOLO. Semantic weight is folded into the
 * remaining maps (see importance.ts). Kept here for a future model swap.
 */
export const MOBILE_HAS_SEMANTIC = false;

export const MIN_IMPORTANCE = 0.05;
export const MAX_IMPORTANCE = 1.0;
export const MAX_RESOLUTION_RATIO = 8.0;
export const ALLOCATION_EXPONENT = 1.5;
export const MIN_TERRITORY_SIZE = 4;
export const MAX_TERRITORY_FRACTION = 0.125;

export const BACKGROUND_TARGET = 0.2;
export const BACKGROUND_MIN = 0.15;
export const BACKGROUND_MAX = 0.25;

export const TARGET_CONTEXT_COUNT = Math.trunc(TOTAL_ELEMENTS * BACKGROUND_TARGET); // 320
export const MIN_CONTEXT_COUNT = Math.trunc(TOTAL_ELEMENTS * BACKGROUND_MIN); // 240
export const MAX_CONTEXT_COUNT = Math.trunc(TOTAL_ELEMENTS * BACKGROUND_MAX); // 400

export const HIGH_IMPORTANCE_THRESHOLD = 0.45;
export const LOW_IMPORTANCE_THRESHOLD = 0.2;

export const CONTRAST_ASSIST_ALPHA = 0.08;
export const MAX_CONTRAST_GAIN = 1.25;
export const MAX_BRIGHTNESS_DELTA = 0.12;
export const LOCAL_LUMINANCE_SIGMA = 15.0;

export const IMPORTANCE_SMOOTH_SIGMA = 3.0;
export const IMPORTANCE_TEMPORAL_ALPHA = 0.75;

export function importanceFloor(): number {
  return Math.max(MIN_IMPORTANCE, MAX_IMPORTANCE / MAX_RESOLUTION_RATIO);
}

// ---- Density-aware PSF (render-time only) ----
export const PHOSPHENE_BASE_RADIUS = 5.5;
export const PHOSPHENE_BLUR_SIGMA = 2.5;
export const PHOSPHENE_RADIUS_MIN = 3.8;
export const PHOSPHENE_RADIUS_MAX = 6.2;
export const DENSITY_KNN = 6;
export const DENSITY_SMOOTH_ALPHA = 0.65;
export const PYTHON_OUTPUT_SIZE = 800;

// ---- Positional steering (render-time only) ----
export const STEERING_NEIGHBORS = 8;
export const STEERING_MAX_FRACTION_DEFAULT = 0.15;
export const STEERING_MAX_FRACTION_CAP = 0.2;
export const STEERING_GAIN = 1.0;
export const MIN_STRUCTURE = 0.12;
export const MIN_SEPARATION_FRAC = 0.35;
export const VECTOR_TEMPORAL_ALPHA = 0.7;
export const VECTOR_SPATIAL_PASSES = 2;
