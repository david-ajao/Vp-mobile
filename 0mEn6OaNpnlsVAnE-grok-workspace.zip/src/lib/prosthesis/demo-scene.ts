/**
 * Animated synthetic scene so the simulator is usable without a camera
 * (preview, permission-denied, desktop browsers without a device).
 *
 * Designed so adaptive allocation is obvious: a walking figure with
 * high-frequency clothing in front of a relatively uniform wall, plus a
 * window with blinds (detail) and simple furniture (medium).
 */

import { CAPTURE_SIZE } from "./constants";

const W = CAPTURE_SIZE;
const H = CAPTURE_SIZE;

function hash2(x: number, y: number): number {
  let n = Math.imul(x | 0, 374761393) + Math.imul(y | 0, 668265263);
  n = Math.imul(n ^ (n >>> 13), 1274126177);
  return ((n ^ (n >>> 16)) >>> 0) / 4294967296;
}

function vnoise(x: number, y: number): number {
  const x0 = Math.floor(x);
  const y0 = Math.floor(y);
  const fx = x - x0;
  const fy = y - y0;
  const ux = fx * fx * (3 - 2 * fx);
  const uy = fy * fy * (3 - 2 * fy);
  const a = hash2(x0, y0);
  const b = hash2(x0 + 1, y0);
  const c = hash2(x0, y0 + 1);
  const d = hash2(x0 + 1, y0 + 1);
  return a + (b - a) * ux + (c - a) * uy + (a - b - c + d) * ux * uy;
}

function fillRect(
  gray: Float32Array,
  x0: number,
  y0: number,
  x1: number,
  y1: number,
  value: number,
  texture = 0,
): void {
  const xa = Math.max(0, Math.floor(x0));
  const xb = Math.min(W, Math.ceil(x1));
  const ya = Math.max(0, Math.floor(y0));
  const yb = Math.min(H, Math.ceil(y1));
  for (let y = ya; y < yb; y++) {
    const row = y * W;
    for (let x = xa; x < xb; x++) {
      const t = texture ? (vnoise(x * 0.18, y * 0.18) - 0.5) * texture : 0;
      gray[row + x] = value + t;
    }
  }
}

function fillEllipse(
  gray: Float32Array,
  cx: number,
  cy: number,
  rx: number,
  ry: number,
  value: number,
  stripe = 0,
): void {
  const x0 = Math.max(0, Math.floor(cx - rx));
  const x1 = Math.min(W, Math.ceil(cx + rx));
  const y0 = Math.max(0, Math.floor(cy - ry));
  const y1 = Math.min(H, Math.ceil(cy + ry));
  const rx2 = rx * rx;
  const ry2 = ry * ry;
  for (let y = y0; y < y1; y++) {
    const dy = y - cy;
    const row = y * W;
    for (let x = x0; x < x1; x++) {
      const dx = x - cx;
      if ((dx * dx) / rx2 + (dy * dy) / ry2 <= 1) {
        let v = value;
        if (stripe && ((x + y) & 3) < 2) v *= 0.55;
        gray[row + x] = v;
      }
    }
  }
}

export function renderDemoScene(gray: Float32Array, timeSec: number): void {
  const t = timeSec;

  // Wall
  for (let y = 0; y < H; y++) {
    const row = y * W;
    const wall = 158 + (y / H) * 20;
    for (let x = 0; x < W; x++) {
      const n = (vnoise(x * 0.07, y * 0.07) - 0.5) * 10;
      gray[row + x] = wall + n;
    }
  }

  // Floor
  const floorY = H * 0.62;
  for (let y = floorY | 0; y < H; y++) {
    const row = y * W;
    const g = (y - floorY) / (H - floorY);
    const base = 102 + g * 30;
    for (let x = 0; x < W; x++) {
      const plank = Math.sin(x * 0.08) * 6;
      gray[row + x] = base + plank + (vnoise(x * 0.2, y * 0.4) - 0.5) * 8;
    }
  }

  // Window with blinds (high spatial frequency)
  const wx0 = 18;
  const wy0 = 36;
  const wx1 = 96;
  const wy1 = 132;
  const glow = 230 + Math.sin(t * 0.6) * 12;
  fillRect(gray, wx0 - 6, wy0 - 8, wx1 + 6, wy1 + 8, 92, 4);
  for (let y = wy0; y < wy1; y++) {
    const row = y * W;
    const blind = (y - wy0) % 7 < 2 ? 0.55 : 1;
    for (let x = wx0; x < wx1; x++) {
      gray[row + x] = glow * blind + (x % 5 === 0 ? -12 : 0);
    }
  }

  // Picture frame
  fillRect(gray, 200, 42, 268, 108, 64, 2);
  fillRect(gray, 206, 48, 262, 102, 150, 18);

  // Door
  fillRect(gray, 250, 88, 304, floorY + 8, 78, 6);
  fillRect(gray, 292, 150, 298, 162, 40, 0);

  // Table
  fillRect(gray, 108, 196, 214, 248, 58, 8);
  fillRect(gray, 118, 248, 128, 288, 48, 2);
  fillRect(gray, 194, 248, 204, 288, 48, 2);

  // Plant (high-frequency leaves)
  const px = 52;
  const py = 210;
  fillEllipse(gray, px, py + 28, 8, 18, 42, 0);
  for (let i = 0; i < 14; i++) {
    const a = (i / 14) * Math.PI * 2 + t * 0.2;
    fillEllipse(
      gray,
      px + Math.cos(a) * 16,
      py + Math.sin(a) * 10 - 8,
      7,
      12,
      86 + (i % 3) * 10,
      1,
    );
  }

  // Sitting figure (medium detail)
  fillEllipse(gray, 168, 176, 11, 13, 210, 0);
  fillEllipse(gray, 168, 208, 16, 22, 70, 1);
  fillRect(gray, 154, 226, 182, 248, 48, 0);

  // Walking person — striped shirt so importance concentrates here
  const walk = 0.5 + 0.5 * Math.sin(t * 0.85);
  const personX = 70 + walk * 150;
  const personY = 168;
  const leg = Math.sin(t * 4.2);
  fillEllipse(gray, personX, personY - 38, 13, 15, 215, 0);
  fillEllipse(gray, personX, personY, 18, 28, 48, 1);
  // arms
  fillEllipse(gray, personX - 20, personY + 4 + leg * 6, 6, 16, 200, 0);
  fillEllipse(gray, personX + 20, personY + 4 - leg * 6, 6, 16, 200, 0);
  // legs
  fillEllipse(gray, personX - 8, personY + 42 + leg * 8, 6, 22, 36, 0);
  fillEllipse(gray, personX + 8, personY + 42 - leg * 8, 6, 22, 36, 0);

  // Clamp
  for (let i = 0; i < gray.length; i++) {
    const v = gray[i];
    gray[i] = v < 0 ? 0 : v > 255 ? 255 : v;
  }
}
