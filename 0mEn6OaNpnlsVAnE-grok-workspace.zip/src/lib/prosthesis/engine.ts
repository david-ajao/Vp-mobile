/**
 * Frame pipeline matching prosthesis_core.encode_frame + optional steering.
 *
 *   capture → importance → 1,600 territories → (steer) → phosphene render
 *
 * Brightness is sampled from the camera / demo image. Importance only
 * controls spatial allocation (and a bounded local contrast assist).
 */

import {
  CAPTURE_SIZE,
  STEERING_MAX_FRACTION_CAP,
} from "./constants";
import { FrameCapture } from "./capture";
import { calculateDiagnostics, emptyDiagnostics } from "./diagnostics";
import { ImportanceEngine } from "./importance";
import { PhospheneRenderer } from "./phosphene";
import { SteeringField } from "./steering";
import {
  buildTerritories,
  buildUniformTerritories,
  createTerritoryStore,
} from "./territories";
import type { EngineSettings, HudSnapshot, SourceKind } from "./types";

const DEFAULT_SETTINGS: EngineSettings = {
  adaptive: true,
  steering: false,
  steeringMaxFraction: 0.15,
  comparison: false,
  contrastAssist: true,
  densityAware: true,
};

export class ProsthesisSimulator {
  readonly capture = new FrameCapture();
  private readonly importance = new ImportanceEngine();
  private readonly adaptiveStore = createTerritoryStore();
  private readonly uniformStore = createTerritoryStore();
  private readonly steering = new SteeringField();
  private readonly renderer = new PhospheneRenderer();
  private readonly rendererB = new PhospheneRenderer();

  private mainCtx: CanvasRenderingContext2D | null = null;
  private compareCtx: CanvasRenderingContext2D | null = null;
  private lastTime = 0;
  private fpsEma = 24;
  hud: HudSnapshot = {
    fps: 0,
    source: "demo",
    cameraError: null,
    diagnostics: emptyDiagnostics(),
    compareDiagnostics: null,
  };

  attach(main: HTMLCanvasElement, compare: HTMLCanvasElement | null): void {
    const mainCtx = main.getContext("2d", { alpha: false });
    if (!mainCtx) throw new Error("Could not get 2D context");
    this.mainCtx = mainCtx;
    this.compareCtx = compare ? compare.getContext("2d", { alpha: false }) : null;
    this.resize(main, compare);
  }

  resize(main: HTMLCanvasElement, compare: HTMLCanvasElement | null): void {
    const dpr =
      typeof window !== "undefined" ? Math.min(2, window.devicePixelRatio || 1) : 1;
    const css = Math.max(280, main.clientWidth || 512);
    const px = Math.min(512, Math.max(320, Math.round(css * Math.min(dpr, 1.5))));
    this.renderer.ensureSize(px);
    this.rendererB.ensureSize(px);
    if (main.width !== px) {
      main.width = px;
      main.height = px;
    }
    if (compare) {
      if (compare.width !== px) {
        compare.width = px;
        compare.height = px;
      }
      this.compareCtx = compare.getContext("2d", { alpha: false });
    }
  }

  tick(nowMs: number, settings: EngineSettings = DEFAULT_SETTINGS): HudSnapshot {
    const dt = this.lastTime ? (nowMs - this.lastTime) / 1000 : 0.032;
    this.lastTime = nowMs;
    const fpsInst = dt > 0.0001 ? 1 / dt : 30;
    this.fpsEma = this.fpsEma * 0.9 + fpsInst * 0.1;

    const gray = this.capture.grab(nowMs / 1000);
    const importance = this.importance.compute(gray, true);

    if (settings.adaptive) {
      buildTerritories(gray, importance, this.adaptiveStore, settings.contrastAssist);
    } else {
      buildUniformTerritories(
        gray,
        importance,
        this.adaptiveStore,
        settings.contrastAssist,
      );
    }

    const primary = this.adaptiveStore;
    let cx = primary.cx;
    let cy = primary.cy;
    const brightnessBefore = checksum(primary.brightness, primary.n);

    let steeringMean = 0;
    let steeringMax = 0;
    let steeringFrac = 0;
    if (settings.steering && settings.steeringMaxFraction > 0) {
      const steered = this.steering.apply(
        primary,
        Math.min(settings.steeringMaxFraction, STEERING_MAX_FRACTION_CAP),
      );
      cx = steered.cx;
      cy = steered.cy;
      steeringMean = this.steering.meanDisp;
      steeringMax = this.steering.maxDisp;
      steeringFrac = this.steering.maxFracUsed;
    } else {
      this.steering.reset();
    }

    const brightnessAfter = checksum(primary.brightness, primary.n);
    const brightnessUnchanged = brightnessBefore === brightnessAfter;

    if (this.mainCtx) {
      this.renderer.render(
        cx,
        cy,
        primary.brightness,
        primary.n,
        CAPTURE_SIZE,
        CAPTURE_SIZE,
        settings.densityAware,
        this.mainCtx,
      );
    }

    let compareDiag = null;
    if (settings.comparison) {
      buildUniformTerritories(
        gray,
        importance,
        this.uniformStore,
        settings.contrastAssist,
      );
      if (this.compareCtx) {
        this.rendererB.render(
          this.uniformStore.cx,
          this.uniformStore.cy,
          this.uniformStore.brightness,
          this.uniformStore.n,
          CAPTURE_SIZE,
          CAPTURE_SIZE,
          false,
          this.compareCtx,
        );
      }
      compareDiag = calculateDiagnostics(this.uniformStore);
    }

    this.hud = {
      fps: this.fpsEma,
      source: this.capture.source,
      cameraError: this.capture.cameraError,
      diagnostics: calculateDiagnostics(primary, {
        steeringMeanDisp: steeringMean,
        steeringMaxDisp: steeringMax,
        steeringMaxFracUsed: steeringFrac,
        steeringMaxFraction: settings.steeringMaxFraction,
        brightnessUnchanged,
        meanNn: this.steering.meanNn,
      }),
      compareDiagnostics: compareDiag,
    };

    return this.hud;
  }

  async startCamera(): Promise<SourceKind> {
    await this.capture.startCamera();
    this.importance.reset();
    this.steering.reset();
    this.renderer.resetDensity();
    this.rendererB.resetDensity();
    return this.capture.source;
  }

  stopCamera(): void {
    this.capture.stopCamera();
    this.importance.reset();
    this.steering.reset();
    this.renderer.resetDensity();
    this.rendererB.resetDensity();
  }

  resetTemporal(): void {
    this.importance.reset();
    this.steering.reset();
    this.renderer.resetDensity();
    this.rendererB.resetDensity();
  }

  dispose(): void {
    this.capture.dispose();
  }
}

function checksum(a: Float32Array, n: number): number {
  let s = 0;
  for (let i = 0; i < n; i++) s += a[i] * (i + 1);
  return s;
}
