/**
 * Local positional steering — render-time only.
 *
 * Conceptual port of current_steering_standalone.py:
 *   - Underlying territory centers and brightness are NEVER modified.
 *   - A small, coherent offset is applied to a copy of the centers.
 *   - Phosphenes stay circular. No ellipses, no pooling, no extra elements.
 *   - Max displacement = steeringMaxFraction * nearest-neighbor distance
 *     (hard-capped at 0.20).
 *   - Steering does not touch brightness.
 */

import {
  CAPTURE_SIZE,
  MIN_SEPARATION_FRAC,
  MIN_STRUCTURE,
  STEERING_GAIN,
  STEERING_MAX_FRACTION_CAP,
  STEERING_NEIGHBORS,
  TOTAL_ELEMENTS,
  VECTOR_SPATIAL_PASSES,
  VECTOR_TEMPORAL_ALPHA,
} from "./constants";
import { SpatialKnn } from "./knn";
import type { TerritoryStore } from "./types";

const N = TOTAL_ELEMENTS;
const K = STEERING_NEIGHBORS;

export class SteeringField {
  private readonly knn = new SpatialKnn(N + 8);
  readonly idx = new Int32Array(N * K);
  readonly dist = new Float32Array(N * K);
  readonly nnDist = new Float32Array(N);
  readonly vx = new Float64Array(N);
  readonly vy = new Float64Array(N);
  readonly cxS = new Float64Array(N);
  readonly cyS = new Float64Array(N);
  readonly disp = new Float32Array(N);
  private readonly structure = new Float64Array(N);
  private readonly prevVx = new Float64Array(N);
  private readonly prevVy = new Float64Array(N);
  private hasPrev = false;
  meanNn = 8;
  meanDisp = 0;
  maxDisp = 0;
  maxFracUsed = 0;
  pctMeaningful = 0;

  reset(): void {
    this.hasPrev = false;
  }

  apply(
    territories: TerritoryStore,
    steeringMaxFraction: number,
  ): { cx: Float64Array; cy: Float64Array } {
    const n = territories.n;
    const cx = territories.cx;
    const cy = territories.cy;
    const scores = territories.score;
    const frac = Math.min(Math.max(steeringMaxFraction, 0), STEERING_MAX_FRACTION_CAP);

    this.knn.build(cx, cy, n);
    this.meanNn = this.knn.query(cx, cy, n, K, this.idx, this.dist);
    for (let i = 0; i < n; i++) this.nnDist[i] = this.dist[i * K];

    this.computeStructure(n);
    this.computeVectors(cx, cy, scores, n);
    this.applyDisplacements(cx, cy, n, frac);

    return { cx: this.cxS, cy: this.cyS };
  }

  private computeStructure(n: number): void {
    const inv = this.vx; // reuse as scratch for 1/nn
    for (let i = 0; i < n; i++) inv[i] = 1 / Math.max(this.nnDist[i], 1e-6);
    const sorted = Array.from(inv.subarray(0, n)).sort((a, b) => a - b);
    const p10 = sorted[Math.max(0, ((n * 0.1) | 0) - 0)] ?? 0;
    const p90 = sorted[Math.min(n - 1, (n * 0.9) | 0)] ?? 1;
    const span = Math.max(p90 - p10, 1e-6);
    for (let i = 0; i < n; i++) {
      let s = (inv[i] - p10) / span;
      if (s < 0) s = 0;
      else if (s > 1) s = 1;
      this.structure[i] = s;
    }
  }

  private computeVectors(
    cx: Float64Array,
    cy: Float64Array,
    scores: Float32Array,
    n: number,
  ): void {
    const vx = this.vx;
    const vy = this.vy;
    vx.fill(0);
    vy.fill(0);
    const k = K;

    for (let i = 0; i < n; i++) {
      const si = this.structure[i];
      if (si < MIN_STRUCTURE) continue;
      let accx = 0;
      let accy = 0;
      let wsum = 0;
      const di = 0.55 * clamp01(scores[i]) + 0.45 * si;
      for (let t = 0; t < k; t++) {
        const j = this.idx[i * k + t];
        if (j === i) continue;
        const dx = cx[j] - cx[i];
        const dy = cy[j] - cy[i];
        const dist = Math.hypot(dx, dy);
        if (dist < 1e-8) continue;
        const dj = 0.55 * clamp01(scores[j]) + 0.45 * this.structure[j];
        const w = Math.max(0, dj - di) + 0.15 * si;
        accx += (dx / dist) * w;
        accy += (dy / dist) * w;
        wsum += Math.abs(w);
      }
      if (wsum < 1e-8) {
        let cxn = 0;
        let cyn = 0;
        let c = 0;
        for (let t = 0; t < k; t++) {
          const j = this.idx[i * k + t];
          cxn += cx[j];
          cyn += cy[j];
          c++;
        }
        if (c) {
          const dx = cxn / c - cx[i];
          const dy = cyn / c - cy[i];
          const mag = Math.hypot(dx, dy);
          if (mag > 1e-8) {
            accx = (dx / mag) * si;
            accy = (dy / mag) * si;
            wsum = si;
          }
        }
      }
      if (wsum > 1e-8) {
        const mag = Math.hypot(accx, accy) + 1e-8;
        const g = STEERING_GAIN * si;
        vx[i] = (accx / mag) * g;
        vy[i] = (accy / mag) * g;
      }
    }

    const nvx = this.cxS; // reuse as scratch for spatial smooth
    const nvy = this.cyS;
    for (let pass = 0; pass < VECTOR_SPATIAL_PASSES; pass++) {
      for (let i = 0; i < n; i++) {
        let accx = vx[i];
        let accy = vy[i];
        let wsum = 1;
        for (let t = 0; t < k; t++) {
          const j = this.idx[i * k + t];
          accx += vx[j];
          accy += vy[j];
          wsum += 1;
        }
        nvx[i] = accx / wsum;
        nvy[i] = accy / wsum;
      }
      vx.set(nvx.subarray(0, n));
      vy.set(nvy.subarray(0, n));
    }

    if (this.hasPrev) {
      const a = VECTOR_TEMPORAL_ALPHA;
      for (let i = 0; i < n; i++) {
        vx[i] = a * this.prevVx[i] + (1 - a) * vx[i];
        vy[i] = a * this.prevVy[i] + (1 - a) * vy[i];
      }
    }
    this.prevVx.set(vx.subarray(0, n));
    this.prevVy.set(vy.subarray(0, n));
    this.hasPrev = true;
  }

  private applyDisplacements(
    cx: Float64Array,
    cy: Float64Array,
    n: number,
    frac: number,
  ): void {
    const imgW = CAPTURE_SIZE;
    const imgH = CAPTURE_SIZE;
    const margin = 1;
    let maxFrac = 0;
    let mean = 0;
    let maxD = 0;
    let meaningful = 0;

    for (let i = 0; i < n; i++) {
      const nn = this.nnDist[i];
      const maxDisp = frac * nn;
      let dx = this.vx[i] * nn;
      let dy = this.vy[i] * nn;
      const mag = Math.hypot(dx, dy);
      if (mag > maxDisp && mag > 1e-8) {
        const s = maxDisp / mag;
        dx *= s;
        dy *= s;
      }
      let xs = cx[i] + dx;
      let ys = cy[i] + dy;
      if (xs < margin) xs = margin;
      else if (xs > imgW - 1 - margin) xs = imgW - 1 - margin;
      if (ys < margin) ys = margin;
      else if (ys > imgH - 1 - margin) ys = imgH - 1 - margin;
      this.cxS[i] = xs;
      this.cyS[i] = ys;
    }

    // Soft min-separation via coarse grid (same idea as the Python prototype)
    const meanNn = Math.max(this.meanNn, 1);
    const minSep = MIN_SEPARATION_FRAC * meanNn;
    const cell = Math.max(meanNn * 0.5, 1);
    const grid = new Map<number, number[]>();
    const key = (x: number, y: number) => ((y * 4096) ^ x) | 0;
    for (let i = 0; i < n; i++) {
      const gx = (this.cxS[i] / cell) | 0;
      const gy = (this.cyS[i] / cell) | 0;
      const k = key(gx, gy);
      let bucket = grid.get(k);
      if (!bucket) {
        bucket = [];
        grid.set(k, bucket);
      }
      bucket.push(i);
    }

    for (let i = 0; i < n; i++) {
      const gx = (this.cxS[i] / cell) | 0;
      const gy = (this.cyS[i] / cell) | 0;
      for (let ox = -1; ox <= 1; ox++) {
        for (let oy = -1; oy <= 1; oy++) {
          const bucket = grid.get(key(gx + ox, gy + oy));
          if (!bucket) continue;
          for (let b = 0; b < bucket.length; b++) {
            const j = bucket[b];
            if (j <= i) continue;
            const ddx = this.cxS[i] - this.cxS[j];
            const ddy = this.cyS[i] - this.cyS[j];
            const dist = Math.hypot(ddx, ddy);
            if (dist < minSep && dist > 1e-6) {
              const deficit = (minSep - dist) / 2;
              const ux = ddx / dist;
              const uy = ddy / dist;
              this.cxS[i] += ux * deficit;
              this.cyS[i] += uy * deficit;
              this.cxS[j] -= ux * deficit;
              this.cyS[j] -= uy * deficit;
            }
          }
        }
      }
    }

    for (let i = 0; i < n; i++) {
      let xs = this.cxS[i];
      let ys = this.cyS[i];
      if (xs < margin) xs = margin;
      else if (xs > imgW - 1 - margin) xs = imgW - 1 - margin;
      if (ys < margin) ys = margin;
      else if (ys > imgH - 1 - margin) ys = imgH - 1 - margin;
      this.cxS[i] = xs;
      this.cyS[i] = ys;
      const d = Math.hypot(xs - cx[i], ys - cy[i]);
      this.disp[i] = d;
      mean += d;
      if (d > maxD) maxD = d;
      const nn = this.nnDist[i];
      const used = nn > 1e-6 ? d / nn : 0;
      if (used > maxFrac) maxFrac = used;
      if (d > 0.05 * nn) meaningful++;
    }

    this.meanDisp = n ? mean / n : 0;
    this.maxDisp = maxD;
    this.maxFracUsed = maxFrac;
    this.pctMeaningful = n ? (100 * meaningful) / n : 0;
  }
}

function clamp01(v: number): number {
  return v < 0 ? 0 : v > 1 ? 1 : v;
}
