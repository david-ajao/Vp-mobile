import { CAPTURE_SIZE } from "./constants";
import { rgbaToGray } from "./image-ops";
import { renderDemoScene } from "./demo-scene";
import type { SourceKind } from "./types";

export class FrameCapture {
  readonly canvas: HTMLCanvasElement;
  private readonly ctx: CanvasRenderingContext2D;
  readonly gray = new Float32Array(CAPTURE_SIZE * CAPTURE_SIZE);
  private video: HTMLVideoElement | null = null;
  private stream: MediaStream | null = null;
  source: SourceKind = "demo";
  cameraError: string | null = null;
  private readonly rgbaScratch = new Uint8ClampedArray(CAPTURE_SIZE * CAPTURE_SIZE * 4);

  constructor() {
    this.canvas = document.createElement("canvas");
    this.canvas.width = CAPTURE_SIZE;
    this.canvas.height = CAPTURE_SIZE;
    const ctx = this.canvas.getContext("2d", {
      willReadFrequently: true,
      alpha: false,
    });
    if (!ctx) throw new Error("Could not create capture canvas");
    this.ctx = ctx;
  }

  grab(timeSec: number): Float32Array {
    if (this.source === "camera" && this.video && this.video.readyState >= 2) {
      const vw = this.video.videoWidth;
      const vh = this.video.videoHeight;
      if (vw > 0 && vh > 0) {
        const side = Math.min(vw, vh);
        const sx = (vw - side) / 2;
        const sy = (vh - side) / 2;
        this.ctx.drawImage(
          this.video,
          sx,
          sy,
          side,
          side,
          0,
          0,
          CAPTURE_SIZE,
          CAPTURE_SIZE,
        );
        const img = this.ctx.getImageData(0, 0, CAPTURE_SIZE, CAPTURE_SIZE);
        this.rgbaScratch.set(img.data);
        rgbaToGray(this.rgbaScratch, this.gray, CAPTURE_SIZE * CAPTURE_SIZE);
        return this.gray;
      }
    }
    renderDemoScene(this.gray, timeSec);
    return this.gray;
  }

  async startCamera(): Promise<void> {
    this.cameraError = null;
    if (typeof navigator === "undefined" || !navigator.mediaDevices?.getUserMedia) {
      this.cameraError = "Camera API is not available in this browser.";
      this.source = "demo";
      return;
    }
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        audio: false,
        video: {
          facingMode: { ideal: "environment" },
          width: { ideal: 640 },
          height: { ideal: 640 },
        },
      });
      await this.attachStream(stream);
    } catch (err) {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({
          audio: false,
          video: true,
        });
        await this.attachStream(stream);
      } catch (err2) {
        this.stopCamera();
        this.cameraError = humanCameraError(err2 ?? err);
        this.source = "demo";
      }
    }
  }

  private async attachStream(stream: MediaStream): Promise<void> {
    this.stopTracks();
    this.stream = stream;
    const video = document.createElement("video");
    video.setAttribute("playsinline", "true");
    video.setAttribute("webkit-playsinline", "true");
    video.muted = true;
    video.autoplay = true;
    video.srcObject = stream;
    await video.play();
    this.video = video;
    this.source = "camera";
    this.cameraError = null;
  }

  stopCamera(): void {
    this.stopTracks();
    if (this.video) {
      this.video.srcObject = null;
      this.video = null;
    }
    this.source = "demo";
  }

  private stopTracks(): void {
    if (!this.stream) return;
    for (const track of this.stream.getTracks()) track.stop();
    this.stream = null;
  }

  dispose(): void {
    this.stopCamera();
  }
}

function humanCameraError(err: unknown): string {
  const name = err && typeof err === "object" && "name" in err ? String(err.name) : "";
  if (name === "NotAllowedError" || name === "PermissionDeniedError") {
    return "Camera permission was declined. Using the demo scene.";
  }
  if (name === "NotFoundError" || name === "DevicesNotFoundError") {
    return "No camera was found. Using the demo scene.";
  }
  if (name === "NotReadableError") {
    return "Camera is already in use. Using the demo scene.";
  }
  const msg = err instanceof Error ? err.message : "Camera unavailable.";
  return `${msg} Using the demo scene.`;
}
