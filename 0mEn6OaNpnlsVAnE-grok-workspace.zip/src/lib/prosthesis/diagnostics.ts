import {
  CAPTURE_SIZE,
  HIGH_IMPORTANCE_THRESHOLD,
  LOW_IMPORTANCE_THRESHOLD,
  MAX_CONTEXT_COUNT,
  MIN_CONTEXT_COUNT,
  STEERING_MAX_FRACTION_CAP,
  TOTAL_ELEMENTS,
} from "./constants";
import type { Diagnostics, TerritoryStore } from "./types";

const counter = new Int32Array(CAPTURE_SIZE * CAPTURE_SIZE);

export function calculateDiagnostics(
  territories: TerritoryStore,
  opts?: {
    steeringMeanDisp?: number;
    steeringMaxDisp?: number;
    steeringMaxFracUsed?: number;
    steeringMaxFraction?: number;
    brightnessUnchanged?: boolean;
    meanNn?: number;
  },
): Diagnostics {
  const width = CAPTURE_SIZE;
  const height = CAPTURE_SIZE;
  const n = territories.n;
  counter.fill(0);
  let oob = 0;

  for (let i = 0; i < n; i++) {
    const x = territories.x[i];
    const y = territories.y[i];
    const w = territories.w[i];
    const h = territories.h[i];
    if (x < 0 || y < 0 || x + w > width || y + h > height || w <= 0 || h <= 0) {
      oob++;
      continue;
    }
    for (let yy = y; yy < y + h; yy++) {
      const row = yy * width;
      for (let xx = x; xx < x + w; xx++) counter[row + xx]++;
    }
  }

  let uncovered = 0;
  let overlapping = 0;
  let covered = 0;
  const totalPx = width * height;
  for (let i = 0; i < totalPx; i++) {
    const c = counter[i];
    if (c === 0) uncovered++;
    else {
      covered++;
      if (c > 1) overlapping++;
    }
  }

  let high = 0;
  let med = 0;
  let ctx = 0;
  let sumB = 0;
  let minB = 255;
  let maxB = 0;
  let nearBlack = 0;
  let saturated = 0;
  let delta = 0;
  for (let i = 0; i < n; i++) {
    const s = territories.score[i];
    if (s >= HIGH_IMPORTANCE_THRESHOLD) high++;
    else if (s >= LOW_IMPORTANCE_THRESHOLD) med++;
    else ctx++;
    const b = territories.brightness[i];
    sumB += b;
    if (b < minB) minB = b;
    if (b > maxB) maxB = b;
    if (b < 8) nearBlack++;
    if (b > 247) saturated++;
    delta += Math.abs(b - territories.rawBrightness[i]);
  }

  const fracCap = opts?.steeringMaxFraction ?? STEERING_MAX_FRACTION_CAP;
  const maxFracUsed = opts?.steeringMaxFracUsed ?? 0;

  return {
    elements: n,
    coveragePercent: (100 * covered) / totalPx,
    uncoveredPixels: uncovered,
    overlappingPixels: overlapping,
    oobTerritories: oob,
    highCount: high,
    pctHigh: n ? (100 * high) / n : 0,
    medCount: med,
    pctMed: n ? (100 * med) / n : 0,
    contextCount: ctx,
    pctContext: n ? (100 * ctx) / n : 0,
    contextProtectionPass: ctx >= MIN_CONTEXT_COUNT && ctx <= MAX_CONTEXT_COUNT,
    avgContrastAssistDelta: n ? delta / n : 0,
    meanBrightness: n ? sumB / n : 0,
    minBrightness: n ? minB : 0,
    maxBrightness: n ? maxB : 0,
    nearBlackCount: nearBlack,
    pctNearBlack: n ? (100 * nearBlack) / n : 0,
    saturatedCount: saturated,
    pctSaturated: n ? (100 * saturated) / n : 0,
    brightnessFromImage: true,
    steeringMeanDisp: opts?.steeringMeanDisp ?? 0,
    steeringMaxDisp: opts?.steeringMaxDisp ?? 0,
    steeringMaxFracUsed: maxFracUsed,
    steeringWithinMax: maxFracUsed <= fracCap + 0.05,
    steeringBrightnessUnchanged: opts?.brightnessUnchanged ?? true,
    meanNn: opts?.meanNn ?? 0,
  };
}

export function emptyDiagnostics(): Diagnostics {
  return calculateDiagnostics(
    {
      n: TOTAL_ELEMENTS,
      x: new Int32Array(TOTAL_ELEMENTS),
      y: new Int32Array(TOTAL_ELEMENTS),
      w: new Int32Array(TOTAL_ELEMENTS),
      h: new Int32Array(TOTAL_ELEMENTS),
      score: new Float32Array(TOTAL_ELEMENTS),
      brightness: new Float32Array(TOTAL_ELEMENTS),
      rawBrightness: new Float32Array(TOTAL_ELEMENTS),
      cx: new Float64Array(TOTAL_ELEMENTS),
      cy: new Float64Array(TOTAL_ELEMENTS),
    },
    {},
  );
}
