export type TerritoryStore = {
  n: number;
  x: Int32Array;
  y: Int32Array;
  w: Int32Array;
  h: Int32Array;
  score: Float32Array;
  brightness: Float32Array;
  rawBrightness: Float32Array;
  cx: Float64Array;
  cy: Float64Array;
};

export type Diagnostics = {
  elements: number;
  coveragePercent: number;
  uncoveredPixels: number;
  overlappingPixels: number;
  oobTerritories: number;
  highCount: number;
  pctHigh: number;
  medCount: number;
  pctMed: number;
  contextCount: number;
  pctContext: number;
  contextProtectionPass: boolean;
  avgContrastAssistDelta: number;
  meanBrightness: number;
  minBrightness: number;
  maxBrightness: number;
  nearBlackCount: number;
  pctNearBlack: number;
  saturatedCount: number;
  pctSaturated: number;
  brightnessFromImage: boolean;
  steeringMeanDisp: number;
  steeringMaxDisp: number;
  steeringMaxFracUsed: number;
  steeringWithinMax: boolean;
  steeringBrightnessUnchanged: boolean;
  meanNn: number;
};

export type EngineSettings = {
  adaptive: boolean;
  steering: boolean;
  steeringMaxFraction: number;
  comparison: boolean;
  contrastAssist: boolean;
  densityAware: boolean;
};

export type HudSnapshot = {
  fps: number;
  source: "demo" | "camera";
  cameraError: string | null;
  diagnostics: Diagnostics;
  compareDiagnostics: Diagnostics | null;
};

export type SourceKind = "demo" | "camera";
