/**
 * Quadtree partition guaranteeing 1,600 territories with a PROTECTED
 * context / background allocation range (15%–25% / 240–400 elements).
 *
 * Port of prosthesis_core.build_territories / build_uniform_territories.
 * Importance controls WHERE spatial resolution is spent. Brightness is
 * sampled from the camera image (mean luminance of each territory) and is
 * never a function of importance except for the bounded contrast-assist
 * shift, which is capped at MAX_BRIGHTNESS_DELTA.
 */

import {
  ALLOCATION_EXPONENT,
  BACKGROUND_MAX,
  BACKGROUND_MIN,
  BACKGROUND_TARGET,
  CAPTURE_SIZE,
  CONTRAST_ASSIST_ALPHA,
  GRID_COLS,
  GRID_ROWS,
  LOCAL_LUMINANCE_SIGMA,
  LOW_IMPORTANCE_THRESHOLD,
  MAX_BRIGHTNESS_DELTA,
  MAX_CONTEXT_COUNT,
  MAX_CONTRAST_GAIN,
  MAX_TERRITORY_FRACTION,
  MIN_CONTEXT_COUNT,
  MIN_TERRITORY_SIZE,
  TARGET_CONTEXT_COUNT,
  TOTAL_ELEMENTS,
} from "./constants";
import { boxBlur, buildIntegral, rectMean } from "./image-ops";
import type { TerritoryStore } from "./types";

export function createTerritoryStore(cap = TOTAL_ELEMENTS + 16): TerritoryStore {
  return {
    n: 0,
    x: new Int32Array(cap),
    y: new Int32Array(cap),
    w: new Int32Array(cap),
    h: new Int32Array(cap),
    score: new Float32Array(cap),
    brightness: new Float32Array(cap),
    rawBrightness: new Float32Array(cap),
    cx: new Float64Array(cap),
    cy: new Float64Array(cap),
  };
}

type QuadNode = {
  prio: number;
  id: number;
  x: number;
  y: number;
  w: number;
  h: number;
  score: number;
};

class MaxHeap {
  a: QuadNode[] = [];
  clear() {
    this.a.length = 0;
  }
  get length() {
    return this.a.length;
  }
  peek(): QuadNode {
    return this.a[0];
  }
  push(n: QuadNode) {
    const a = this.a;
    a.push(n);
    let i = a.length - 1;
    while (i > 0) {
      const p = (i - 1) >> 1;
      if (a[p].prio > a[i].prio || (a[p].prio === a[i].prio && a[p].id <= a[i].id)) {
        break;
      }
      const t = a[p];
      a[p] = a[i];
      a[i] = t;
      i = p;
    }
  }
  pop(): QuadNode {
    const a = this.a;
    const top = a[0];
    const last = a.pop()!;
    if (a.length) {
      a[0] = last;
      let i = 0;
      const n = a.length;
      for (;;) {
        let s = i;
        const l = i * 2 + 1;
        const r = l + 1;
        if (l < n && (a[l].prio > a[s].prio || (a[l].prio === a[s].prio && a[l].id < a[s].id))) {
          s = l;
        }
        if (r < n && (a[r].prio > a[s].prio || (a[r].prio === a[s].prio && a[r].id < a[s].id))) {
          s = r;
        }
        if (s === i) break;
        const t = a[i];
        a[i] = a[s];
        a[s] = t;
        i = s;
      }
    }
    return top;
  }
}

const highHeap = new MaxHeap();
const ctxHeap = new MaxHeap();
const highFrozen: QuadNode[] = [];
const ctxFrozen: QuadNode[] = [];

const grayIntegral = new Float64Array((CAPTURE_SIZE + 1) * (CAPTURE_SIZE + 1));
const impIntegral = new Float64Array((CAPTURE_SIZE + 1) * (CAPTURE_SIZE + 1));
const localLum = new Float32Array(CAPTURE_SIZE * CAPTURE_SIZE);
const blurTmp = new Float32Array(CAPTURE_SIZE * CAPTURE_SIZE);
const blurScratch = new Float32Array(CAPTURE_SIZE * CAPTURE_SIZE);

function canSplit(w: number, h: number): boolean {
  return w >= 2 * MIN_TERRITORY_SIZE && h >= 2 * MIN_TERRITORY_SIZE;
}

function computePrio(w: number, h: number, score: number, maxSide: number): number {
  if (w > maxSide || h > maxSide) return 1e12 + w * h;
  return Math.pow(score, ALLOCATION_EXPONENT) * (w * h);
}

function finalize(
  nodes: QuadNode[],
  gray: Float32Array,
  store: TerritoryStore,
  contrastAssist: boolean,
): void {
  const width = CAPTURE_SIZE;
  const height = CAPTURE_SIZE;
  const iw = width + 1;
  const n = Math.min(nodes.length, store.x.length);
  store.n = n;

  for (let i = 0; i < n; i++) {
    const nd = nodes[i];
    const x = nd.x;
    const y = nd.y;
    const w = nd.w;
    const h = nd.h;
    store.x[i] = x;
    store.y[i] = y;
    store.w[i] = w;
    store.h[i] = h;
    store.score[i] = nd.score;
    const raw = rectMean(grayIntegral, iw, x, y, w, h);
    store.rawBrightness[i] = raw;
    store.cx[i] = x + w / 2;
    store.cy[i] = y + h / 2;
  }

  if (!contrastAssist) {
    store.brightness.set(store.rawBrightness.subarray(0, n));
    return;
  }

  const radius = Math.max(1, Math.round(LOCAL_LUMINANCE_SIGMA * 0.9));
  boxBlur(gray, localLum, blurTmp, width, height, radius);
  boxBlur(localLum, blurScratch, blurTmp, width, height, radius);

  for (let i = 0; i < n; i++) {
    const cx = Math.min(width - 1, Math.max(0, store.cx[i] | 0));
    const cy = Math.min(height - 1, Math.max(0, store.cy[i] | 0));
    const bOrig = store.rawBrightness[i] / 255;
    const bLocal = blurScratch[cy * width + cx] / 255;
    const score = store.score[i];
    const factor = Math.min(1 + CONTRAST_ASSIST_ALPHA * score, MAX_CONTRAST_GAIN);
    const bOut = bLocal + (bOrig - bLocal) * factor;
    let shift = bOut - bOrig;
    if (shift > MAX_BRIGHTNESS_DELTA) shift = MAX_BRIGHTNESS_DELTA;
    else if (shift < -MAX_BRIGHTNESS_DELTA) shift = -MAX_BRIGHTNESS_DELTA;
    let v = (bOrig + shift) * 255;
    if (v < 0) v = 0;
    else if (v > 255) v = 255;
    store.brightness[i] = v;
  }
}

export function buildTerritories(
  gray: Float32Array,
  importance: Float32Array,
  store: TerritoryStore,
  contrastAssist: boolean,
): void {
  const width = CAPTURE_SIZE;
  const height = CAPTURE_SIZE;
  const iw = width + 1;
  buildIntegral(gray, width, height, grayIntegral);
  buildIntegral(importance, width, height, impIntegral);
  const maxSide = Math.max(width, height) * MAX_TERRITORY_FRACTION;

  highHeap.clear();
  ctxHeap.clear();
  highFrozen.length = 0;
  ctxFrozen.length = 0;

  let nextId = 0;
  const rootScore = rectMean(impIntegral, iw, 0, 0, width, height);
  const rootPrio = computePrio(width, height, rootScore, maxSide);
  const root: QuadNode = {
    prio: rootPrio,
    id: nextId++,
    x: 0,
    y: 0,
    w: width,
    h: height,
    score: rootScore,
  };

  let currentContext = 0;
  let leafCount = 1;
  if (rootScore < LOW_IMPORTANCE_THRESHOLD) {
    ctxHeap.push(root);
    currentContext = 1;
  } else {
    highHeap.push(root);
  }

  while (leafCount < TOTAL_ELEMENTS) {
    const canHigh = highHeap.length > 0;
    const canCtx = ctxHeap.length > 0;
    if (!canHigh && !canCtx) break;

    let popHigh: boolean;
    if (canHigh && canCtx) {
      if (currentContext < MIN_CONTEXT_COUNT) {
        popHigh = false;
      } else if (currentContext + 3 > MAX_CONTEXT_COUNT) {
        popHigh = true;
      } else if (currentContext < TARGET_CONTEXT_COUNT) {
        popHigh = highHeap.peek().prio > ctxHeap.peek().prio * 1.5;
      } else {
        popHigh = highHeap.peek().prio * 1.5 >= ctxHeap.peek().prio;
      }
    } else {
      popHigh = canHigh;
    }

    const node = popHigh ? highHeap.pop() : ctxHeap.pop();
    if (!popHigh) currentContext -= 1;

    const hw = node.w >> 1;
    const hh = node.h >> 1;
    const children: [number, number, number, number][] = [
      [node.x, node.y, hw, hh],
      [node.x + hw, node.y, node.w - hw, hh],
      [node.x, node.y + hh, hw, node.h - hh],
      [node.x + hw, node.y + hh, node.w - hw, node.h - hh],
    ];

    for (let c = 0; c < 4; c++) {
      const [cx, cy, cw, ch] = children[c];
      if (cw <= 0 || ch <= 0) continue;
      const cScore = rectMean(impIntegral, iw, cx, cy, cw, ch);
      const cPrio = computePrio(cw, ch, cScore, maxSide);
      const isCtx = cScore < LOW_IMPORTANCE_THRESHOLD;
      const child: QuadNode = {
        prio: cPrio,
        id: nextId++,
        x: cx,
        y: cy,
        w: cw,
        h: ch,
        score: cScore,
      };
      if (canSplit(cw, ch)) {
        if (isCtx) {
          currentContext += 1;
          ctxHeap.push(child);
        } else {
          highHeap.push(child);
        }
      } else if (isCtx) {
        currentContext += 1;
        ctxFrozen.push(child);
      } else {
        highFrozen.push(child);
      }
    }
    leafCount += 3;
  }

  const leaves: QuadNode[] = [];
  for (let i = 0; i < highFrozen.length; i++) leaves.push(highFrozen[i]);
  for (let i = 0; i < ctxFrozen.length; i++) leaves.push(ctxFrozen[i]);
  for (let i = 0; i < highHeap.a.length; i++) leaves.push(highHeap.a[i]);
  for (let i = 0; i < ctxHeap.a.length; i++) leaves.push(ctxHeap.a[i]);

  // Guarantee exactly 1,600 by subdividing largest leftover leaves if short,
  // or truncating if a degenerate split produced extras.
  while (leaves.length < TOTAL_ELEMENTS) {
    let best = -1;
    let bestArea = -1;
    for (let i = 0; i < leaves.length; i++) {
      const nd = leaves[i];
      if (!canSplit(nd.w, nd.h)) continue;
      const area = nd.w * nd.h;
      if (area > bestArea) {
        bestArea = area;
        best = i;
      }
    }
    if (best < 0) break;
    const node = leaves[best];
    const hw = node.w >> 1;
    const hh = node.h >> 1;
    const kids: [number, number, number, number][] = [
      [node.x, node.y, hw, hh],
      [node.x + hw, node.y, node.w - hw, hh],
      [node.x, node.y + hh, hw, node.h - hh],
      [node.x + hw, node.y + hh, node.w - hw, node.h - hh],
    ];
    leaves.splice(best, 1);
    for (let c = 0; c < 4; c++) {
      const [cx, cy, cw, ch] = kids[c];
      if (cw <= 0 || ch <= 0) continue;
      const cScore = rectMean(impIntegral, iw, cx, cy, cw, ch);
      leaves.push({
        prio: 0,
        id: nextId++,
        x: cx,
        y: cy,
        w: cw,
        h: ch,
        score: cScore,
      });
    }
  }
  if (leaves.length > TOTAL_ELEMENTS) leaves.length = TOTAL_ELEMENTS;

  finalize(leaves, gray, store, contrastAssist);
}

export function buildUniformTerritories(
  gray: Float32Array,
  importance: Float32Array,
  store: TerritoryStore,
  contrastAssist: boolean,
): void {
  const width = CAPTURE_SIZE;
  const height = CAPTURE_SIZE;
  const iw = width + 1;
  buildIntegral(gray, width, height, grayIntegral);
  buildIntegral(importance, width, height, impIntegral);

  const xs = new Int32Array(GRID_COLS + 1);
  const ys = new Int32Array(GRID_ROWS + 1);
  for (let c = 0; c <= GRID_COLS; c++) xs[c] = Math.round((c * width) / GRID_COLS);
  for (let r = 0; r <= GRID_ROWS; r++) ys[r] = Math.round((r * height) / GRID_ROWS);

  const leaves: QuadNode[] = [];
  let id = 0;
  for (let r = 0; r < GRID_ROWS; r++) {
    for (let c = 0; c < GRID_COLS; c++) {
      const x = xs[c];
      const y = ys[r];
      const w = xs[c + 1] - x;
      const h = ys[r + 1] - y;
      const score = rectMean(impIntegral, iw, x, y, w, h);
      leaves.push({ prio: 0, id: id++, x, y, w, h, score });
    }
  }
  finalize(leaves, gray, store, contrastAssist);
}

export const CONTEXT_RANGE_LABEL = `${(BACKGROUND_MIN * 100).toFixed(0)}–${(
  BACKGROUND_MAX * 100
).toFixed(0)}% (target ${(BACKGROUND_TARGET * 100).toFixed(0)}%)`;
