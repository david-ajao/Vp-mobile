import { useCallback, useEffect, useRef, useState, type RefObject } from "react";
import * as Slider from "@radix-ui/react-slider";
import * as Switch from "@radix-ui/react-switch";
import {
  Camera,
  CameraOff,
  ChevronDown,
  CircleDot,
} from "lucide-react";
import {
  ProsthesisSimulator,
  STEERING_MAX_FRACTION_DEFAULT,
  TOTAL_ELEMENTS,
  type Diagnostics,
  type EngineSettings,
  type HudSnapshot,
} from "@/lib/prosthesis";
import { cn } from "@/lib/utils";

const INITIAL_SETTINGS: EngineSettings = {
  adaptive: true,
  steering: false,
  steeringMaxFraction: STEERING_MAX_FRACTION_DEFAULT,
  comparison: false,
  contrastAssist: true,
  densityAware: true,
};

function emptyHud(): HudSnapshot {
  return {
    fps: 0,
    source: "demo",
    cameraError: null,
    diagnostics: {
      elements: TOTAL_ELEMENTS,
      coveragePercent: 0,
      uncoveredPixels: 0,
      overlappingPixels: 0,
      oobTerritories: 0,
      highCount: 0,
      pctHigh: 0,
      medCount: 0,
      pctMed: 0,
      contextCount: 0,
      pctContext: 0,
      contextProtectionPass: false,
      avgContrastAssistDelta: 0,
      meanBrightness: 0,
      minBrightness: 0,
      maxBrightness: 0,
      nearBlackCount: 0,
      pctNearBlack: 0,
      saturatedCount: 0,
      pctSaturated: 0,
      brightnessFromImage: true,
      steeringMeanDisp: 0,
      steeringMaxDisp: 0,
      steeringMaxFracUsed: 0,
      steeringWithinMax: true,
      steeringBrightnessUnchanged: true,
      meanNn: 0,
    },
    compareDiagnostics: null,
  };
}

export function SimulatorApp() {
  const mainRef = useRef<HTMLCanvasElement>(null);
  const compareRef = useRef<HTMLCanvasElement>(null);
  const engineRef = useRef<ProsthesisSimulator | null>(null);
  const settingsRef = useRef<EngineSettings>(INITIAL_SETTINGS);
  const [settings, setSettings] = useState<EngineSettings>(INITIAL_SETTINGS);
  const [hud, setHud] = useState<HudSnapshot>(emptyHud);
  const [busy, setBusy] = useState(false);
  const [diagOpen, setDiagOpen] = useState(false);
  const [ready, setReady] = useState(false);

  settingsRef.current = settings;

  const apply = useCallback((patch: Partial<EngineSettings>) => {
    setSettings((prev) => {
      const next = { ...prev, ...patch };
      settingsRef.current = next;
      if (patch.adaptive !== undefined || patch.steering !== undefined) {
        engineRef.current?.resetTemporal();
      }
      return next;
    });
  }, []);

  useEffect(() => {
    const engine = new ProsthesisSimulator();
    engineRef.current = engine;
    const main = mainRef.current;
    if (!main) return;

    const attach = () => engine.attach(main, compareRef.current);
    attach();
    requestAnimationFrame(attach);
    setReady(true);

    let raf = 0;
    let lastHud = 0;
    const loop = (now: number) => {
      const snap = engine.tick(now, settingsRef.current);
      if (lastHud === 0 || now - lastHud > 250) {
        lastHud = now;
        setHud({ ...snap, diagnostics: { ...snap.diagnostics } });
      }
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);

    const onResize = () => engine.resize(main, compareRef.current);
    window.addEventListener("resize", onResize);
    const ro = new ResizeObserver(onResize);
    ro.observe(main);

    if ("serviceWorker" in navigator) {
      navigator.serviceWorker.register("/service-worker.js").catch(() => {});
    }

    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("resize", onResize);
      ro.disconnect();
      engine.dispose();
      engineRef.current = null;
    };
  }, []);

  useEffect(() => {
    const main = mainRef.current;
    if (main) engineRef.current?.resize(main, compareRef.current);
  }, [settings.comparison]);

  const startCamera = async () => {
    if (!engineRef.current || busy) return;
    setBusy(true);
    try {
      await engineRef.current.startCamera();
    } finally {
      setBusy(false);
    }
  };

  const stopCamera = () => {
    engineRef.current?.stopCamera();
  };

  const d = hud.diagnostics;
  const cameraOn = hud.source === "camera";
  const strengthPct = Math.round(settings.steeringMaxFraction * 100);

  return (
    <main className="mx-auto flex min-h-dvh w-full max-w-3xl flex-col bg-bg px-4 pb-8 pt-[max(0.75rem,env(safe-area-inset-top))] sm:px-6">
      <header className="flex items-end justify-between gap-3 pb-4">
        <div>
          <p className="font-mono text-[0.6875rem] tracking-[0.18em] text-muted uppercase">
            Visual encoding
          </p>
          <h1 className="font-display text-[2rem] leading-tight tracking-[-0.03em] text-fg italic sm:text-[2.35rem]">
            Phosphene 1600
          </h1>
        </div>
        <div className="flex items-center gap-2 pb-1">
          <StatChip label="FPS" value={ready ? hud.fps.toFixed(0) : "—"} />
          <StatChip label="Elements" value={String(TOTAL_ELEMENTS)} accent />
        </div>
      </header>

      <section
        className={cn(
          "grid gap-3",
          settings.comparison ? "grid-cols-2" : "grid-cols-1",
        )}
      >
        <Stage
          canvasRef={mainRef}
          label={settings.adaptive ? "Adaptive · 1,600" : "Uniform 40 × 40"}
          sub={
            settings.steering
              ? `Steering ${strengthPct}%`
              : "No steering"
          }
        />
        <div className={settings.comparison ? "block" : "hidden"}>
          <Stage
            canvasRef={compareRef}
            label="Uniform 40 × 40"
            sub="No steering"
          />
        </div>
      </section>

      {hud.cameraError ? (
        <p className="mt-3 rounded-md bg-elevated px-3 py-2 text-sm text-warn" role="status">
          {hud.cameraError}
        </p>
      ) : null}

      <p className="mt-3 font-mono text-[0.6875rem] tracking-wide text-subtle">
        Source · {cameraOn ? "rear camera" : "demo scene"}
        {" · "}
        Importance is a mobile approximation (gradient, contrast, variance). No YOLO
        segmentation.
      </p>

      <div className="mt-5 flex flex-col gap-3">
        <div className="grid grid-cols-2 gap-2">
          <button
            type="button"
            onClick={startCamera}
            disabled={busy || cameraOn}
            className={cn(
              "flex h-12 items-center justify-center gap-2 rounded-lg bg-accent px-3 font-medium text-accent-fg",
              "transition-[opacity,transform] duration-150 ease-out active:scale-[0.96]",
              "disabled:opacity-40",
            )}
          >
            <Camera className="size-4" strokeWidth={1.75} aria-hidden />
            Start Camera
          </button>
          <button
            type="button"
            onClick={stopCamera}
            disabled={!cameraOn}
            className={cn(
              "flex h-12 items-center justify-center gap-2 rounded-lg bg-elevated px-3 font-medium text-fg",
              "shadow-[var(--shadow-border)]",
              "transition-[opacity,transform] duration-150 ease-out active:scale-[0.96]",
              "disabled:opacity-40",
            )}
          >
            <CameraOff className="size-4" strokeWidth={1.75} aria-hidden />
            Stop Camera
          </button>
        </div>

        <div className="rounded-xl bg-surface p-4 shadow-[var(--shadow-border)]">
          <ToggleRow
            label="Adaptive allocation"
            description="Finer territories on important structure"
            checked={settings.adaptive}
            onCheckedChange={(v) => apply({ adaptive: v })}
          />
          <div className="my-3 h-px bg-line" />
          <ToggleRow
            label="Steering"
            description="Bounded positional offset at render time"
            checked={settings.steering}
            onCheckedChange={(v) => apply({ steering: v })}
          />
          <div className="mt-4">
            <div className="mb-2 flex items-baseline justify-between">
              <label className="text-sm text-fg" htmlFor="steering-strength">
                Steering strength
              </label>
              <span className="font-mono text-sm tabular-nums text-muted">{strengthPct}%</span>
            </div>
            <Slider.Root
              id="steering-strength"
              value={[strengthPct]}
              min={0}
              max={20}
              step={1}
              disabled={!settings.steering}
              onValueChange={([v]) => apply({ steeringMaxFraction: (v ?? 0) / 100 })}
              className="relative flex h-8 w-full touch-none items-center"
            >
              <Slider.Track className="relative h-1.5 grow rounded-full bg-elevated">
                <Slider.Range className="absolute h-full rounded-full bg-accent" />
              </Slider.Track>
              <Slider.Thumb
                className="block size-5 rounded-full bg-fg shadow-[var(--shadow-border)] outline-none focus-visible:ring-2 focus-visible:ring-accent"
                aria-label="Steering strength"
              />
            </Slider.Root>
            <p className="mt-2 text-[0.75rem] text-subtle">0–20% of nearest-neighbor spacing</p>
          </div>
          <div className="my-3 h-px bg-line" />
          <ToggleRow
            label="Baseline comparison"
            description="Uniform 40 × 40 beside the live encoding"
            checked={settings.comparison}
            onCheckedChange={(v) => apply({ comparison: v })}
          />
        </div>
      </div>

      <button
        type="button"
        onClick={() => setDiagOpen((o) => !o)}
        className="mt-4 flex h-12 w-full items-center justify-between rounded-lg bg-surface px-4 text-left shadow-[var(--shadow-border)]"
        aria-expanded={diagOpen}
      >
        <span className="flex items-center gap-2 text-sm font-medium">
          <CircleDot className="size-4 text-muted" strokeWidth={1.75} aria-hidden />
          Diagnostics
        </span>
        <ChevronDown
          className={cn(
            "size-4 text-muted transition-transform duration-150",
            diagOpen && "rotate-180",
          )}
          aria-hidden
        />
      </button>

      {diagOpen ? <DiagnosticsPanel d={d} steeringOn={settings.steering} /> : null}

      <footer className="mt-6 space-y-3 pb-[env(safe-area-inset-bottom)]">
        <p className="text-[0.75rem] leading-relaxed text-subtle">
          The 1,600 elements represent virtual spatial sampling/encoding territories and
          are not a simulation of actual physical electrodes, cortical stimulation, or
          physiological neural activity. This mobile version demonstrates adaptive
          spatial encoding and visual representation concepts.
        </p>
      </footer>
    </main>
  );
}

function Stage({
  canvasRef,
  label,
  sub,
}: {
  canvasRef: RefObject<HTMLCanvasElement | null>;
  label: string;
  sub: string;
}) {
  return (
    <figure className="min-w-0">
      <div className="overflow-hidden rounded-xl bg-black shadow-[var(--shadow-border)]">
        <canvas
          ref={canvasRef}
          className="block aspect-square w-full"
          aria-label="Phosphene simulation"
        />
      </div>
      <figcaption className="mt-2 flex items-baseline justify-between gap-2 px-0.5">
        <span className="text-sm text-fg">{label}</span>
        <span className="font-mono text-[0.6875rem] text-subtle">{sub}</span>
      </figcaption>
    </figure>
  );
}

function StatChip({
  label,
  value,
  accent,
}: {
  label: string;
  value: string;
  accent?: boolean;
}) {
  return (
    <div className="rounded-md bg-surface px-2.5 py-1.5 shadow-[var(--shadow-border)]">
      <div className="font-mono text-[0.625rem] tracking-wider text-subtle uppercase">
        {label}
      </div>
      <div
        className={cn(
          "font-mono text-sm tabular-nums leading-none",
          accent ? "text-accent" : "text-fg",
        )}
      >
        {value}
      </div>
    </div>
  );
}

function ToggleRow({
  label,
  description,
  checked,
  onCheckedChange,
}: {
  label: string;
  description: string;
  checked: boolean;
  onCheckedChange: (v: boolean) => void;
}) {
  return (
    <label className="flex min-h-11 items-center justify-between gap-4">
      <span>
        <span className="block text-sm font-medium text-fg">{label}</span>
        <span className="block text-[0.75rem] text-subtle">{description}</span>
      </span>
      <Switch.Root
        checked={checked}
        onCheckedChange={onCheckedChange}
        className={cn(
          "relative h-7 w-12 shrink-0 rounded-full bg-elevated shadow-[var(--shadow-border)]",
          "transition-colors duration-150 data-[state=checked]:bg-accent",
        )}
      >
        <Switch.Thumb
          className={cn(
            "block size-5 translate-x-1 rounded-full bg-fg transition-transform duration-150",
            "data-[state=checked]:translate-x-6 data-[state=checked]:bg-accent-fg",
          )}
        />
      </Switch.Root>
    </label>
  );
}

function DiagnosticsPanel({ d, steeringOn }: { d: Diagnostics; steeringOn: boolean }) {
  const nOk = d.elements === TOTAL_ELEMENTS;
  const coverOk = d.coveragePercent >= 99.5 && d.oobTerritories === 0;
  const brightOk = d.brightnessFromImage;
  const steerOk = !steeringOn || (d.steeringWithinMax && d.steeringBrightnessUnchanged);

  return (
    <div className="mt-2 space-y-3 rounded-xl bg-surface p-4 shadow-[var(--shadow-border)]">
      <Check
        pass={nOk}
        label={`${d.elements.toLocaleString()} / ${TOTAL_ELEMENTS.toLocaleString()} elements`}
      />
      <Check
        pass={coverOk}
        label={`Coverage ${d.coveragePercent.toFixed(2)}% · OOB ${d.oobTerritories} · overlap ${d.overlappingPixels} px`}
      />
      <Check
        pass={d.contextProtectionPass}
        label={`Context ${d.contextCount} (${d.pctContext.toFixed(1)}%) · protected 240–400`}
      />
      <Check
        pass={brightOk}
        label={`Brightness from image · mean ${d.meanBrightness.toFixed(1)} · assist Δ ${d.avgContrastAssistDelta.toFixed(2)}`}
      />
      <Check
        pass={steerOk}
        label={
          steeringOn
            ? `Steering max ${ (d.steeringMaxFracUsed * 100).toFixed(1)}% of NN · mean ${d.steeringMeanDisp.toFixed(2)} px · brightness unchanged ${d.steeringBrightnessUnchanged ? "yes" : "no"}`
            : "Steering off — positions unmodified"
        }
      />
      <div className="grid grid-cols-3 gap-2 pt-1 font-mono text-[0.6875rem] tabular-nums text-muted">
        <span>High {d.highCount}</span>
        <span>Med {d.medCount}</span>
        <span>Context {d.contextCount}</span>
      </div>
    </div>
  );
}

function Check({ pass, label }: { pass: boolean; label: string }) {
  return (
    <div className="flex items-start gap-2 text-sm">
      <span
        className={cn(
          "mt-0.5 inline-block size-2 shrink-0 rounded-full",
          pass ? "bg-pass" : "bg-fail",
        )}
        aria-hidden
      />
      <span className="text-fg">
        <span className="font-mono text-[0.6875rem] tracking-wider text-muted uppercase">
          {pass ? "Pass" : "Fail"}
        </span>
        <span className="mt-0.5 block text-[0.8125rem] leading-snug">{label}</span>
      </span>
    </div>
  );
}
