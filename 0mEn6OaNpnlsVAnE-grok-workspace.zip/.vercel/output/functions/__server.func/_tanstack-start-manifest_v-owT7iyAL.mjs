//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-owT7iyAL.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-DSnRQxCI.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DSnRQxCI.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-umjKbbSA.js"]
	}
} });
//#endregion
export { tsrStartManifest };
