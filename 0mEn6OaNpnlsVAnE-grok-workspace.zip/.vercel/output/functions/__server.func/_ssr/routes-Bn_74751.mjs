import { i as __toESM } from "../_runtime.mjs";
import { a as require_jsx_runtime, o as require_react } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { a as CameraOff, i as Camera, n as CircleDot, r as ChevronDown } from "../_libs/lucide-react.mjs";
import { i as SliderTrack, n as SliderRange, r as SliderThumb, t as Slider } from "../_libs/@radix-ui/react-slider+[...].mjs";
import { n as SwitchThumb, t as Switch } from "../_libs/radix-ui__react-switch.mjs";
import { t as clsx } from "../_libs/clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-Bn_74751.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var TOTAL_ELEMENTS = 1600;
var DETAIL_WEIGHT = .25;
var SALIENCY_WEIGHT = .2;
var CONTEXT_WEIGHT = .2;
var MIN_IMPORTANCE = .05;
var ALLOCATION_EXPONENT = 1.5;
var MAX_TERRITORY_FRACTION = .125;
var BACKGROUND_TARGET = .2;
var BACKGROUND_MIN = .15;
var BACKGROUND_MAX = .25;
var TARGET_CONTEXT_COUNT = Math.trunc(TOTAL_ELEMENTS * BACKGROUND_TARGET);
var MIN_CONTEXT_COUNT = Math.trunc(TOTAL_ELEMENTS * BACKGROUND_MIN);
var MAX_CONTEXT_COUNT = Math.trunc(TOTAL_ELEMENTS * BACKGROUND_MAX);
var LOW_IMPORTANCE_THRESHOLD = .2;
var CONTRAST_ASSIST_ALPHA = .08;
var MAX_CONTRAST_GAIN = 1.25;
var MAX_BRIGHTNESS_DELTA = .12;
var IMPORTANCE_TEMPORAL_ALPHA = .75;
function importanceFloor() {
	return Math.max(MIN_IMPORTANCE, 1 / 8);
}
var PHOSPHENE_BASE_RADIUS = 5.5;
var PHOSPHENE_BLUR_SIGMA = 2.5;
var PHOSPHENE_RADIUS_MIN = 3.8;
var PHOSPHENE_RADIUS_MAX = 6.2;
var DENSITY_SMOOTH_ALPHA = .65;
var STEERING_MAX_FRACTION_DEFAULT = .15;
var STEERING_MAX_FRACTION_CAP = .2;
var MIN_SEPARATION_FRAC = .35;
var VECTOR_TEMPORAL_ALPHA = .7;
/**
* Lightweight image operators replacing OpenCV for the mobile build.
* All buffers are preallocated by the caller — no per-frame allocs here.
*/
function rgbaToGray(rgba, gray, n) {
	for (let i = 0, p = 0; i < n; i++, p += 4) gray[i] = .299 * rgba[p] + .587 * rgba[p + 1] + .114 * rgba[p + 2];
}
function downsampleArea(src, sw, sh, dst, dw, dh) {
	const xRatio = sw / dw;
	const yRatio = sh / dh;
	for (let y = 0; y < dh; y++) {
		const y0 = y * yRatio | 0;
		const y1 = Math.min(sh, Math.ceil((y + 1) * yRatio));
		for (let x = 0; x < dw; x++) {
			const x0 = x * xRatio | 0;
			const x1 = Math.min(sw, Math.ceil((x + 1) * xRatio));
			let sum = 0;
			let count = 0;
			for (let yy = y0; yy < y1; yy++) {
				const row = yy * sw;
				for (let xx = x0; xx < x1; xx++) {
					sum += src[row + xx];
					count++;
				}
			}
			dst[y * dw + x] = count ? sum / count : 0;
		}
	}
}
function upsampleBilinear(src, sw, sh, dst, dw, dh) {
	const xRatio = (sw - 1) / Math.max(1, dw - 1);
	const yRatio = (sh - 1) / Math.max(1, dh - 1);
	for (let y = 0; y < dh; y++) {
		const fy = y * yRatio;
		const y0 = fy | 0;
		const y1 = Math.min(sh - 1, y0 + 1);
		const ty = fy - y0;
		for (let x = 0; x < dw; x++) {
			const fx = x * xRatio;
			const x0 = fx | 0;
			const x1 = Math.min(sw - 1, x0 + 1);
			const tx = fx - x0;
			const a = src[y0 * sw + x0];
			const b = src[y0 * sw + x1];
			const c = src[y1 * sw + x0];
			const d = src[y1 * sw + x1];
			dst[y * dw + x] = a * (1 - tx) * (1 - ty) + b * tx * (1 - ty) + c * (1 - tx) * ty + d * tx * ty;
		}
	}
}
function buildIntegral(src, w, h, out) {
	const iw = w + 1;
	out.fill(0);
	for (let y = 0; y < h; y++) {
		let rowSum = 0;
		const srcRow = y * w;
		const dstRow = (y + 1) * iw;
		const prevRow = y * iw;
		for (let x = 0; x < w; x++) {
			rowSum += src[srcRow + x];
			out[dstRow + x + 1] = out[prevRow + x + 1] + rowSum;
		}
	}
}
function rectSum(integral, iw, x, y, w, h) {
	return integral[(y + h) * iw + (x + w)] - integral[y * iw + (x + w)] - integral[(y + h) * iw + x] + integral[y * iw + x];
}
function rectMean(integral, iw, x, y, w, h) {
	const area = w * h;
	if (area <= 0) return 0;
	return rectSum(integral, iw, x, y, w, h) / area;
}
/** Separable box blur. `radius` is half-width of the window. */
function boxBlur(src, dst, tmp, w, h, radius) {
	const r = Math.max(1, radius | 0);
	const inv = 1 / (2 * r + 1);
	for (let y = 0; y < h; y++) {
		const row = y * w;
		let sum = 0;
		for (let x = -r; x <= r; x++) {
			const xx = x < 0 ? 0 : x >= w ? w - 1 : x;
			sum += src[row + xx];
		}
		for (let x = 0; x < w; x++) {
			tmp[row + x] = sum * inv;
			const add = x + r + 1;
			const sub = x - r;
			const a = add >= w ? w - 1 : add;
			const s = sub < 0 ? 0 : sub;
			sum += src[row + a] - src[row + s];
		}
	}
	for (let x = 0; x < w; x++) {
		let sum = 0;
		for (let y = -r; y <= r; y++) {
			const yy = y < 0 ? 0 : y >= h ? h - 1 : y;
			sum += tmp[yy * w + x];
		}
		for (let y = 0; y < h; y++) {
			dst[y * w + x] = sum * inv;
			const add = y + r + 1;
			const sub = y - r;
			const a = add >= h ? h - 1 : add;
			const s = sub < 0 ? 0 : sub;
			sum += tmp[a * w + x] - tmp[s * w + x];
		}
	}
}
/**
* Two-pass box blur ≈ Gaussian with sigma ≈ radius / 0.886.
* Matches the desktop pipeline's GaussianBlur well enough at analysis res.
*/
function gaussianBlurApprox(src, dst, tmp, scratch, w, h, sigma) {
	const radius = Math.max(1, Math.round(sigma * .9));
	boxBlur(src, scratch, tmp, w, h, radius);
	boxBlur(scratch, dst, tmp, w, h, radius);
}
function sobelMagnitude(src, dst, w, h) {
	for (let y = 0; y < h; y++) {
		const ym = y === 0 ? 0 : y - 1;
		const yp = y === h - 1 ? h - 1 : y + 1;
		for (let x = 0; x < w; x++) {
			const xm = x === 0 ? 0 : x - 1;
			const xp = x === w - 1 ? w - 1 : x + 1;
			const p00 = src[ym * w + xm];
			const p01 = src[ym * w + x];
			const p02 = src[ym * w + xp];
			const p10 = src[y * w + xm];
			const p12 = src[y * w + xp];
			const p20 = src[yp * w + xm];
			const p21 = src[yp * w + x];
			const p22 = src[yp * w + xp];
			const gx = -p00 + p02 - 2 * p10 + 2 * p12 - p20 + p22;
			const gy = -p00 - 2 * p01 - p02 + p20 + 2 * p21 + p22;
			dst[y * w + x] = Math.sqrt(gx * gx + gy * gy);
		}
	}
}
/** Mixed partial d²/dxdy — stand-in for OpenCV Sobel(dx=1, dy=1). */
function mixedDerivative(src, dst, w, h) {
	for (let y = 0; y < h; y++) {
		const ym = y === 0 ? 0 : y - 1;
		const yp = y === h - 1 ? h - 1 : y + 1;
		for (let x = 0; x < w; x++) {
			const xm = x === 0 ? 0 : x - 1;
			const xp = x === w - 1 ? w - 1 : x + 1;
			dst[y * w + x] = Math.abs(src[yp * w + xp] - src[yp * w + xm] - src[ym * w + xp] + src[ym * w + xm]);
		}
	}
}
function histogramMedian255(src, n) {
	const bins = /* @__PURE__ */ new Int32Array(256);
	for (let i = 0; i < n; i++) {
		let v = src[i] | 0;
		if (v < 0) v = 0;
		else if (v > 255) v = 255;
		bins[v]++;
	}
	const mid = n >> 1;
	let acc = 0;
	for (let i = 0; i < 256; i++) {
		acc += bins[i];
		if (acc >= mid) return i;
	}
	return 128;
}
function clip01(v) {
	return v < 0 ? 0 : v > 1 ? 1 : v;
}
function squareInto(src, dst, n) {
	for (let i = 0; i < n; i++) dst[i] = src[i] * src[i];
}
/**
* Animated synthetic scene so the simulator is usable without a camera
* (preview, permission-denied, desktop browsers without a device).
*
* Designed so adaptive allocation is obvious: a walking figure with
* high-frequency clothing in front of a relatively uniform wall, plus a
* window with blinds (detail) and simple furniture (medium).
*/
var W = 320;
var H = 320;
function hash2(x, y) {
	let n = Math.imul(x | 0, 374761393) + Math.imul(y | 0, 668265263);
	n = Math.imul(n ^ n >>> 13, 1274126177);
	return ((n ^ n >>> 16) >>> 0) / 4294967296;
}
function vnoise(x, y) {
	const x0 = Math.floor(x);
	const y0 = Math.floor(y);
	const fx = x - x0;
	const fy = y - y0;
	const ux = fx * fx * (3 - 2 * fx);
	const uy = fy * fy * (3 - 2 * fy);
	const a = hash2(x0, y0);
	const b = hash2(x0 + 1, y0);
	const c = hash2(x0, y0 + 1);
	const d = hash2(x0 + 1, y0 + 1);
	return a + (b - a) * ux + (c - a) * uy + (a - b - c + d) * ux * uy;
}
function fillRect(gray, x0, y0, x1, y1, value, texture = 0) {
	const xa = Math.max(0, Math.floor(x0));
	const xb = Math.min(W, Math.ceil(x1));
	const ya = Math.max(0, Math.floor(y0));
	const yb = Math.min(H, Math.ceil(y1));
	for (let y = ya; y < yb; y++) {
		const row = y * W;
		for (let x = xa; x < xb; x++) {
			const t = texture ? (vnoise(x * .18, y * .18) - .5) * texture : 0;
			gray[row + x] = value + t;
		}
	}
}
function fillEllipse(gray, cx, cy, rx, ry, value, stripe = 0) {
	const x0 = Math.max(0, Math.floor(cx - rx));
	const x1 = Math.min(W, Math.ceil(cx + rx));
	const y0 = Math.max(0, Math.floor(cy - ry));
	const y1 = Math.min(H, Math.ceil(cy + ry));
	const rx2 = rx * rx;
	const ry2 = ry * ry;
	for (let y = y0; y < y1; y++) {
		const dy = y - cy;
		const row = y * W;
		for (let x = x0; x < x1; x++) {
			const dx = x - cx;
			if (dx * dx / rx2 + dy * dy / ry2 <= 1) {
				let v = value;
				if (stripe && (x + y & 3) < 2) v *= .55;
				gray[row + x] = v;
			}
		}
	}
}
function renderDemoScene(gray, timeSec) {
	const t = timeSec;
	for (let y = 0; y < H; y++) {
		const row = y * W;
		const wall = 118 + y / H * 18;
		for (let x = 0; x < W; x++) {
			const n = (vnoise(x * .07, y * .07) - .5) * 10;
			gray[row + x] = wall + n;
		}
	}
	const floorY = H * .62;
	for (let y = floorY | 0; y < H; y++) {
		const row = y * W;
		const base = 72 + (y - floorY) / (H - floorY) * 28;
		for (let x = 0; x < W; x++) {
			const plank = Math.sin(x * .08) * 6;
			gray[row + x] = base + plank + (vnoise(x * .2, y * .4) - .5) * 8;
		}
	}
	const wx0 = 18;
	const wy0 = 36;
	const wx1 = 96;
	const wy1 = 132;
	const glow = 200 + Math.sin(t * .6) * 18;
	fillRect(gray, 12, 28, 102, 140, 92, 4);
	for (let y = wy0; y < wy1; y++) {
		const row = y * W;
		const blind = (y - wy0) % 7 < 2 ? .55 : 1;
		for (let x = wx0; x < wx1; x++) gray[row + x] = glow * blind + (x % 5 === 0 ? -12 : 0);
	}
	fillRect(gray, 200, 42, 268, 108, 64, 2);
	fillRect(gray, 206, 48, 262, 102, 150, 18);
	fillRect(gray, 250, 88, 304, floorY + 8, 78, 6);
	fillRect(gray, 292, 150, 298, 162, 40, 0);
	fillRect(gray, 108, 196, 214, 248, 58, 8);
	fillRect(gray, 118, 248, 128, 288, 48, 2);
	fillRect(gray, 194, 248, 204, 288, 48, 2);
	const px = 52;
	const py = 210;
	fillEllipse(gray, px, 238, 8, 18, 42, 0);
	for (let i = 0; i < 14; i++) {
		const a = i / 14 * Math.PI * 2 + t * .2;
		fillEllipse(gray, px + Math.cos(a) * 16, py + Math.sin(a) * 10 - 8, 7, 12, 86 + i % 3 * 10, 1);
	}
	fillEllipse(gray, 168, 176, 11, 13, 210, 0);
	fillEllipse(gray, 168, 208, 16, 22, 70, 1);
	fillRect(gray, 154, 226, 182, 248, 48, 0);
	const personX = 70 + (.5 + .5 * Math.sin(t * .85)) * 150;
	const personY = 168;
	const leg = Math.sin(t * 4.2);
	fillEllipse(gray, personX, 130, 13, 15, 215, 0);
	fillEllipse(gray, personX, personY, 18, 28, 48, 1);
	fillEllipse(gray, personX - 20, 172 + leg * 6, 6, 16, 200, 0);
	fillEllipse(gray, personX + 20, 172 - leg * 6, 6, 16, 200, 0);
	fillEllipse(gray, personX - 8, 210 + leg * 8, 6, 22, 36, 0);
	fillEllipse(gray, personX + 8, 210 - leg * 8, 6, 22, 36, 0);
	for (let i = 0; i < gray.length; i++) {
		const v = gray[i];
		gray[i] = v < 0 ? 0 : v > 255 ? 255 : v;
	}
}
var FrameCapture = class {
	canvas;
	ctx;
	gray = /* @__PURE__ */ new Float32Array(102400);
	video = null;
	stream = null;
	source = "demo";
	cameraError = null;
	rgbaScratch = /* @__PURE__ */ new Uint8ClampedArray(409600);
	constructor() {
		this.canvas = document.createElement("canvas");
		this.canvas.width = 320;
		this.canvas.height = 320;
		const ctx = this.canvas.getContext("2d", {
			willReadFrequently: true,
			alpha: false
		});
		if (!ctx) throw new Error("Could not create capture canvas");
		this.ctx = ctx;
	}
	grab(timeSec) {
		if (this.source === "camera" && this.video && this.video.readyState >= 2) {
			const vw = this.video.videoWidth;
			const vh = this.video.videoHeight;
			if (vw > 0 && vh > 0) {
				const side = Math.min(vw, vh);
				const sx = (vw - side) / 2;
				const sy = (vh - side) / 2;
				this.ctx.drawImage(this.video, sx, sy, side, side, 0, 0, 320, 320);
				const img = this.ctx.getImageData(0, 0, 320, 320);
				this.rgbaScratch.set(img.data);
				rgbaToGray(this.rgbaScratch, this.gray, 102400);
				return this.gray;
			}
		}
		renderDemoScene(this.gray, timeSec);
		return this.gray;
	}
	async startCamera() {
		this.cameraError = null;
		if (typeof navigator === "undefined" || !navigator.mediaDevices?.getUserMedia) {
			this.cameraError = "Camera API is not available in this browser.";
			this.source = "demo";
			return;
		}
		try {
			const stream = await navigator.mediaDevices.getUserMedia({
				audio: false,
				video: {
					facingMode: { ideal: "environment" },
					width: { ideal: 640 },
					height: { ideal: 640 }
				}
			});
			await this.attachStream(stream);
		} catch (err) {
			try {
				const stream = await navigator.mediaDevices.getUserMedia({
					audio: false,
					video: true
				});
				await this.attachStream(stream);
			} catch (err2) {
				this.stopCamera();
				this.cameraError = humanCameraError(err2 ?? err);
				this.source = "demo";
			}
		}
	}
	async attachStream(stream) {
		this.stopTracks();
		this.stream = stream;
		const video = document.createElement("video");
		video.setAttribute("playsinline", "true");
		video.setAttribute("webkit-playsinline", "true");
		video.muted = true;
		video.autoplay = true;
		video.srcObject = stream;
		await video.play();
		this.video = video;
		this.source = "camera";
		this.cameraError = null;
	}
	stopCamera() {
		this.stopTracks();
		if (this.video) {
			this.video.srcObject = null;
			this.video = null;
		}
		this.source = "demo";
	}
	stopTracks() {
		if (!this.stream) return;
		for (const track of this.stream.getTracks()) track.stop();
		this.stream = null;
	}
	dispose() {
		this.stopCamera();
	}
};
function humanCameraError(err) {
	const name = err && typeof err === "object" && "name" in err ? String(err.name) : "";
	if (name === "NotAllowedError" || name === "PermissionDeniedError") return "Camera permission was declined. Using the demo scene.";
	if (name === "NotFoundError" || name === "DevicesNotFoundError") return "No camera was found. Using the demo scene.";
	if (name === "NotReadableError") return "Camera is already in use. Using the demo scene.";
	return `${err instanceof Error ? err.message : "Camera unavailable."} Using the demo scene.`;
}
var counter = /* @__PURE__ */ new Int32Array(102400);
function calculateDiagnostics(territories, opts) {
	const width = 320;
	const height = 320;
	const n = territories.n;
	counter.fill(0);
	let oob = 0;
	for (let i = 0; i < n; i++) {
		const x = territories.x[i];
		const y = territories.y[i];
		const w = territories.w[i];
		const h = territories.h[i];
		if (x < 0 || y < 0 || x + w > width || y + h > height || w <= 0 || h <= 0) {
			oob++;
			continue;
		}
		for (let yy = y; yy < y + h; yy++) {
			const row = yy * width;
			for (let xx = x; xx < x + w; xx++) counter[row + xx]++;
		}
	}
	let uncovered = 0;
	let overlapping = 0;
	let covered = 0;
	const totalPx = width * height;
	for (let i = 0; i < totalPx; i++) {
		const c = counter[i];
		if (c === 0) uncovered++;
		else {
			covered++;
			if (c > 1) overlapping++;
		}
	}
	let high = 0;
	let med = 0;
	let ctx = 0;
	let sumB = 0;
	let minB = 255;
	let maxB = 0;
	let nearBlack = 0;
	let saturated = 0;
	let delta = 0;
	for (let i = 0; i < n; i++) {
		const s = territories.score[i];
		if (s >= .45) high++;
		else if (s >= .2) med++;
		else ctx++;
		const b = territories.brightness[i];
		sumB += b;
		if (b < minB) minB = b;
		if (b > maxB) maxB = b;
		if (b < 8) nearBlack++;
		if (b > 247) saturated++;
		delta += Math.abs(b - territories.rawBrightness[i]);
	}
	const fracCap = opts?.steeringMaxFraction ?? .2;
	const maxFracUsed = opts?.steeringMaxFracUsed ?? 0;
	return {
		elements: n,
		coveragePercent: 100 * covered / totalPx,
		uncoveredPixels: uncovered,
		overlappingPixels: overlapping,
		oobTerritories: oob,
		highCount: high,
		pctHigh: n ? 100 * high / n : 0,
		medCount: med,
		pctMed: n ? 100 * med / n : 0,
		contextCount: ctx,
		pctContext: n ? 100 * ctx / n : 0,
		contextProtectionPass: ctx >= MIN_CONTEXT_COUNT && ctx <= MAX_CONTEXT_COUNT,
		avgContrastAssistDelta: n ? delta / n : 0,
		meanBrightness: n ? sumB / n : 0,
		minBrightness: n ? minB : 0,
		maxBrightness: n ? maxB : 0,
		nearBlackCount: nearBlack,
		pctNearBlack: n ? 100 * nearBlack / n : 0,
		saturatedCount: saturated,
		pctSaturated: n ? 100 * saturated / n : 0,
		brightnessFromImage: true,
		steeringMeanDisp: opts?.steeringMeanDisp ?? 0,
		steeringMaxDisp: opts?.steeringMaxDisp ?? 0,
		steeringMaxFracUsed: maxFracUsed,
		steeringWithinMax: maxFracUsed <= fracCap + .05,
		steeringBrightnessUnchanged: opts?.brightnessUnchanged ?? true
	};
}
function emptyDiagnostics() {
	return calculateDiagnostics({
		n: TOTAL_ELEMENTS,
		x: new Int32Array(TOTAL_ELEMENTS),
		y: new Int32Array(TOTAL_ELEMENTS),
		w: new Int32Array(TOTAL_ELEMENTS),
		h: new Int32Array(TOTAL_ELEMENTS),
		score: new Float32Array(TOTAL_ELEMENTS),
		brightness: new Float32Array(TOTAL_ELEMENTS),
		rawBrightness: new Float32Array(TOTAL_ELEMENTS),
		cx: new Float64Array(TOTAL_ELEMENTS),
		cy: new Float64Array(TOTAL_ELEMENTS)
	}, {});
}
/**
* MOBILE IMPORTANCE DETECTOR
* --------------------------
* Browser approximation of desktop ImportanceEngine (prosthesis_core.py).
*
* Desktop fuses four maps:
*   semantic (YOLO seg) 0.35 + detail 0.25 + saliency 0.20 + context 0.20
*
* This mobile build does NOT run YOLO / Ultralytics / any neural net.
* Semantic weight is dropped and the remaining three maps are renormalized,
* matching the desktop `--no-semantic` / fallback path:
*   detail, saliency (DoG + global contrast), context (structure + variance).
*
* To plug in a more sophisticated model later, replace `compute()` so it
* still returns a Float32Array of length CAPTURE_SIZE² in
* [importanceFloor(), 1]. Territory allocation and steering will pick it up
* without further changes.
*/
var AW = 160;
var AH = 160;
var AN = AW * AH;
var CW = 320;
var CH = 320;
var CN = CW * CH;
var ImportanceEngine = class {
	analysis = new Float32Array(AN);
	detail = new Float32Array(AN);
	saliency = new Float32Array(AN);
	context = new Float32Array(AN);
	combined = new Float32Array(AN);
	full = new Float32Array(CN);
	tmpA = new Float32Array(AN);
	tmpB = new Float32Array(AN);
	tmpC = new Float32Array(AN);
	tmpD = new Float32Array(AN);
	previous = null;
	prevBuf = new Float32Array(AN);
	reset() {
		this.previous = null;
	}
	/**
	* @param gray Capture-resolution luminance, 0–255, length CAPTURE_SIZE²
	* @returns Full-resolution importance map, length CAPTURE_SIZE²
	*/
	compute(gray, useTemporal = true) {
		downsampleArea(gray, CW, CH, this.analysis, AW, AH);
		this.computeDetail(this.analysis, this.detail);
		this.computeSaliency(this.analysis, this.saliency);
		this.computeContext(this.analysis, this.context);
		const floor = importanceFloor();
		const wDet = DETAIL_WEIGHT;
		const wSal = SALIENCY_WEIGHT;
		const wCtx = CONTEXT_WEIGHT;
		const total = wDet + wSal + wCtx;
		const det = this.detail;
		const sal = this.saliency;
		const ctx = this.context;
		const comb = this.combined;
		for (let i = 0; i < AN; i++) comb[i] = (wDet * det[i] + wSal * sal[i] + wCtx * ctx[i]) / total;
		gaussianBlurApprox(comb, comb, this.tmpA, this.tmpB, AW, AH, 3);
		for (let i = 0; i < AN; i++) {
			const v = comb[i];
			comb[i] = v < floor ? floor : v > 1 ? 1 : v;
		}
		if (useTemporal && this.previous) {
			const a = IMPORTANCE_TEMPORAL_ALPHA;
			const prev = this.previous;
			for (let i = 0; i < AN; i++) comb[i] = a * prev[i] + (1 - a) * comb[i];
		}
		this.prevBuf.set(comb);
		this.previous = this.prevBuf;
		upsampleBilinear(comb, AW, AH, this.full, CW, CH);
		for (let i = 0; i < CN; i++) {
			const v = this.full[i];
			this.full[i] = v < floor ? floor : v > 1 ? 1 : v;
		}
		return this.full;
	}
	computeDetail(img, out) {
		const sigmas = [
			1.2,
			3,
			6
		];
		const refs = [
			300,
			180,
			90
		];
		const weights = [
			.5,
			.3,
			.2
		];
		out.fill(0);
		for (let k = 0; k < 3; k++) {
			gaussianBlurApprox(img, this.tmpC, this.tmpA, this.tmpB, AW, AH, sigmas[k]);
			sobelMagnitude(this.tmpC, this.tmpD, AW, AH);
			const inv = 1 / refs[k];
			const w = weights[k];
			for (let i = 0; i < AN; i++) {
				const v = this.tmpD[i] * inv;
				out[i] += w * (v < 0 ? 0 : v > 1 ? 1 : v);
			}
		}
		for (let i = 0; i < AN; i++) out[i] = clip01(out[i]);
	}
	computeSaliency(img, out) {
		gaussianBlurApprox(img, this.tmpC, this.tmpA, this.tmpB, AW, AH, 2);
		gaussianBlurApprox(img, this.tmpD, this.tmpA, this.tmpB, AW, AH, 14);
		const median = histogramMedian255(img, AN);
		gaussianBlurApprox(img, this.tmpA, this.tmpB, out, AW, AH, 8);
		for (let i = 0; i < AN; i++) {
			const dog = clip01(Math.abs(this.tmpC[i] - this.tmpD[i]) / 40);
			const globalC = clip01(Math.abs(this.tmpA[i] - median) / 60);
			out[i] = clip01(.6 * dog + .4 * globalC);
		}
	}
	computeContext(img, out) {
		gaussianBlurApprox(img, this.tmpC, this.tmpA, this.tmpB, AW, AH, 16);
		mixedDerivative(this.tmpC, this.tmpD, AW, AH);
		squareInto(img, this.tmpA, AN);
		gaussianBlurApprox(this.tmpA, this.tmpB, this.tmpC, out, AW, AH, 12);
		gaussianBlurApprox(img, this.tmpA, this.tmpC, out, AW, AH, 12);
		for (let i = 0; i < AN; i++) {
			const ctxStruct = clip01(this.tmpD[i] / 50);
			const varApprox = this.tmpB[i] - this.tmpA[i] * this.tmpA[i];
			const ctxCont = clip01(Math.sqrt(varApprox > 0 ? varApprox : 0) / 40);
			out[i] = clip01(.5 * ctxStruct + .5 * ctxCont);
		}
	}
};
/**
* Spatial-hash k-nearest neighbors for 1,600 points.
* Replaces the O(n²) pairwise matrices in the Python prototype so the
* mobile build can hold 20–30 FPS. Results are equivalent for local k.
*/
var HASH_BINS = 64;
var SpatialKnn = class {
	heads = /* @__PURE__ */ new Int32Array(4096);
	next;
	cap;
	cell = 8;
	originX = 0;
	originY = 0;
	cols = HASH_BINS;
	rows = HASH_BINS;
	constructor(cap) {
		this.cap = cap;
		this.next = new Int32Array(cap);
	}
	build(cx, cy, n) {
		let minX = Infinity;
		let minY = Infinity;
		let maxX = -Infinity;
		let maxY = -Infinity;
		for (let i = 0; i < n; i++) {
			const x = cx[i];
			const y = cy[i];
			if (x < minX) minX = x;
			if (y < minY) minY = y;
			if (x > maxX) maxX = x;
			if (y > maxY) maxY = y;
		}
		const spanX = Math.max(1, maxX - minX);
		const spanY = Math.max(1, maxY - minY);
		this.cell = Math.max(4, Math.sqrt(spanX * spanY / Math.max(1, n)));
		this.originX = minX;
		this.originY = minY;
		this.cols = Math.min(HASH_BINS, Math.max(4, Math.ceil(spanX / this.cell) + 1));
		this.rows = Math.min(HASH_BINS, Math.max(4, Math.ceil(spanY / this.cell) + 1));
		this.heads.fill(-1);
		for (let i = 0; i < n; i++) {
			const gx = this.binX(cx[i]);
			const b = this.binY(cy[i]) * this.cols + gx;
			this.next[i] = this.heads[b];
			this.heads[b] = i;
		}
	}
	/**
	* Fill idxOut[i*k + t] and distOut[i*k + t] with the t-th nearest neighbor
	* of i (sorted by distance, excluding self). Returns mean nearest-neighbor
	* distance.
	*/
	query(cx, cy, n, k, idxOut, distOut) {
		const kEff = Math.min(k, Math.max(0, n - 1));
		let nnSum = 0;
		const candIdx = this._candIdx;
		const candD = this._candD;
		for (let i = 0; i < n; i++) {
			const x = cx[i];
			const y = cy[i];
			let count = 0;
			const gx = this.binX(x);
			const gy = this.binY(y);
			for (let ring = 1; ring <= 6 && count < kEff * 4; ring++) {
				const x0 = Math.max(0, gx - ring);
				const x1 = Math.min(this.cols - 1, gx + ring);
				const y0 = Math.max(0, gy - ring);
				const y1 = Math.min(this.rows - 1, gy + ring);
				for (let by = y0; by <= y1; by++) for (let bx = x0; bx <= x1; bx++) {
					if (ring > 1) {
						if (bx > x0 && bx < x1 && by > y0 && by < y1 && bx >= gx - (ring - 1) && bx <= gx + (ring - 1) && by >= gy - (ring - 1) && by <= gy + (ring - 1)) continue;
					}
					let t = this.heads[by * this.cols + bx];
					while (t !== -1) {
						if (t !== i && count < candIdx.length) {
							const dx = cx[t] - x;
							const dy = cy[t] - y;
							candIdx[count] = t;
							candD[count] = dx * dx + dy * dy;
							count++;
						}
						t = this.next[t];
					}
				}
			}
			const take = Math.min(kEff, count);
			for (let a = 0; a < take; a++) {
				let minI = a;
				for (let b = a + 1; b < count; b++) if (candD[b] < candD[minI]) minI = b;
				if (minI !== a) {
					const td = candD[a];
					candD[a] = candD[minI];
					candD[minI] = td;
					const ti = candIdx[a];
					candIdx[a] = candIdx[minI];
					candIdx[minI] = ti;
				}
			}
			const base = i * k;
			for (let t = 0; t < k; t++) if (t < take) {
				idxOut[base + t] = candIdx[t];
				distOut[base + t] = Math.sqrt(Math.max(candD[t], 1e-12));
			} else {
				idxOut[base + t] = i;
				distOut[base + t] = 1;
			}
			nnSum += distOut[base];
		}
		return n > 0 ? nnSum / n : 1;
	}
	_candIdx = /* @__PURE__ */ new Int32Array(256);
	_candD = /* @__PURE__ */ new Float32Array(256);
	binX(x) {
		const v = (x - this.originX) / this.cell | 0;
		return v < 0 ? 0 : v >= this.cols ? this.cols - 1 : v;
	}
	binY(y) {
		const v = (y - this.originY) / this.cell | 0;
		return v < 0 ? 0 : v >= this.rows ? this.rows - 1 : v;
	}
};
/**
* Density-aware circular PSF renderer.
*
* Port of prosthesis_core.render_phosphenes:
*   - Sparse regions keep a near-baseline radius (background coherence).
*   - Dense regions receive a modestly smaller radius (separability).
*   - Variation is continuous and tightly bounded.
*   - Brightness values come unchanged from the encoding stage.
*   - Phosphenes are CIRCLES. No ellipses, no cells, no photographic reconstruct.
*/
var N$1 = TOTAL_ELEMENTS;
var PhospheneRenderer = class {
	size = 512;
	buf = /* @__PURE__ */ new Float32Array(262144);
	tmp = /* @__PURE__ */ new Float32Array(262144);
	scratch = /* @__PURE__ */ new Float32Array(262144);
	image = null;
	density = new Float32Array(N$1);
	prevDensity = new Float32Array(N$1);
	hasPrevDensity = false;
	knn = new SpatialKnn(N$1 + 8);
	knnIdx = new Int32Array(N$1 * 6);
	knnDist = new Float32Array(N$1 * 6);
	outCx = new Float64Array(N$1);
	outCy = new Float64Array(N$1);
	resetDensity() {
		this.hasPrevDensity = false;
	}
	ensureSize(size) {
		const s = Math.max(256, Math.min(800, size | 0));
		if (s === this.size && this.image) return;
		this.size = s;
		const n = s * s;
		this.buf = new Float32Array(n);
		this.tmp = new Float32Array(n);
		this.scratch = new Float32Array(n);
		this.image = new ImageData(s, s);
	}
	get outputSize() {
		return this.size;
	}
	render(cx, cy, brightness, n, imgW, imgH, densityAware, ctx) {
		const size = this.size;
		this.ensureSize(size);
		const scale = size / 800;
		const sx = size / imgW;
		const sy = size / imgH;
		const buf = this.buf;
		buf.fill(0);
		for (let i = 0; i < n; i++) {
			this.outCx[i] = cx[i] * sx;
			this.outCy[i] = cy[i] * sy;
		}
		let radiiBase = PHOSPHENE_BASE_RADIUS * scale;
		const rMin = PHOSPHENE_RADIUS_MIN * scale;
		const rMax = PHOSPHENE_RADIUS_MAX * scale;
		if (densityAware && n > 8) {
			this.knn.build(this.outCx, this.outCy, n);
			this.knn.query(this.outCx, this.outCy, n, 6, this.knnIdx, this.knnDist);
			const meanD = this.tmp;
			for (let i = 0; i < n; i++) {
				let s = 0;
				const base = i * 6;
				for (let t = 0; t < 6; t++) s += this.knnDist[base + t];
				meanD[i] = s / 6;
			}
			const sorted = Array.from(meanD.subarray(0, n)).sort((a, b) => a - b);
			const p10 = sorted[n * .1 | 0] ?? 0;
			const p90 = sorted[n * .9 | 0] ?? 1;
			const span = Math.max(p90 - p10, .001);
			const dens = this.density;
			for (let i = 0; i < n; i++) {
				let d = 1 - (meanD[i] - p10) / span;
				if (d < 0) d = 0;
				else if (d > 1) d = 1;
				dens[i] = d;
			}
			if (this.hasPrevDensity) {
				const a = DENSITY_SMOOTH_ALPHA;
				for (let i = 0; i < n; i++) dens[i] = a * this.prevDensity[i] + (1 - a) * dens[i];
			}
			this.prevDensity.set(dens.subarray(0, n));
			this.hasPrevDensity = true;
			for (let i = 0; i < n; i++) {
				let r = rMax - dens[i] * (rMax - rMin);
				if (r < rMin) r = rMin;
				else if (r > rMax) r = rMax;
				this.stamp(buf, size, this.outCx[i], this.outCy[i], r, brightness[i] / 255);
			}
		} else {
			this.hasPrevDensity = false;
			const r = Math.max(rMin, radiiBase);
			for (let i = 0; i < n; i++) this.stamp(buf, size, this.outCx[i], this.outCy[i], r, brightness[i] / 255);
		}
		const blurR = Math.max(1, Math.round(PHOSPHENE_BLUR_SIGMA * scale * .9));
		this.boxBlurGray(buf, this.scratch, this.tmp, size, size, blurR);
		this.boxBlurGray(this.scratch, buf, this.tmp, size, size, blurR);
		const image = this.image;
		const px = image.data;
		for (let i = 0, p = 0; i < buf.length; i++, p += 4) {
			let v = buf[i] * 255;
			if (v < 0) v = 0;
			else if (v > 255) v = 255;
			const u = v | 0;
			px[p] = u;
			px[p + 1] = u;
			px[p + 2] = u;
			px[p + 3] = 255;
		}
		ctx.putImageData(image, 0, 0);
	}
	stamp(buf, size, cx, cy, radius, val) {
		const r = Math.max(1, radius);
		const r2 = r * r;
		const x0 = Math.max(0, Math.floor(cx - r));
		const x1 = Math.min(size - 1, Math.ceil(cx + r));
		const y0 = Math.max(0, Math.floor(cy - r));
		const y1 = Math.min(size - 1, Math.ceil(cy + r));
		for (let y = y0; y <= y1; y++) {
			const dy = y - cy;
			const row = y * size;
			for (let x = x0; x <= x1; x++) {
				const dx = x - cx;
				if (dx * dx + dy * dy <= r2) buf[row + x] = val;
			}
		}
	}
	boxBlurGray(src, dst, tmp, w, h, radius) {
		const r = Math.max(1, radius | 0);
		const inv = 1 / (2 * r + 1);
		for (let y = 0; y < h; y++) {
			const row = y * w;
			let sum = 0;
			for (let x = -r; x <= r; x++) {
				const xx = x < 0 ? 0 : x >= w ? w - 1 : x;
				sum += src[row + xx];
			}
			for (let x = 0; x < w; x++) {
				tmp[row + x] = sum * inv;
				const add = x + r + 1 >= w ? w - 1 : x + r + 1;
				const sub = x - r < 0 ? 0 : x - r;
				sum += src[row + add] - src[row + sub];
			}
		}
		for (let x = 0; x < w; x++) {
			let sum = 0;
			for (let y = -r; y <= r; y++) {
				const yy = y < 0 ? 0 : y >= h ? h - 1 : y;
				sum += tmp[yy * w + x];
			}
			for (let y = 0; y < h; y++) {
				dst[y * w + x] = sum * inv;
				const add = y + r + 1 >= h ? h - 1 : y + r + 1;
				const sub = y - r < 0 ? 0 : y - r;
				sum += tmp[add * w + x] - tmp[sub * w + x];
			}
		}
	}
};
/**
* Local positional steering — render-time only.
*
* Conceptual port of current_steering_standalone.py:
*   - Underlying territory centers and brightness are NEVER modified.
*   - A small, coherent offset is applied to a copy of the centers.
*   - Phosphenes stay circular. No ellipses, no pooling, no extra elements.
*   - Max displacement = steeringMaxFraction * nearest-neighbor distance
*     (hard-capped at 0.20).
*   - Steering does not touch brightness.
*/
var N = TOTAL_ELEMENTS;
var K = 8;
var SteeringField = class {
	knn = new SpatialKnn(N + 8);
	idx = new Int32Array(N * K);
	dist = new Float32Array(N * K);
	nnDist = new Float32Array(N);
	vx = new Float64Array(N);
	vy = new Float64Array(N);
	cxS = new Float64Array(N);
	cyS = new Float64Array(N);
	disp = new Float32Array(N);
	structure = new Float64Array(N);
	prevVx = new Float64Array(N);
	prevVy = new Float64Array(N);
	hasPrev = false;
	meanNn = 8;
	meanDisp = 0;
	maxDisp = 0;
	maxFracUsed = 0;
	pctMeaningful = 0;
	reset() {
		this.hasPrev = false;
	}
	apply(territories, steeringMaxFraction) {
		const n = territories.n;
		const cx = territories.cx;
		const cy = territories.cy;
		const scores = territories.score;
		const frac = Math.min(Math.max(steeringMaxFraction, 0), STEERING_MAX_FRACTION_CAP);
		this.knn.build(cx, cy, n);
		this.meanNn = this.knn.query(cx, cy, n, K, this.idx, this.dist);
		for (let i = 0; i < n; i++) this.nnDist[i] = this.dist[i * K];
		this.computeStructure(n);
		this.computeVectors(cx, cy, scores, n);
		this.applyDisplacements(cx, cy, n, frac);
		return {
			cx: this.cxS,
			cy: this.cyS
		};
	}
	computeStructure(n) {
		const inv = this.vx;
		for (let i = 0; i < n; i++) inv[i] = 1 / Math.max(this.nnDist[i], 1e-6);
		const sorted = Array.from(inv.subarray(0, n)).sort((a, b) => a - b);
		const p10 = sorted[Math.max(0, (n * .1 | 0) - 0)] ?? 0;
		const p90 = sorted[Math.min(n - 1, n * .9 | 0)] ?? 1;
		const span = Math.max(p90 - p10, 1e-6);
		for (let i = 0; i < n; i++) {
			let s = (inv[i] - p10) / span;
			if (s < 0) s = 0;
			else if (s > 1) s = 1;
			this.structure[i] = s;
		}
	}
	computeVectors(cx, cy, scores, n) {
		const vx = this.vx;
		const vy = this.vy;
		vx.fill(0);
		vy.fill(0);
		const k = K;
		for (let i = 0; i < n; i++) {
			const si = this.structure[i];
			if (si < .12) continue;
			let accx = 0;
			let accy = 0;
			let wsum = 0;
			const di = .55 * clamp01(scores[i]) + .45 * si;
			for (let t = 0; t < k; t++) {
				const j = this.idx[i * k + t];
				if (j === i) continue;
				const dx = cx[j] - cx[i];
				const dy = cy[j] - cy[i];
				const dist = Math.hypot(dx, dy);
				if (dist < 1e-8) continue;
				const dj = .55 * clamp01(scores[j]) + .45 * this.structure[j];
				const w = Math.max(0, dj - di) + .15 * si;
				accx += dx / dist * w;
				accy += dy / dist * w;
				wsum += Math.abs(w);
			}
			if (wsum < 1e-8) {
				let cxn = 0;
				let cyn = 0;
				let c = 0;
				for (let t = 0; t < k; t++) {
					const j = this.idx[i * k + t];
					cxn += cx[j];
					cyn += cy[j];
					c++;
				}
				if (c) {
					const dx = cxn / c - cx[i];
					const dy = cyn / c - cy[i];
					const mag = Math.hypot(dx, dy);
					if (mag > 1e-8) {
						accx = dx / mag * si;
						accy = dy / mag * si;
						wsum = si;
					}
				}
			}
			if (wsum > 1e-8) {
				const mag = Math.hypot(accx, accy) + 1e-8;
				const g = 1 * si;
				vx[i] = accx / mag * g;
				vy[i] = accy / mag * g;
			}
		}
		const nvx = this.cxS;
		const nvy = this.cyS;
		for (let pass = 0; pass < 2; pass++) {
			for (let i = 0; i < n; i++) {
				let accx = vx[i];
				let accy = vy[i];
				let wsum = 1;
				for (let t = 0; t < k; t++) {
					const j = this.idx[i * k + t];
					accx += vx[j];
					accy += vy[j];
					wsum += 1;
				}
				nvx[i] = accx / wsum;
				nvy[i] = accy / wsum;
			}
			vx.set(nvx.subarray(0, n));
			vy.set(nvy.subarray(0, n));
		}
		if (this.hasPrev) {
			const a = VECTOR_TEMPORAL_ALPHA;
			for (let i = 0; i < n; i++) {
				vx[i] = a * this.prevVx[i] + (1 - a) * vx[i];
				vy[i] = a * this.prevVy[i] + (1 - a) * vy[i];
			}
		}
		this.prevVx.set(vx.subarray(0, n));
		this.prevVy.set(vy.subarray(0, n));
		this.hasPrev = true;
	}
	applyDisplacements(cx, cy, n, frac) {
		const margin = 1;
		let maxFrac = 0;
		let mean = 0;
		let maxD = 0;
		let meaningful = 0;
		for (let i = 0; i < n; i++) {
			const nn = this.nnDist[i];
			const maxDisp = frac * nn;
			let dx = this.vx[i] * nn;
			let dy = this.vy[i] * nn;
			const mag = Math.hypot(dx, dy);
			if (mag > maxDisp && mag > 1e-8) {
				const s = maxDisp / mag;
				dx *= s;
				dy *= s;
			}
			let xs = cx[i] + dx;
			let ys = cy[i] + dy;
			if (xs < margin) xs = margin;
			else if (xs > 318) xs = 318;
			if (ys < margin) ys = margin;
			else if (ys > 318) ys = 318;
			this.cxS[i] = xs;
			this.cyS[i] = ys;
		}
		const meanNn = Math.max(this.meanNn, 1);
		const minSep = MIN_SEPARATION_FRAC * meanNn;
		const cell = Math.max(meanNn * .5, 1);
		const grid = /* @__PURE__ */ new Map();
		const key = (x, y) => y * 4096 ^ x | 0;
		for (let i = 0; i < n; i++) {
			const k = key(this.cxS[i] / cell | 0, this.cyS[i] / cell | 0);
			let bucket = grid.get(k);
			if (!bucket) {
				bucket = [];
				grid.set(k, bucket);
			}
			bucket.push(i);
		}
		for (let i = 0; i < n; i++) {
			const gx = this.cxS[i] / cell | 0;
			const gy = this.cyS[i] / cell | 0;
			for (let ox = -1; ox <= 1; ox++) for (let oy = -1; oy <= 1; oy++) {
				const bucket = grid.get(key(gx + ox, gy + oy));
				if (!bucket) continue;
				for (let b = 0; b < bucket.length; b++) {
					const j = bucket[b];
					if (j <= i) continue;
					const ddx = this.cxS[i] - this.cxS[j];
					const ddy = this.cyS[i] - this.cyS[j];
					const dist = Math.hypot(ddx, ddy);
					if (dist < minSep && dist > 1e-6) {
						const deficit = (minSep - dist) / 2;
						const ux = ddx / dist;
						const uy = ddy / dist;
						this.cxS[i] += ux * deficit;
						this.cyS[i] += uy * deficit;
						this.cxS[j] -= ux * deficit;
						this.cyS[j] -= uy * deficit;
					}
				}
			}
		}
		for (let i = 0; i < n; i++) {
			let xs = this.cxS[i];
			let ys = this.cyS[i];
			if (xs < margin) xs = margin;
			else if (xs > 318) xs = 318;
			if (ys < margin) ys = margin;
			else if (ys > 318) ys = 318;
			this.cxS[i] = xs;
			this.cyS[i] = ys;
			const d = Math.hypot(xs - cx[i], ys - cy[i]);
			this.disp[i] = d;
			mean += d;
			if (d > maxD) maxD = d;
			const nn = this.nnDist[i];
			const used = nn > 1e-6 ? d / nn : 0;
			if (used > maxFrac) maxFrac = used;
			if (d > .05 * nn) meaningful++;
		}
		this.meanDisp = n ? mean / n : 0;
		this.maxDisp = maxD;
		this.maxFracUsed = maxFrac;
		this.pctMeaningful = n ? 100 * meaningful / n : 0;
	}
};
function clamp01(v) {
	return v < 0 ? 0 : v > 1 ? 1 : v;
}
/**
* Quadtree partition guaranteeing 1,600 territories with a PROTECTED
* context / background allocation range (15%–25% / 240–400 elements).
*
* Port of prosthesis_core.build_territories / build_uniform_territories.
* Importance controls WHERE spatial resolution is spent. Brightness is
* sampled from the camera image (mean luminance of each territory) and is
* never a function of importance except for the bounded contrast-assist
* shift, which is capped at MAX_BRIGHTNESS_DELTA.
*/
function createTerritoryStore(cap = TOTAL_ELEMENTS + 16) {
	return {
		n: 0,
		x: new Int32Array(cap),
		y: new Int32Array(cap),
		w: new Int32Array(cap),
		h: new Int32Array(cap),
		score: new Float32Array(cap),
		brightness: new Float32Array(cap),
		rawBrightness: new Float32Array(cap),
		cx: new Float64Array(cap),
		cy: new Float64Array(cap)
	};
}
var MaxHeap = class {
	a = [];
	clear() {
		this.a.length = 0;
	}
	get length() {
		return this.a.length;
	}
	peek() {
		return this.a[0];
	}
	push(n) {
		const a = this.a;
		a.push(n);
		let i = a.length - 1;
		while (i > 0) {
			const p = i - 1 >> 1;
			if (a[p].prio > a[i].prio || a[p].prio === a[i].prio && a[p].id <= a[i].id) break;
			const t = a[p];
			a[p] = a[i];
			a[i] = t;
			i = p;
		}
	}
	pop() {
		const a = this.a;
		const top = a[0];
		const last = a.pop();
		if (a.length) {
			a[0] = last;
			let i = 0;
			const n = a.length;
			for (;;) {
				let s = i;
				const l = i * 2 + 1;
				const r = l + 1;
				if (l < n && (a[l].prio > a[s].prio || a[l].prio === a[s].prio && a[l].id < a[s].id)) s = l;
				if (r < n && (a[r].prio > a[s].prio || a[r].prio === a[s].prio && a[r].id < a[s].id)) s = r;
				if (s === i) break;
				const t = a[i];
				a[i] = a[s];
				a[s] = t;
				i = s;
			}
		}
		return top;
	}
};
var highHeap = new MaxHeap();
var ctxHeap = new MaxHeap();
var highFrozen = [];
var ctxFrozen = [];
var grayIntegral = /* @__PURE__ */ new Float64Array(103041);
var impIntegral = /* @__PURE__ */ new Float64Array(103041);
var localLum = /* @__PURE__ */ new Float32Array(102400);
var blurTmp = /* @__PURE__ */ new Float32Array(102400);
var blurScratch = /* @__PURE__ */ new Float32Array(102400);
function canSplit(w, h) {
	return w >= 8 && h >= 8;
}
function computePrio(w, h, score, maxSide) {
	if (w > maxSide || h > maxSide) return 0xe8d4a51000 + w * h;
	return Math.pow(score, ALLOCATION_EXPONENT) * (w * h);
}
function finalize(nodes, gray, store, contrastAssist) {
	const width = 320;
	const height = 320;
	const iw = 321;
	const n = Math.min(nodes.length, store.x.length);
	store.n = n;
	for (let i = 0; i < n; i++) {
		const nd = nodes[i];
		const x = nd.x;
		const y = nd.y;
		const w = nd.w;
		const h = nd.h;
		store.x[i] = x;
		store.y[i] = y;
		store.w[i] = w;
		store.h[i] = h;
		store.score[i] = nd.score;
		const raw = rectMean(grayIntegral, iw, x, y, w, h);
		store.rawBrightness[i] = raw;
		store.cx[i] = x + w / 2;
		store.cy[i] = y + h / 2;
	}
	if (!contrastAssist) {
		store.brightness.set(store.rawBrightness.subarray(0, n));
		return;
	}
	const radius = Math.max(1, Math.round(13.5));
	boxBlur(gray, localLum, blurTmp, width, height, radius);
	boxBlur(localLum, blurScratch, blurTmp, width, height, radius);
	for (let i = 0; i < n; i++) {
		const cx = Math.min(319, Math.max(0, store.cx[i] | 0));
		const cy = Math.min(319, Math.max(0, store.cy[i] | 0));
		const bOrig = store.rawBrightness[i] / 255;
		const bLocal = blurScratch[cy * width + cx] / 255;
		const score = store.score[i];
		const factor = Math.min(1 + CONTRAST_ASSIST_ALPHA * score, MAX_CONTRAST_GAIN);
		let shift = bLocal + (bOrig - bLocal) * factor - bOrig;
		if (shift > .12) shift = MAX_BRIGHTNESS_DELTA;
		else if (shift < -.12) shift = -MAX_BRIGHTNESS_DELTA;
		let v = (bOrig + shift) * 255;
		if (v < 0) v = 0;
		else if (v > 255) v = 255;
		store.brightness[i] = v;
	}
}
function buildTerritories(gray, importance, store, contrastAssist) {
	const width = 320;
	const height = 320;
	const iw = 321;
	buildIntegral(gray, width, height, grayIntegral);
	buildIntegral(importance, width, height, impIntegral);
	const maxSide = Math.max(width, height) * MAX_TERRITORY_FRACTION;
	highHeap.clear();
	ctxHeap.clear();
	highFrozen.length = 0;
	ctxFrozen.length = 0;
	let nextId = 0;
	const rootScore = rectMean(impIntegral, iw, 0, 0, width, height);
	const root = {
		prio: computePrio(width, height, rootScore, maxSide),
		id: nextId++,
		x: 0,
		y: 0,
		w: width,
		h: height,
		score: rootScore
	};
	let currentContext = 0;
	let leafCount = 1;
	if (rootScore < .2) {
		ctxHeap.push(root);
		currentContext = 1;
	} else highHeap.push(root);
	while (leafCount < TOTAL_ELEMENTS) {
		const canHigh = highHeap.length > 0;
		const canCtx = ctxHeap.length > 0;
		if (!canHigh && !canCtx) break;
		let popHigh;
		if (canHigh && canCtx) {
			if (currentContext < MIN_CONTEXT_COUNT) popHigh = false;
			else if (currentContext + 3 > MAX_CONTEXT_COUNT) popHigh = true;
			else if (currentContext < TARGET_CONTEXT_COUNT) popHigh = highHeap.peek().prio > ctxHeap.peek().prio * 1.5;
			else popHigh = highHeap.peek().prio * 1.5 >= ctxHeap.peek().prio;
		} else popHigh = canHigh;
		const node = popHigh ? highHeap.pop() : ctxHeap.pop();
		if (!popHigh) currentContext -= 1;
		const hw = node.w >> 1;
		const hh = node.h >> 1;
		const children = [
			[
				node.x,
				node.y,
				hw,
				hh
			],
			[
				node.x + hw,
				node.y,
				node.w - hw,
				hh
			],
			[
				node.x,
				node.y + hh,
				hw,
				node.h - hh
			],
			[
				node.x + hw,
				node.y + hh,
				node.w - hw,
				node.h - hh
			]
		];
		for (let c = 0; c < 4; c++) {
			const [cx, cy, cw, ch] = children[c];
			if (cw <= 0 || ch <= 0) continue;
			const cScore = rectMean(impIntegral, iw, cx, cy, cw, ch);
			const cPrio = computePrio(cw, ch, cScore, maxSide);
			const isCtx = cScore < LOW_IMPORTANCE_THRESHOLD;
			const child = {
				prio: cPrio,
				id: nextId++,
				x: cx,
				y: cy,
				w: cw,
				h: ch,
				score: cScore
			};
			if (canSplit(cw, ch)) {
				if (isCtx) {
					currentContext += 1;
					ctxHeap.push(child);
				} else highHeap.push(child);
			} else if (isCtx) {
				currentContext += 1;
				ctxFrozen.push(child);
			} else highFrozen.push(child);
		}
		leafCount += 3;
	}
	const leaves = [];
	for (let i = 0; i < highFrozen.length; i++) leaves.push(highFrozen[i]);
	for (let i = 0; i < ctxFrozen.length; i++) leaves.push(ctxFrozen[i]);
	for (let i = 0; i < highHeap.a.length; i++) leaves.push(highHeap.a[i]);
	for (let i = 0; i < ctxHeap.a.length; i++) leaves.push(ctxHeap.a[i]);
	while (leaves.length < TOTAL_ELEMENTS) {
		let best = -1;
		let bestArea = -1;
		for (let i = 0; i < leaves.length; i++) {
			const nd = leaves[i];
			if (!canSplit(nd.w, nd.h)) continue;
			const area = nd.w * nd.h;
			if (area > bestArea) {
				bestArea = area;
				best = i;
			}
		}
		if (best < 0) break;
		const node = leaves[best];
		const hw = node.w >> 1;
		const hh = node.h >> 1;
		const kids = [
			[
				node.x,
				node.y,
				hw,
				hh
			],
			[
				node.x + hw,
				node.y,
				node.w - hw,
				hh
			],
			[
				node.x,
				node.y + hh,
				hw,
				node.h - hh
			],
			[
				node.x + hw,
				node.y + hh,
				node.w - hw,
				node.h - hh
			]
		];
		leaves.splice(best, 1);
		for (let c = 0; c < 4; c++) {
			const [cx, cy, cw, ch] = kids[c];
			if (cw <= 0 || ch <= 0) continue;
			const cScore = rectMean(impIntegral, iw, cx, cy, cw, ch);
			leaves.push({
				prio: 0,
				id: nextId++,
				x: cx,
				y: cy,
				w: cw,
				h: ch,
				score: cScore
			});
		}
	}
	if (leaves.length > 1600) leaves.length = TOTAL_ELEMENTS;
	finalize(leaves, gray, store, contrastAssist);
}
function buildUniformTerritories(gray, importance, store, contrastAssist) {
	const width = 320;
	const height = 320;
	const iw = 321;
	buildIntegral(gray, width, height, grayIntegral);
	buildIntegral(importance, width, height, impIntegral);
	const xs = /* @__PURE__ */ new Int32Array(41);
	const ys = /* @__PURE__ */ new Int32Array(41);
	for (let c = 0; c <= 40; c++) xs[c] = Math.round(c * width / 40);
	for (let r = 0; r <= 40; r++) ys[r] = Math.round(r * height / 40);
	const leaves = [];
	let id = 0;
	for (let r = 0; r < 40; r++) for (let c = 0; c < 40; c++) {
		const x = xs[c];
		const y = ys[r];
		const w = xs[c + 1] - x;
		const h = ys[r + 1] - y;
		const score = rectMean(impIntegral, iw, x, y, w, h);
		leaves.push({
			prio: 0,
			id: id++,
			x,
			y,
			w,
			h,
			score
		});
	}
	finalize(leaves, gray, store, contrastAssist);
}
`${(BACKGROUND_MIN * 100).toFixed(0)}${(BACKGROUND_MAX * 100).toFixed(0)}${(BACKGROUND_TARGET * 100).toFixed(0)}`;
/**
* Frame pipeline matching prosthesis_core.encode_frame + optional steering.
*
*   capture → importance → 1,600 territories → (steer) → phosphene render
*
* Brightness is sampled from the camera / demo image. Importance only
* controls spatial allocation (and a bounded local contrast assist).
*/
var DEFAULT_SETTINGS = {
	adaptive: true,
	steering: false,
	steeringMaxFraction: .15,
	comparison: false,
	contrastAssist: true,
	densityAware: true
};
var ProsthesisSimulator = class {
	capture = new FrameCapture();
	importance = new ImportanceEngine();
	adaptiveStore = createTerritoryStore();
	uniformStore = createTerritoryStore();
	steering = new SteeringField();
	renderer = new PhospheneRenderer();
	rendererB = new PhospheneRenderer();
	mainCtx = null;
	compareCtx = null;
	lastTime = 0;
	fpsEma = 24;
	hud = {
		fps: 0,
		source: "demo",
		cameraError: null,
		diagnostics: emptyDiagnostics(),
		compareDiagnostics: null
	};
	attach(main, compare) {
		const mainCtx = main.getContext("2d", { alpha: false });
		if (!mainCtx) throw new Error("Could not get 2D context");
		this.mainCtx = mainCtx;
		this.compareCtx = compare ? compare.getContext("2d", { alpha: false }) : null;
		this.resize(main, compare);
	}
	resize(main, compare) {
		const dpr = typeof window !== "undefined" ? Math.min(2, window.devicePixelRatio || 1) : 1;
		const css = Math.max(280, Math.min(main.clientWidth || 512, 720));
		const px = Math.round(css * dpr);
		this.renderer.ensureSize(px);
		this.rendererB.ensureSize(px);
		if (main.width !== px) {
			main.width = px;
			main.height = px;
		}
		if (compare) {
			if (compare.width !== px) {
				compare.width = px;
				compare.height = px;
			}
			this.compareCtx = compare.getContext("2d", { alpha: false });
		}
	}
	tick(nowMs, settings = DEFAULT_SETTINGS) {
		const dt = this.lastTime ? (nowMs - this.lastTime) / 1e3 : .032;
		this.lastTime = nowMs;
		const fpsInst = dt > 1e-4 ? 1 / dt : 30;
		this.fpsEma = this.fpsEma * .9 + fpsInst * .1;
		const gray = this.capture.grab(nowMs / 1e3);
		const importance = this.importance.compute(gray, true);
		if (settings.adaptive) buildTerritories(gray, importance, this.adaptiveStore, settings.contrastAssist);
		else buildUniformTerritories(gray, importance, this.adaptiveStore, settings.contrastAssist);
		const primary = this.adaptiveStore;
		let cx = primary.cx;
		let cy = primary.cy;
		const brightnessBefore = checksum(primary.brightness, primary.n);
		let steeringMean = 0;
		let steeringMax = 0;
		let steeringFrac = 0;
		if (settings.steering && settings.steeringMaxFraction > 0) {
			const steered = this.steering.apply(primary, Math.min(settings.steeringMaxFraction, STEERING_MAX_FRACTION_CAP));
			cx = steered.cx;
			cy = steered.cy;
			steeringMean = this.steering.meanDisp;
			steeringMax = this.steering.maxDisp;
			steeringFrac = this.steering.maxFracUsed;
		} else this.steering.reset();
		const brightnessUnchanged = brightnessBefore === checksum(primary.brightness, primary.n);
		if (this.mainCtx) this.renderer.render(cx, cy, primary.brightness, primary.n, 320, 320, settings.densityAware, this.mainCtx);
		let compareDiag = null;
		if (settings.comparison) {
			buildUniformTerritories(gray, importance, this.uniformStore, settings.contrastAssist);
			if (this.compareCtx) this.rendererB.render(this.uniformStore.cx, this.uniformStore.cy, this.uniformStore.brightness, this.uniformStore.n, 320, 320, false, this.compareCtx);
			compareDiag = calculateDiagnostics(this.uniformStore);
		}
		this.hud = {
			fps: this.fpsEma,
			source: this.capture.source,
			cameraError: this.capture.cameraError,
			diagnostics: calculateDiagnostics(primary, {
				steeringMeanDisp: steeringMean,
				steeringMaxDisp: steeringMax,
				steeringMaxFracUsed: steeringFrac,
				steeringMaxFraction: settings.steeringMaxFraction,
				brightnessUnchanged
			}),
			compareDiagnostics: compareDiag
		};
		return this.hud;
	}
	async startCamera() {
		await this.capture.startCamera();
		this.importance.reset();
		this.steering.reset();
		this.renderer.resetDensity();
		this.rendererB.resetDensity();
		return this.capture.source;
	}
	stopCamera() {
		this.capture.stopCamera();
		this.importance.reset();
		this.steering.reset();
		this.renderer.resetDensity();
		this.rendererB.resetDensity();
	}
	resetTemporal() {
		this.importance.reset();
		this.steering.reset();
		this.renderer.resetDensity();
		this.rendererB.resetDensity();
	}
	dispose() {
		this.capture.dispose();
	}
};
function checksum(a, n) {
	let s = 0;
	for (let i = 0; i < n; i++) s += a[i] * (i + 1);
	return s;
}
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var INITIAL_SETTINGS = {
	adaptive: true,
	steering: false,
	steeringMaxFraction: STEERING_MAX_FRACTION_DEFAULT,
	comparison: false,
	contrastAssist: true,
	densityAware: true
};
function emptyHud() {
	return {
		fps: 0,
		source: "demo",
		cameraError: null,
		diagnostics: {
			elements: TOTAL_ELEMENTS,
			coveragePercent: 0,
			uncoveredPixels: 0,
			overlappingPixels: 0,
			oobTerritories: 0,
			highCount: 0,
			pctHigh: 0,
			medCount: 0,
			pctMed: 0,
			contextCount: 0,
			pctContext: 0,
			contextProtectionPass: false,
			avgContrastAssistDelta: 0,
			meanBrightness: 0,
			minBrightness: 0,
			maxBrightness: 0,
			nearBlackCount: 0,
			pctNearBlack: 0,
			saturatedCount: 0,
			pctSaturated: 0,
			brightnessFromImage: true,
			steeringMeanDisp: 0,
			steeringMaxDisp: 0,
			steeringMaxFracUsed: 0,
			steeringWithinMax: true,
			steeringBrightnessUnchanged: true
		},
		compareDiagnostics: null
	};
}
function SimulatorApp() {
	const mainRef = (0, import_react.useRef)(null);
	const compareRef = (0, import_react.useRef)(null);
	const engineRef = (0, import_react.useRef)(null);
	const settingsRef = (0, import_react.useRef)(INITIAL_SETTINGS);
	const [settings, setSettings] = (0, import_react.useState)(INITIAL_SETTINGS);
	const [hud, setHud] = (0, import_react.useState)(emptyHud);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [diagOpen, setDiagOpen] = (0, import_react.useState)(false);
	const [ready, setReady] = (0, import_react.useState)(false);
	settingsRef.current = settings;
	const apply = (0, import_react.useCallback)((patch) => {
		setSettings((prev) => {
			const next = {
				...prev,
				...patch
			};
			settingsRef.current = next;
			if (patch.adaptive !== void 0 || patch.steering !== void 0) engineRef.current?.resetTemporal();
			return next;
		});
	}, []);
	(0, import_react.useEffect)(() => {
		const engine = new ProsthesisSimulator();
		engineRef.current = engine;
		const main = mainRef.current;
		if (!main) return;
		const attach = () => engine.attach(main, compareRef.current);
		attach();
		requestAnimationFrame(attach);
		setReady(true);
		let raf = 0;
		let lastHud = 0;
		const loop = (now) => {
			const snap = engine.tick(now, settingsRef.current);
			if (lastHud === 0 || now - lastHud > 250) {
				lastHud = now;
				setHud({
					...snap,
					diagnostics: { ...snap.diagnostics }
				});
			}
			raf = requestAnimationFrame(loop);
		};
		raf = requestAnimationFrame(loop);
		const onResize = () => engine.resize(main, compareRef.current);
		window.addEventListener("resize", onResize);
		const ro = new ResizeObserver(onResize);
		ro.observe(main);
		if ("serviceWorker" in navigator) navigator.serviceWorker.register("/service-worker.js").catch(() => {});
		return () => {
			cancelAnimationFrame(raf);
			window.removeEventListener("resize", onResize);
			ro.disconnect();
			engine.dispose();
			engineRef.current = null;
		};
	}, []);
	(0, import_react.useEffect)(() => {
		const main = mainRef.current;
		if (main) engineRef.current?.resize(main, compareRef.current);
	}, [settings.comparison]);
	const startCamera = async () => {
		if (!engineRef.current || busy) return;
		setBusy(true);
		try {
			await engineRef.current.startCamera();
		} finally {
			setBusy(false);
		}
	};
	const stopCamera = () => {
		engineRef.current?.stopCamera();
	};
	const d = hud.diagnostics;
	const cameraOn = hud.source === "camera";
	const strengthPct = Math.round(settings.steeringMaxFraction * 100);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto flex min-h-dvh w-full max-w-3xl flex-col bg-bg px-4 pb-8 pt-[max(0.75rem,env(safe-area-inset-top))] sm:px-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex items-end justify-between gap-3 pb-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-mono text-[0.6875rem] tracking-[0.18em] text-muted uppercase",
					children: "Visual encoding"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-[2rem] leading-tight tracking-[-0.03em] text-fg italic sm:text-[2.35rem]",
					children: "Phosphene 1600"
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2 pb-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatChip, {
						label: "FPS",
						value: ready ? hud.fps.toFixed(0) : "—"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatChip, {
						label: "Elements",
						value: String(TOTAL_ELEMENTS),
						accent: true
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: cn("grid gap-3", settings.comparison ? "grid-cols-2" : "grid-cols-1"),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stage, {
					canvasRef: mainRef,
					label: settings.adaptive ? "Adaptive · 1,600 territories" : "Uniform 40 × 40",
					sub: settings.steering ? `Steering ${strengthPct}%` : "No steering"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: settings.comparison ? "block" : "hidden",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stage, {
						canvasRef: compareRef,
						label: "Baseline · uniform 40 × 40",
						sub: "No steering"
					})
				})]
			}),
			hud.cameraError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 rounded-md bg-elevated px-3 py-2 text-sm text-warn",
				role: "status",
				children: hud.cameraError
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-3 font-mono text-[0.6875rem] tracking-wide text-subtle",
				children: [
					"Source · ",
					cameraOn ? "rear camera" : "demo scene",
					" · ",
					"Importance is a mobile approximation (gradient, contrast, variance). No YOLO segmentation."
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-5 flex flex-col gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-2 gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: startCamera,
						disabled: busy || cameraOn,
						className: cn("flex h-12 items-center justify-center gap-2 rounded-lg bg-accent px-3 font-medium text-accent-fg", "transition-[opacity,transform] duration-150 ease-out active:scale-[0.96]", "disabled:opacity-40"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Camera, {
							className: "size-4",
							strokeWidth: 1.75,
							"aria-hidden": true
						}), "Start Camera"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: stopCamera,
						disabled: !cameraOn,
						className: cn("flex h-12 items-center justify-center gap-2 rounded-lg bg-elevated px-3 font-medium text-fg", "shadow-[var(--shadow-border)]", "transition-[opacity,transform] duration-150 ease-out active:scale-[0.96]", "disabled:opacity-40"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CameraOff, {
							className: "size-4",
							strokeWidth: 1.75,
							"aria-hidden": true
						}), "Stop Camera"]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-xl bg-surface p-4 shadow-[var(--shadow-border)]",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToggleRow, {
							label: "Adaptive allocation",
							description: "Finer territories on important structure",
							checked: settings.adaptive,
							onCheckedChange: (v) => apply({ adaptive: v })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "my-3 h-px bg-line" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToggleRow, {
							label: "Steering",
							description: "Bounded positional offset at render time",
							checked: settings.steering,
							onCheckedChange: (v) => apply({ steering: v })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mb-2 flex items-baseline justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
										className: "text-sm text-fg",
										htmlFor: "steering-strength",
										children: "Steering strength"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "font-mono text-sm tabular-nums text-muted",
										children: [strengthPct, "%"]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Slider, {
									id: "steering-strength",
									value: [strengthPct],
									min: 0,
									max: 20,
									step: 1,
									disabled: !settings.steering,
									onValueChange: ([v]) => apply({ steeringMaxFraction: (v ?? 0) / 100 }),
									className: "relative flex h-8 w-full touch-none items-center",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderTrack, {
										className: "relative h-1.5 grow rounded-full bg-elevated",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderRange, { className: "absolute h-full rounded-full bg-accent" })
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderThumb, {
										className: "block size-5 rounded-full bg-fg shadow-[var(--shadow-border)] outline-none focus-visible:ring-2 focus-visible:ring-accent",
										"aria-label": "Steering strength"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 text-[0.75rem] text-subtle",
									children: "0–20% of nearest-neighbor spacing"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "my-3 h-px bg-line" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToggleRow, {
							label: "Baseline comparison",
							description: "Uniform 40 × 40 beside the live encoding",
							checked: settings.comparison,
							onCheckedChange: (v) => apply({ comparison: v })
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: () => setDiagOpen((o) => !o),
				className: "mt-4 flex h-12 w-full items-center justify-between rounded-lg bg-surface px-4 text-left shadow-[var(--shadow-border)]",
				"aria-expanded": diagOpen,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "flex items-center gap-2 text-sm font-medium",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleDot, {
						className: "size-4 text-muted",
						strokeWidth: 1.75,
						"aria-hidden": true
					}), "Diagnostics"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, {
					className: cn("size-4 text-muted transition-transform duration-150", diagOpen && "rotate-180"),
					"aria-hidden": true
				})]
			}),
			diagOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DiagnosticsPanel, {
				d,
				steeringOn: settings.steering
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("footer", {
				className: "mt-6 space-y-3 pb-[env(safe-area-inset-bottom)]",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[0.75rem] leading-relaxed text-subtle",
					children: "The 1,600 elements represent virtual spatial sampling/encoding territories and are not a simulation of actual physical electrodes, cortical stimulation, or physiological neural activity. This mobile version demonstrates adaptive spatial encoding and visual representation concepts."
				})
			})
		]
	});
}
function Stage({ canvasRef, label, sub }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figure", {
		className: "min-w-0",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "overflow-hidden rounded-xl bg-black shadow-[var(--shadow-border)]",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
				ref: canvasRef,
				className: "block aspect-square w-full",
				"aria-label": "Phosphene simulation"
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figcaption", {
			className: "mt-2 flex items-baseline justify-between gap-2 px-0.5",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-sm text-fg",
				children: label
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "font-mono text-[0.6875rem] text-subtle",
				children: sub
			})]
		})]
	});
}
function StatChip({ label, value, accent }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-md bg-surface px-2.5 py-1.5 shadow-[var(--shadow-border)]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "font-mono text-[0.625rem] tracking-wider text-subtle uppercase",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: cn("font-mono text-sm tabular-nums leading-none", accent ? "text-accent" : "text-fg"),
			children: value
		})]
	});
}
function ToggleRow({ label, description, checked, onCheckedChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "flex min-h-11 items-center justify-between gap-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "block text-sm font-medium text-fg",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "block text-[0.75rem] text-subtle",
			children: description
		})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
			checked,
			onCheckedChange,
			className: cn("relative h-7 w-12 shrink-0 rounded-full bg-elevated shadow-[var(--shadow-border)]", "transition-colors duration-150 data-[state=checked]:bg-accent"),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SwitchThumb, { className: cn("block size-5 translate-x-1 rounded-full bg-fg transition-transform duration-150", "data-[state=checked]:translate-x-6 data-[state=checked]:bg-accent-fg") })
		})]
	});
}
function DiagnosticsPanel({ d, steeringOn }) {
	const nOk = d.elements === TOTAL_ELEMENTS;
	const coverOk = d.coveragePercent >= 99.5 && d.oobTerritories === 0;
	const brightOk = d.brightnessFromImage;
	const steerOk = !steeringOn || d.steeringWithinMax && d.steeringBrightnessUnchanged;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mt-2 space-y-3 rounded-xl bg-surface p-4 shadow-[var(--shadow-border)]",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {
				pass: nOk,
				label: `${d.elements.toLocaleString()} / ${TOTAL_ELEMENTS.toLocaleString()} elements`
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {
				pass: coverOk,
				label: `Coverage ${d.coveragePercent.toFixed(2)}% · OOB ${d.oobTerritories} · overlap ${d.overlappingPixels} px`
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {
				pass: d.contextProtectionPass,
				label: `Context ${d.contextCount} (${d.pctContext.toFixed(1)}%) · protected 240–400`
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {
				pass: brightOk,
				label: `Brightness from image · mean ${d.meanBrightness.toFixed(1)} · assist Δ ${d.avgContrastAssistDelta.toFixed(2)}`
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {
				pass: steerOk,
				label: steeringOn ? `Steering max ${(d.steeringMaxFracUsed * 100).toFixed(1)}% of NN · mean ${d.steeringMeanDisp.toFixed(2)} px · brightness unchanged ${d.steeringBrightnessUnchanged ? "yes" : "no"}` : "Steering off — positions unmodified"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-3 gap-2 pt-1 font-mono text-[0.6875rem] tabular-nums text-muted",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["High ", d.highCount] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Med ", d.medCount] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Context ", d.contextCount] })
				]
			})
		]
	});
}
function Check({ pass, label }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-start gap-2 text-sm",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: cn("mt-0.5 inline-block size-2 shrink-0 rounded-full", pass ? "bg-pass" : "bg-fail"),
			"aria-hidden": true
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "text-fg",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "font-mono text-[0.6875rem] tracking-wider text-muted uppercase",
				children: pass ? "Pass" : "Fail"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "mt-0.5 block text-[0.8125rem] leading-snug",
				children: label
			})]
		})]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SimulatorApp, {});
}
//#endregion
export { Home as component };
